"""Emotion template fusion for DAZ/Faceit rigs.

Adds emotion-template ARKit weights on top of the NVIDIA-driven
BlendshapeFrame.weights, BEFORE the weights are written to the rig, so the
emotion intensity can be fused into the final animation.
"""

from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Audio amplitude envelope extraction
# ---------------------------------------------------------------------------

def compute_amplitude_envelope(
    audio_path: str,
    fps: float,
    total_frames: int,
    frame_offset: int = 0,
    hop_size: int = 512,
) -> Optional[List[float]]:
    """Compute a per-frame amplitude envelope from an audio file.

    Uses librosa to load the audio and compute RMS energy. The result is
    normalized so the peak amplitude maps to 1.0. Returns the raw [0, 1]
    envelope; the emotion floor (non_mouth_min_ratio / mouth_min_ratio) is
    applied at the call site so each segment can use its own user-controlled
    minimum ratio.

    Args:
        audio_path: path to the source .wav file.
        fps: scene frame rate.
        total_frames: number of animation frames to cover.
        frame_offset: frame number offset (segment start).
        hop_size: librosa hop length for RMS computation.

    Returns:
        List of per-frame amplitude values [0.0, 1.0], or None on error.
    """
    try:
        import librosa
        import numpy as np
    except ImportError:
        print("[EmotionFusion] librosa/numpy not available, skipping amplitude modulation")
        return None

    try:
        y, sr = librosa.load(audio_path, sr=None, mono=True)
    except Exception as e:
        print(f"[EmotionFusion] Failed to load audio: {e}")
        return None

    if len(y) == 0:
        return None

    # Compute RMS energy
    rms = librosa.feature.rms(y=y, hop_length=hop_size, frame_length=hop_size * 2)[0]

    if len(rms) == 0:
        return None

    # Convert RMS frame times to animation frames
    rms_times = librosa.frames_to_time(
        range(len(rms)), sr=sr, hop_length=hop_size
    )

    # Map to animation frame numbers
    rms_frames = [int(round(t * fps)) + 1 + frame_offset for t in rms_times]

    # Build per-frame envelope by interpolation
    max_frame = total_frames + frame_offset
    envelope = [0.0] * (max_frame + 1)

    for i, frame_num in enumerate(rms_frames):
        if 0 <= frame_num <= max_frame:
            envelope[frame_num] = rms[i]

    # Forward-fill zeros (interpolate gaps)
    last_val = 0.0
    for i in range(len(envelope)):
        if envelope[i] > 0:
            last_val = envelope[i]
        else:
            envelope[i] = last_val

    # Normalize to [0, 1] based on the 95th percentile (avoid spikes)
    peak = float(np.percentile(envelope, 95)) if len(envelope) > 0 else 1.0
    if peak < 1e-6:
        peak = 1.0

    normalized = [min(1.0, v / peak) for v in envelope]

    # Return the raw normalized envelope [0, 1]. The emotion floor
    # (non_mouth_min_ratio / mouth_min_ratio) is applied at the call site
    # so each segment can use its own user-controlled minimum ratio.
    return normalized


def apply_emotion_fusion_to_weights(
    blendshape_data,
    segments,
    audio_path: str,
    fps: float,
    frame_offset: int = 0,
    cross_fade_sec: float = 0.3,
):
    """Apply emotion templates to ARKit blendshape weights in-place.

    Adds emotion-template ARKit weights directly on top of the
    NVIDIA-driven BlendshapeFrame.weights, BEFORE the weights are written
    to DAZ Object-level facs_* properties. The existing
    apply_blendshapes_to_daz_rig() write path is unchanged.

    Pipeline:
        NVIDIA inference -> blendshape_data (ARKit weights, PascalCase)
        -> [this function] adds emotion template weights in-place
        -> apply_blendshapes_to_daz_rig writes combined weights to rig

    Mouth-channel emotion weights are suppressed when the lip-sync JawOpen
    value indicates the mouth is closed (JawOpen < 0.3), preserving
    bilabial closure (b/p/m sounds) — the ARKit-weight-domain equivalent
    of the jaw_master rotation suppression used for A2F_Rig.

    The core algorithm (template lookup, cross-fade, split-envelope,
    Gaussian smoothing, closure suppression, mouth-expression clamping)
    runs in the compiled C++ engine (a2f_engine.pyd) to protect the IP.
    This function handles audio envelope extraction (librosa) and Blender
    property parsing in Python, then delegates the fusion math to C++.

    Args:
        blendshape_data: list of BlendshapeFrame (modified in-place).
        segments: list of AudioMorphEmotionSegmentItem.
        audio_path: source audio file (for amplitude envelope).
        fps: scene frame rate.
        frame_offset: frame number offset (segment start).
        cross_fade_sec: cross-fade duration between adjacent segments.
    """
    if not segments or not blendshape_data:
        return

    total_frames = len(blendshape_data)

    # Compute amplitude envelope (Python: librosa dependency).
    envelope = compute_amplitude_envelope(
        audio_path, fps, total_frames, frame_offset
    )
    if envelope is None:
        print("[EmotionFusion-Weights] No amplitude envelope, using constant intensity")
        envelope = [1.0] * (total_frames + frame_offset + 1)

    # Parse segment properties from Blender (Python: bpy property access).
    emo_segments = []
    _debug_seg_emotions = []
    for seg in segments:
        emo_id = _get_segment_emotion_id(seg)
        _debug_seg_emotions.append(emo_id)
        emo_segments.append({
            "emotion": emo_id,
            "intensity": float(getattr(seg, "intensity", 1.0)),
            "mouth_intensity": float(getattr(seg, "mouth_intensity", 0.5)),
            "non_mouth_min_ratio": float(getattr(seg, "non_mouth_min_ratio", 0.3)),
            "mouth_min_ratio": float(getattr(seg, "mouth_min_ratio", 0.1)),
            "start_frame": int(getattr(seg, "frame", 1)),
        })

    print(f"[EmotionFusion-Weights] DEBUG: segment emotions={_debug_seg_emotions}")

    # Delegate core fusion to C++ engine.
    try:
        import a2f_engine as _native
        # Convert BlendshapeFrame to C++ Frame format (list of dicts).
        cpp_frames = [
            {"time": float(fd.time), "weights": dict(fd.weights)}
            for fd in blendshape_data
        ]
        result = _native.apply_emotion_fusion(
            cpp_frames, emo_segments, envelope,
            float(fps), int(frame_offset), float(cross_fade_sec)
        )
        # Apply results back to BlendshapeFrame objects in-place.
        total_modified = 0
        for i, fd in enumerate(blendshape_data):
            new_weights = result[i]["weights"]
            for name, val in new_weights.items():
                if name in fd.weights:
                    if abs(fd.weights[name] - val) > 1e-9:
                        fd.weights[name] = val
                        total_modified += 1
                else:
                    if abs(val) > 1e-9:
                        fd.weights[name] = val
                        total_modified += 1
        print(f"[EmotionFusion-Weights] Modified {total_modified} weight entries across "
              f"{total_frames} frames (C++ engine)")
        return
    except Exception as e:
        print(f"[EmotionFusion-Weights] C++ engine unavailable ({e}); "
              f"skipping emotion fusion")
        return


def _get_segment_emotion_id(seg) -> str:
    """Extract the emotion identifier string from a segment property."""
    emo = getattr(seg, "emotion", None)
    if emo is None:
        return "NEUTRAL"
    # EnumProperty with function items returns the identifier string
    if isinstance(emo, str):
        return emo
    # If it's an integer index, we need to convert (shouldn't happen at runtime)
    return str(emo)

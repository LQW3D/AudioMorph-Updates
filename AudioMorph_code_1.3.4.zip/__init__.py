# AudioMorph Blender Plugin
# Copyright (C) 2026 老齐 (Lao Qi). All rights reserved.
#
# This is proprietary commercial software. You may not copy, modify,
# distribute, or reverse-engineer any part of this software without the
# express written permission of the copyright holder. See the LICENSE
# file for the full license terms.
#
# This addon is distributed under the terms described in the LICENSE
# file in the addon root directory.

bl_info = {
    "name": "AudioMorph",
    "author": "老齐",
    "version": (1, 3, 4),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > AudioMorph",
    "description": "Generate facial animations from audio",
    "category": "Animation",
    "platforms": ['WINDOWS'],
}

import os
import sys

# Windows-only plugin: all shipped binaries (a2f_engine.pyd, pylibs/*) are
# win_amd64 builds. Fail with a clear message instead of an opaque
# ImportError/crash on other platforms.
if sys.platform != 'win32':
    raise RuntimeError(
        "AudioMorph is a Windows-only plugin (all binaries are "
        "win_amd64 builds). Please install and run it on Windows."
    )

# Fix Windows console encoding for Chinese characters in report/print output
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

_addon_dir = os.path.dirname(__file__)

# ============================================================================
# Device auto-detection (GPU/CPU)
# ----------------------------------------------------------------------------
# Strategy:
#   1. Read cached config from device_config.json (fast path, no detection)
#   2. If config missing, run detection (first startup, ~2-3s)
#   3. GPU (DirectML) is highest priority, CPU is fallback
#   4. No UI toggle needed - always use best available device
#
# For distribution: delete device_config.json before packaging.
# Each user's first startup will auto-detect their device.
# ============================================================================
from .core.device_detector import detect_device as _detect_device

_device_config = _detect_device()
_pylibs_dir_name = _device_config.get("pylibs_dir", "pylibs")
_pylibs_dir = os.path.join(_addon_dir, "deps", _pylibs_dir_name)
# CPU pylibs (for numpy/scipy/llvmlite dependencies, always needed)
_py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
if _py_version == "cp313":
    _pylibs_cpu_dir = os.path.join(_addon_dir, "deps", "pylibs_cp313")
elif _py_version == "cp311":
    _pylibs_cpu_dir = os.path.join(_addon_dir, "deps", "pylibs")
else:
    # Unreachable in practice: detect_device() above already raised for
    # unsupported Python versions. Keep the guard for defense in depth.
    raise RuntimeError(
        f"AudioMorph supports Blender 4.x (Python 3.11) and "
        f"Blender 5.x (Python 3.13) only; detected Python {_py_version}."
    )

# Add primary pylibs dir (GPU or CPU depending on detection) to sys.path
if _pylibs_dir not in sys.path:
    sys.path.insert(0, _pylibs_dir)

# Make the bundled ffmpeg.exe (in the bin/ folder) discoverable by librosa /
# audioread. These libraries look up ffmpeg on the system PATH; without it
# they cannot decode MP3 and other non-WAV formats. Prepend so it takes
# precedence over any system-installed ffmpeg.
_bin_dir = os.path.join(_addon_dir, "deps", "bin")
if os.path.isdir(_bin_dir):
    os.environ["PATH"] = _bin_dir + os.pathsep + os.environ.get("PATH", "")

# If using GPU (DML) pylibs, also need CPU pylibs for numpy/scipy/llvmlite
if _pylibs_dir != _pylibs_cpu_dir and _pylibs_cpu_dir not in sys.path:
    sys.path.append(_pylibs_cpu_dir)

# Register ONNX Runtime native DLL path (Windows requires explicit DLL search dirs)
_ort_capi_dir = os.path.join(_pylibs_dir, "onnxruntime", "capi")
if os.path.isdir(_ort_capi_dir) and hasattr(os, "add_dll_directory"):
    os.add_dll_directory(_ort_capi_dir)

# Register other native library paths (scipy.libs, llvmlite.libs, numpy.libs)
# These are always in CPU pylibs dir
for _libs_subdir in ("numpy.libs", "scipy.libs", "llvmlite.libs"):
    _libs_dir = os.path.join(_pylibs_cpu_dir, _libs_subdir)
    if os.path.isdir(_libs_dir) and hasattr(os, "add_dll_directory"):
        os.add_dll_directory(_libs_dir)

# Log device detection result
print(f"[AudioMorph] Device: {_device_config.get('device_type', 'cpu')} "
      f"| Provider: {_device_config.get('provider', 'CPUExecutionProvider')} "
      f"| onnxruntime: {_device_config.get('onnxruntime_version', 'unknown')}")

import bpy

# Properties
from .properties import (
    AudioMorphEmotionSegmentItem,
    AudioMorphProperties,
    AudioMorphDAZProperties,
    apply_defaults_to_scene,
)

# UI - Panels and navigation operators
from .ui.panel import (
    AUDIO2FACE_OT_set_page,
    AUDIO2FACE_PT_main_panel,
    AUDIO2FACE_PT_settings_panel,
    AUDIO2FACE_PT_post_adjust_panel,
)

# Object picker (DAZ rig eyedropper)
from .operators.pick_object import AUDIO2FACE_OT_pick_daz_rig

# Phoneme correction operators. The module-level helper functions in
# operators/phoneme.py are reused by daz/daz_phoneme.py, and
# AUDIO2FACE_OT_add_char_end_marker is invoked directly by the DAZ page UI.
# The other operators below are imported but not registered (the DAZ page has
# its own daz_* counterparts); they are kept here so the module stays loaded
# for the shared helper functions.
from .operators.phoneme import (
    AUDIO2FACE_OT_add_char_end_marker,
)

# Manual emotion segmentation operators (shared by the DAZ page)
from .operators.emotion_segments import (
    AUDIO2FACE_OT_emotion_segment_correct_frame,
    AUDIO2FACE_OT_emotion_segment_add,
    AUDIO2FACE_OT_emotion_segment_remove,
    AUDIO2FACE_OT_emotion_segment_clear,
)

# Preset template management + save defaults (used by the DAZ settings panel)
from .operators.preset import (
    AUDIO2FACE_OT_save_as_preset,
    AUDIO2FACE_OT_load_preset,
    AUDIO2FACE_OT_delete_preset,
)
from .operators.save_defaults import AUDIO2FACE_OT_save_defaults

# Auto-update operators + addon preferences (three-part update UI)
from .operators.update import (
    AUDIO2FACE_OT_update_confirm,
    AUDIO2FACE_OT_update_part,
    AUDIO2FACE_OT_open_preferences,
    AudioMorphPreferences,
)

# DAZ mode operators (independent module: drives DAZ FACS rigs via (fin)
# properties on the armature data block instead of mesh shape keys)
from .daz.daz_audio import AUDIO2FACE_OT_daz_import_audio
from .daz.daz_generate import AUDIO2FACE_OT_daz_generate
from .daz.daz_phoneme import (
    AUDIO2FACE_OT_daz_toggle_phoneme_correction,
    AUDIO2FACE_OT_daz_apply_phoneme_strength,
    AUDIO2FACE_OT_daz_apply_edited_text,
    AUDIO2FACE_OT_daz_open_text_editor,
    AUDIO2FACE_OT_daz_forced_align_text,
    AUDIO2FACE_OT_daz_fix_timestamps_from_markers,
)
from .daz.daz_postprocess import (
    AUDIO2FACE_OT_daz_apply_adjustments,
    AUDIO2FACE_OT_daz_set_frame_range,
    AUDIO2FACE_OT_daz_repair_lip_closure,
)


# ---------------------------------------------------------------------------
# License activation operators
# ---------------------------------------------------------------------------

class AUDIO2FACE_OT_copy_device_id(bpy.types.Operator):
    bl_idname = "audiomorph.copy_device_id"
    bl_label = "Copy Device ID"
    bl_description = "Copy the device ID to clipboard"

    def execute(self, context):
        from .core.license_manager import get_device_id
        dev_id = get_device_id()
        if dev_id:
            context.window_manager.clipboard = dev_id
            self.report({'INFO'}, "Device ID copied to clipboard")
        else:
            self.report({'WARNING'}, "No device ID available")
        return {'FINISHED'}


class AUDIO2FACE_OT_activate(bpy.types.Operator):
    bl_idname = "audiomorph.activate"
    bl_label = "Activate"
    bl_description = "Activate the plugin with an activation key"

    def execute(self, context):
        key = getattr(context.scene, "audiomorph_activation_key", "").strip()
        if not key:
            context.scene.audiomorph_activation_status = "Please enter activation key"
            self.report({'WARNING'}, "Please enter activation key")
            return {'CANCELLED'}

        from .core.license_manager import activate_online
        ok, msg = activate_online(key)
        if ok:
            context.scene.audiomorph_activation_status = ""
            context.scene.audiomorph_activation_key = ""
            self.report({'INFO'}, "Activation successful!")
        else:
            context.scene.audiomorph_activation_status = msg
            self.report({'ERROR'}, msg)
        return {'FINISHED'}


classes = [
    # Properties
    AudioMorphEmotionSegmentItem,
    AudioMorphProperties,
    AudioMorphDAZProperties,

    # UI navigation
    AUDIO2FACE_OT_set_page,
    AUDIO2FACE_OT_pick_daz_rig,

    # Phoneme correction: add_char_end_marker is reused by the DAZ page UI.
    AUDIO2FACE_OT_add_char_end_marker,

    # Manual emotion segmentation operators
    AUDIO2FACE_OT_emotion_segment_correct_frame,
    AUDIO2FACE_OT_emotion_segment_add,
    AUDIO2FACE_OT_emotion_segment_remove,
    AUDIO2FACE_OT_emotion_segment_clear,

    # Preset template management + save defaults (DAZ settings panel)
    AUDIO2FACE_OT_save_as_preset,
    AUDIO2FACE_OT_load_preset,
    AUDIO2FACE_OT_delete_preset,
    AUDIO2FACE_OT_save_defaults,

    # DAZ mode operators
    AUDIO2FACE_OT_daz_import_audio,
    AUDIO2FACE_OT_daz_generate,
    AUDIO2FACE_OT_daz_toggle_phoneme_correction,
    AUDIO2FACE_OT_daz_apply_phoneme_strength,
    AUDIO2FACE_OT_daz_apply_edited_text,
    AUDIO2FACE_OT_daz_open_text_editor,
    AUDIO2FACE_OT_daz_forced_align_text,
    AUDIO2FACE_OT_daz_fix_timestamps_from_markers,
    AUDIO2FACE_OT_daz_apply_adjustments,
    AUDIO2FACE_OT_daz_set_frame_range,
    AUDIO2FACE_OT_daz_repair_lip_closure,

    # License activation
    AUDIO2FACE_OT_copy_device_id,
    AUDIO2FACE_OT_activate,

    # Auto-update
    AUDIO2FACE_OT_update_confirm,
    AUDIO2FACE_OT_update_part,
    AUDIO2FACE_OT_open_preferences,
    AudioMorphPreferences,

    # UI Panels
    AUDIO2FACE_PT_main_panel,
    AUDIO2FACE_PT_settings_panel,
    AUDIO2FACE_PT_post_adjust_panel,
]


_applied_scene_id = None


# ----------------------------------------------------------------------------
# Frame rate
# ----------------------------------------------------------------------------
# The plugin does not keep its own fps property. The UI binds directly to
# scene.render.fps, and operators read context.scene.render.fps. This means
# the Animation page, the DAZ page, and the scene always share the exact
# same value with zero sync logic.


@bpy.app.handlers.persistent
def _on_file_loaded(*args):
    global _applied_scene_id
    _applied_scene_id = None
    try:
        for scene in bpy.data.scenes:
            if hasattr(scene, 'audiomorph_props'):
                apply_defaults_to_scene(scene)
                _applied_scene_id = id(scene)
    except Exception:
        pass


def _license_verify_timer():
    """Periodic online license re-verify.

    Refreshes the cloud token so a short-lived token + grace period do not
    lock out a paying user. It runs once right after startup (first_interval
    is small) and then as a low-frequency safety net every 24 hours.

    The actual network round-trip is delegated to a background thread
    (verify_online_periodic), so a slow/unreachable server never freezes the
    UI on startup. It also only verifies ONCE per 24h (cached timestamp), so
    launching Blender several times a day does not hit the license server each
    time. Silently skips when offline or not yet activated (the DLL's grace
    period covers brief outages)."""
    try:
        from .core import license_manager
        license_manager.verify_online_periodic()
    except Exception:
        pass  # transient error (offline / no token) -> grace period handles it
    return 24 * 3600.0  # reschedule as a low-frequency safety net


def register():
    global _applied_scene_id, _last_blender_lang

    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.audiomorph_props = bpy.props.PointerProperty(type=AudioMorphProperties)
    bpy.types.Scene.audiomorph_daz_props = bpy.props.PointerProperty(type=AudioMorphDAZProperties)

    # License activation scene properties
    bpy.types.Scene.audiomorph_activation_key = bpy.props.StringProperty(
        name="Activation Key",
        description="Enter the activation key received from the developer",
        default="",
    )
    bpy.types.Scene.audiomorph_activation_status = bpy.props.StringProperty(
        name="Activation Status",
        default="",
    )

    if _on_file_loaded not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_file_loaded)

    try:
        scene = bpy.context.scene
        if scene and hasattr(scene, 'audiomorph_props'):
            apply_defaults_to_scene(scene)
            _applied_scene_id = id(scene)
    except Exception:
        pass

    # Start language-change detection timer
    _last_blender_lang = _detect_blender_lang_raw()
    if not bpy.app.timers.is_registered(_check_lang_change_timer):
        bpy.app.timers.register(_check_lang_change_timer, first_interval=1.5)

    # Periodic online license verification (keep cloud token fresh).
    if not bpy.app.timers.is_registered(_license_verify_timer):
        # Verify once shortly after startup, then every 24h as a safety net.
        bpy.app.timers.register(_license_verify_timer, first_interval=0.5)


def unregister():
    if _on_file_loaded in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_file_loaded)

    # Stop language-change detection timer
    if bpy.app.timers.is_registered(_check_lang_change_timer):
        bpy.app.timers.unregister(_check_lang_change_timer)

    # Stop the periodic online license verification timer
    if bpy.app.timers.is_registered(_license_verify_timer):
        bpy.app.timers.unregister(_license_verify_timer)

    # Stop phoneme strength debounce timer if it is running.
    # This timer writes animation data on slider drag; without cleanup it
    # would fire once more after the addon is disabled, modifying the user's
    # scene with the plugin seemingly inactive.
    try:
        from .properties import _phoneme_debounce_timer
        if bpy.app.timers.is_registered(_phoneme_debounce_timer):
            bpy.app.timers.unregister(_phoneme_debounce_timer)
    except Exception:
        pass

    # Stop the update progress-polling timer if it is running.
    try:
        from .operators.update import _update_timer
        if bpy.app.timers.is_registered(_update_timer):
            bpy.app.timers.unregister(_update_timer)
    except Exception:
        pass

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.audiomorph_props
    del bpy.types.Scene.audiomorph_daz_props
    # Clean up the license activation properties registered in register().
    if hasattr(bpy.types.Scene, "audiomorph_activation_key"):
        del bpy.types.Scene.audiomorph_activation_key
    if hasattr(bpy.types.Scene, "audiomorph_activation_status"):
        del bpy.types.Scene.audiomorph_activation_status


# ============================================================================
# Language switch: deferred module reload and class re-registration
# ----------------------------------------------------------------------------
# The plugin follows Blender's UI language (bpy.app.translations.locale).
# When Blender's language changes, class-level t() calls (bl_label,
# bl_description, name=, description=, EnumProperty items) must be
# re-evaluated. This requires reloading all modules that define classes with
# t() calls, then re-registering the classes.
#
# A periodic timer checks Blender's language every 1.5s. If it changed,
# schedule_reload() is called, which defers the reload via a one-shot timer
# (unregistering classes during a UI draw would crash Blender).
# ============================================================================

_reload_pending = False
_last_blender_lang = None
_pending_lang = None  # Target language for the pending reload


def _detect_blender_lang():
    """Read Blender's effective UI language (locale).

    Delegates to i18n._detect_blender_lang so that locale normalization
    (e.g. 'zh_HANS' -> 'zh_CN') is handled consistently. Without
    normalization, equivalent locales like 'zh_HANS' and 'zh_HANS.UTF-8'
    would be considered different and trigger spurious reloads.
    """
    try:
        from .utils.i18n import _detect_blender_lang as _i18n_detect
        return _i18n_detect()
    except Exception:
        return None


def _detect_blender_lang_raw():
    """Read Blender's raw language preference (for change detection).

    Returns a tuple (locale, pref_language) so the timer can detect changes
    even when _detect_blender_lang() returns None (e.g. switching to English
    where locale becomes empty but preferences.view.language is 'en_US').
    """
    locale_val = None
    pref_lang = None
    try:
        locale_val = bpy.app.translations.locale
    except Exception:
        pass
    try:
        pref_lang = bpy.context.preferences.view.language
    except Exception:
        pass
    return (locale_val, pref_lang)


def _check_lang_change_timer():
    """Periodic timer: detect Blender language change and trigger reload."""
    global _last_blender_lang, _pending_lang

    # Use raw values for change detection so we catch transitions that
    # _detect_blender_lang() might miss (e.g. zh_HANS -> '' when switching
    # to English, where locale becomes empty).
    raw = _detect_blender_lang_raw()
    if _last_blender_lang is None:
        _last_blender_lang = raw
        return 1.5
    if raw != _last_blender_lang:
        _last_blender_lang = raw
        # Resolve the normalized target language for the override
        _pending_lang = _detect_blender_lang() or 'en_US'
        schedule_reload()
    return 1.5  # repeat every 1.5 seconds


def _do_reload_timer():
    """Timer callback: performs the actual reload."""
    global _reload_pending
    _reload_pending = False
    reload_and_re_register()
    return None  # one-shot timer


def schedule_reload():
    """Schedule a deferred reload.

    Uses a flag to prevent multiple timer registrations if the language
    changes rapidly. Only the final language takes effect because
    module reload re-reads Blender's current language.
    """
    global _reload_pending
    if not _reload_pending:
        _reload_pending = True
        if not bpy.app.timers.is_registered(_do_reload_timer):
            bpy.app.timers.register(_do_reload_timer, first_interval=0.01)


def reload_and_re_register():
    """Reload all plugin modules and re-register classes to update translations.

    Steps:
    1. Unregister all classes and remove Scene pointer properties
    2. Reload all modules that contain class-level t() calls (19 modules)
    3. Re-import all classes from reloaded modules (updates module bindings)
    4. Rebuild the classes list with new class objects
    5. Re-register all classes and Scene pointer properties

    Module reload order matters: properties first (other modules import from
    it), then core/operator/daz modules, then ui.panel last.
    """
    import importlib
    import traceback

    global classes, apply_defaults_to_scene, _last_blender_lang, _pending_lang

    print("[AudioMorph] Reloading modules for language switch...")

    # Backup current classes so we can attempt rollback on failure.
    # If reload fails mid-way, the UI would disappear; re-registering the
    # old classes at least restores the previous working state.
    _old_classes = list(classes)
    _rollback_succeeded = False

    try:
        # 1. Unregister all classes
        for cls in reversed(classes):
            try:
                bpy.utils.unregister_class(cls)
            except Exception as e:
                print(f"[AudioMorph] Warning: unregister "
                      f"{getattr(cls, '__name__', cls)}: {e}")

        # Remove Scene pointer properties
        try:
            del bpy.types.Scene.audiomorph_props
        except Exception:
            pass
        try:
            del bpy.types.Scene.audiomorph_daz_props
        except Exception:
            pass

        # 2. Reload modules in dependency order
        # -- i18n (must be first: properties imports t() from it) --
        from .utils import i18n as _i18n_mod
        importlib.reload(_i18n_mod)

        # Set the language override so class-level t() calls during the
        # subsequent module reloads use the correct language. This prevents
        # a race condition where bpy.app.translations.locale hasn't fully
        # updated yet, causing t() to fall back to the old language.
        if _pending_lang:
            _i18n_mod._RELOAD_LANG_OVERRIDE = _pending_lang
            print(f"[AudioMorph] Language override set to: {_pending_lang}")

        # -- properties (imported by almost everything) --
        from . import properties as _properties_mod
        importlib.reload(_properties_mod)

        # -- core modules with class-level t() calls --
        # (a2f_rig / a2f_weights / a2f_baker / setup / landmarks were removed
        #  with the binding page.)

        # -- operator modules (generate / phoneme are kept because the DAZ
        #    page reuses their helper functions) --
        from .operators import pick_object as _pick_object_mod
        importlib.reload(_pick_object_mod)
        from .operators import phoneme as _phoneme_mod
        importlib.reload(_phoneme_mod)
        from .operators import emotion_segments as _emotion_segments_mod
        importlib.reload(_emotion_segments_mod)
        from .operators import generate as _generate_mod
        importlib.reload(_generate_mod)
        from .operators import preset as _preset_mod
        importlib.reload(_preset_mod)
        from .operators import save_defaults as _save_defaults_mod
        importlib.reload(_save_defaults_mod)
        from .operators import update as _update_mod
        importlib.reload(_update_mod)

        # -- daz modules --
        from .daz import daz_audio as _daz_audio_mod
        importlib.reload(_daz_audio_mod)
        from .daz import daz_generate as _daz_generate_mod
        importlib.reload(_daz_generate_mod)
        from .daz import daz_phoneme as _daz_phoneme_mod
        importlib.reload(_daz_phoneme_mod)
        from .daz import daz_postprocess as _daz_postprocess_mod
        importlib.reload(_daz_postprocess_mod)

        # -- ui panel (last, imports from properties/operators/core/daz) --
        from .ui import panel as _panel_mod
        importlib.reload(_panel_mod)

        # 3. Re-import all classes (updates module-level bindings)
        from .properties import (
            AudioMorphEmotionSegmentItem,
            AudioMorphProperties, AudioMorphDAZProperties,
            apply_defaults_to_scene,
        )

        from .ui.panel import (
            AUDIO2FACE_OT_set_page,
            AUDIO2FACE_PT_main_panel, AUDIO2FACE_PT_settings_panel,
            AUDIO2FACE_PT_post_adjust_panel,
        )

        from .operators.pick_object import AUDIO2FACE_OT_pick_daz_rig
        from .operators.phoneme import AUDIO2FACE_OT_add_char_end_marker
        from .operators.emotion_segments import (
            AUDIO2FACE_OT_emotion_segment_correct_frame,
            AUDIO2FACE_OT_emotion_segment_add,
            AUDIO2FACE_OT_emotion_segment_remove,
            AUDIO2FACE_OT_emotion_segment_clear,
        )
        from .operators.preset import (
            AUDIO2FACE_OT_save_as_preset,
            AUDIO2FACE_OT_load_preset,
            AUDIO2FACE_OT_delete_preset,
        )
        from .operators.save_defaults import AUDIO2FACE_OT_save_defaults
        from .operators.update import (
            AUDIO2FACE_OT_update_confirm,
            AUDIO2FACE_OT_update_part,
            AUDIO2FACE_OT_open_preferences,
            AudioMorphPreferences,
        )

        from .daz.daz_audio import AUDIO2FACE_OT_daz_import_audio
        from .daz.daz_generate import AUDIO2FACE_OT_daz_generate
        from .daz.daz_phoneme import (
            AUDIO2FACE_OT_daz_toggle_phoneme_correction,
            AUDIO2FACE_OT_daz_apply_phoneme_strength,
            AUDIO2FACE_OT_daz_apply_edited_text,
            AUDIO2FACE_OT_daz_open_text_editor,
            AUDIO2FACE_OT_daz_forced_align_text,
            AUDIO2FACE_OT_daz_fix_timestamps_from_markers,
        )
        from .daz.daz_postprocess import (
            AUDIO2FACE_OT_daz_apply_adjustments,
            AUDIO2FACE_OT_daz_set_frame_range,
            AUDIO2FACE_OT_daz_repair_lip_closure,
        )

        # 4. Rebuild classes list with new class objects
        classes = [
            # Properties
            AudioMorphEmotionSegmentItem,
            AudioMorphProperties, AudioMorphDAZProperties,

            # UI navigation
            AUDIO2FACE_OT_set_page, AUDIO2FACE_OT_pick_daz_rig,

            # Phoneme correction: add_char_end_marker is reused by the DAZ page.
            AUDIO2FACE_OT_add_char_end_marker,

            # Manual emotion segmentation operators
            AUDIO2FACE_OT_emotion_segment_correct_frame,
            AUDIO2FACE_OT_emotion_segment_add,
            AUDIO2FACE_OT_emotion_segment_remove,
            AUDIO2FACE_OT_emotion_segment_clear,

            # Preset template management + save defaults (DAZ settings panel)
            AUDIO2FACE_OT_save_as_preset,
            AUDIO2FACE_OT_load_preset,
            AUDIO2FACE_OT_delete_preset,
            AUDIO2FACE_OT_save_defaults,

            # DAZ mode operators
            AUDIO2FACE_OT_daz_import_audio, AUDIO2FACE_OT_daz_generate,
            AUDIO2FACE_OT_daz_toggle_phoneme_correction,
            AUDIO2FACE_OT_daz_apply_phoneme_strength,
            AUDIO2FACE_OT_daz_apply_edited_text,
            AUDIO2FACE_OT_daz_open_text_editor,
            AUDIO2FACE_OT_daz_forced_align_text,
            AUDIO2FACE_OT_daz_fix_timestamps_from_markers,
            AUDIO2FACE_OT_daz_apply_adjustments,
            AUDIO2FACE_OT_daz_set_frame_range,
            AUDIO2FACE_OT_daz_repair_lip_closure,

            # License activation (must stay in sync with the main classes list)
            AUDIO2FACE_OT_copy_device_id,
            AUDIO2FACE_OT_activate,

            # Auto-update
            AUDIO2FACE_OT_update_confirm,
            AUDIO2FACE_OT_update_part,
            AUDIO2FACE_OT_open_preferences,
            AudioMorphPreferences,

            # UI Panels
            AUDIO2FACE_PT_main_panel,
            AUDIO2FACE_PT_settings_panel,
            AUDIO2FACE_PT_post_adjust_panel,
        ]

        # 5. Re-register all classes
        for cls in classes:
            bpy.utils.register_class(cls)
        bpy.types.Scene.audiomorph_props = bpy.props.PointerProperty(
            type=AudioMorphProperties)
        bpy.types.Scene.audiomorph_daz_props = bpy.props.PointerProperty(
            type=AudioMorphDAZProperties)

        # Apply defaults to current scene
        try:
            scene = bpy.context.scene
            if scene and hasattr(scene, 'audiomorph_props'):
                apply_defaults_to_scene(scene)
        except Exception:
            pass

        # Clear the language override now that all modules are reloaded.
        # Runtime t() calls will use dynamic detection again.
        try:
            from .utils import i18n as _i18n_mod_clear
            _i18n_mod_clear._RELOAD_LANG_OVERRIDE = None
        except Exception:
            pass
        _pending_lang = None

        # Update cached language so the timer doesn't re-trigger reload
        _last_blender_lang = _detect_blender_lang_raw()

        print("[AudioMorph] Language switch complete.")

    except Exception as e:
        print(f"[AudioMorph] FATAL: Language reload failed: {e}")
        traceback.print_exc()
        # Attempt rollback: re-register the previous classes so the UI is
        # restored to its pre-reload working state. If rollback itself fails,
        # the user will need to restart Blender (we print a clear message).
        try:
            # Ensure Scene properties are removed before re-registering
            try:
                del bpy.types.Scene.audiomorph_props
            except Exception:
                pass
            try:
                del bpy.types.Scene.audiomorph_daz_props
            except Exception:
                pass
            # Re-register any class that is not currently registered.
            # Use a module-level name check: registered classes appear in
            # bpy.types.*; a class whose bl_idname attribute is missing from
            # the registry needs re-registration.
            for cls in _old_classes:
                try:
                    bpy.utils.register_class(cls)
                except Exception as reg_e:
                    # Class may still be registered (unregister didn't reach it)
                    if "already" not in str(reg_e).lower():
                        print(f"[AudioMorph] Rollback: could not re-register "
                              f"{getattr(cls, '__name__', cls)}: {reg_e}")
            # Restore Scene pointer properties
            from .properties import AudioMorphProperties, AudioMorphDAZProperties
            bpy.types.Scene.audiomorph_props = bpy.props.PointerProperty(
                type=AudioMorphProperties)
            bpy.types.Scene.audiomorph_daz_props = bpy.props.PointerProperty(
                type=AudioMorphDAZProperties)
            classes = _old_classes
            _rollback_succeeded = True
            print("[AudioMorph] Rollback to previous state succeeded.")
        except Exception as rollback_e:
            print(f"[AudioMorph] Rollback FAILED: {rollback_e}")
            print("[AudioMorph] Please RESTART Blender to recover the plugin.")

"""AudioToFace native engine - ctypes glue layer.

Loads the Python-version-independent native DLL (a2f_engine.dll) and exposes
exactly the same API surface the old a2f_engine.pyd provided, so the rest of
the addon's Python code is untouched. Structured data crosses the boundary as
in-memory JSON; large arrays (numpy) pass by pointer (zero copy).

The DLL export names are obfuscated (a2f_engine.def); the mapping lives here.
"""
import ctypes
import json
import os

import numpy as np

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_DLL_PATH = os.path.join(_ADDON_DIR, "a2f_engine.dll")

_dll = ctypes.CDLL(_DLL_PATH)

_c_int = ctypes.c_int
_c_longlong = ctypes.c_longlong
_c_char_p = ctypes.c_char_p
_c_void_p = ctypes.c_void_p
_c_double = ctypes.c_double
_c_float_p = ctypes.POINTER(ctypes.c_float)
_c_double_p = ctypes.POINTER(ctypes.c_double)
_c_int_p = ctypes.POINTER(ctypes.c_int)

# --- declare the obfuscated exports ----------------------------------------
_dll._zX7q1.argtypes = [_c_int, _c_char_p, _c_char_p, _c_int]      # a2f_call
_dll._zX7q1.restype = _c_int
_dll._zX7q2.argtypes = [_c_float_p, _c_int, _c_float_p, _c_int, _c_char_p,
                        _c_int_p, _c_int, _c_double_p, _c_double_p,
                        _c_int_p, _c_int_p, _c_int_p, _c_int]      # solver_create
_dll._zX7q2.restype = _c_longlong
_dll._zX7q3.argtypes = [_c_longlong, _c_float_p, _c_int, _c_float_p]  # solver_solve
_dll._zX7q3.restype = _c_int
_dll._zX7q4.argtypes = [_c_longlong]                                 # solver_reset
_dll._zX7q4.restype = None
_dll._zX7q5.argtypes = [_c_longlong]                                 # solver_delete
_dll._zX7q5.restype = None
_dll._zX7q6.argtypes = [_c_float_p, _c_int, _c_int, _c_float_p, _c_int,
                        _c_float_p, ctypes.POINTER(ctypes.c_double)]   # pca_reconstruct
_dll._zX7q6.restype = _c_int
_dll._zX7q7.argtypes = [_c_double_p, _c_int, _c_int, _c_int_p, _c_int,
                        _c_int, _c_int_p, _c_int_p]                  # ctc_align
_dll._zX7q7.restype = _c_int
_dll._zX7q8.argtypes = [_c_double_p, _c_int, _c_int, _c_int_p, _c_int,
                        _c_int_p, _c_char_p, _c_double, _c_char_p, _c_int]  # build_char_ts
_dll._zX7q8.restype = _c_int
_dll._zX7q9.argtypes = [_c_float_p, _c_int, _c_double, _c_int,
                        _c_char_p, _c_int]                           # detect_silence
_dll._zX7q9.restype = _c_int

# Opcodes (must match a2f_engine.cpp).
_OP = {
    "get_emotion_template": 1,
    "split_pinyin": 2,
    "build_weight_multipliers": 3,
    "build_postprocess_multipliers": 4,
    "map_sdk_output": 5,
    "apply_prediction_delay": 6,
    "apply_silence_suppression": 7,
    "apply_eye_controls": 8,
    "correct_phoneme_frames": 9,
    "apply_emotion_fusion": 10,
    "repair_lip_closure": 11,
    "build_daz_mapping": 12,
    "daz_write_values": 13,
    "clamp_daz_prop": 14,
    "compensate_mouth_close": 15,
    "build_faceit_mapping": 16,
    "adapt_faceit_weights": 17,
    "is_faceit_down_direction": 18,
    "faceit_write_values": 19,
    "gaussian_smooth": 20,
    "trim_char_to_speech": 21,
    "trim_segment_to_speech_static": 22,
    "redistribute_timestamps_core": 23,
    "get_device_id": 24,
    "check_activated": 25,
    "activate": 26,
    "deactivate": 27,
    "verify_license": 28,
    "convert_arkit_to_daz": 29,
    "convert_arkit_to_faceit": 30,
    "write_values_batch": 31,
    "map_sdk_output_batch": 32,
    "daz_clamp_batch": 33,
    "verify_cloud_token": 34,
    "get_cloud_token": 35,
}

_OUT_BUF = ctypes.create_string_buffer(1 << 20)  # 1 MiB result buffer


def _jsonable(obj):
    """Recursively convert numpy scalars/arrays to JSON-native types."""
    if isinstance(obj, (np.floating, np.integer)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (list, tuple)):
        return [_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _jsonable(v) for k, v in obj.items()}
    return obj


def _call(op_name, *args):
    """Invoke the JSON main interface."""
    payload = json.dumps(_jsonable(list(args)), ensure_ascii=False).encode("utf-8")
    # The output for frame-array ops (silence suppression, eye controls,
    # phoneme correction, emotion fusion, lip repair, ...) is itself the full
    # frame list, which can be several MB for a long clip. A fixed 1 MiB
    # buffer overflowed and made every such op return A2F_ERR_ARGS (-2),
    # silently skipping the correction. Size the output buffer from the
    # request so it always fits (output is never hugely larger than the input).
    buf_size = max(1 << 22, len(payload) * 3 + 131072)
    buf = ctypes.create_string_buffer(buf_size)
    rc = _dll._zX7q1(_OP[op_name], payload, buf, len(buf))
    if rc == -5:
        raise LicenseError(
            "AudioToFace is not activated. Please activate it in the "
            "preferences to use this feature.")
    if rc != 0:
        raise RuntimeError("a2f_engine op %r failed (rc=%d)" % (op_name, rc))
    s = buf.value.decode("utf-8")
    return json.loads(s) if s else None


class LicenseError(RuntimeError):
    """Raised when a protected engine op is refused due to an invalid license."""


# ---------------------------------------------------------------------------
# Public API (identical names/signatures to the old .pyd)
# ---------------------------------------------------------------------------

def get_emotion_template(emotion_id):
    return _call("get_emotion_template", emotion_id)


def split_pinyin(py, start, end):
    return _call("split_pinyin", py, float(start), float(end))


def build_weight_multipliers(params):
    return _call("build_weight_multipliers", params)


def build_postprocess_multipliers(params):
    return _call("build_postprocess_multipliers", params)


def map_sdk_output(raw_weights, multipliers):
    return _call("map_sdk_output", list(raw_weights), multipliers)


def map_sdk_output_batch(raw_frames, multipliers):
    """Convert a whole clip of 68-channel SDK raw frames to named ARKit
    weights in one engine call. raw_frames is a list of the per-frame raw
    weight lists/arrays (one 68-float vector per frame). multipliers is the
    ARKit multiplier dict. Returns a list (same order as input) of
    {arkit_name: weight} dicts. Replaces the per-frame map_sdk_output round
    trip that dominated the generation path.
    """
    return _call("map_sdk_output_batch",
                 [list(r) for r in raw_frames], multipliers)


def daz_clamp_batch(arkit_name, prop_name, values, allow_negative=False):
    """Clamp a whole series of values for one (arkit, prop) pair in a single
    engine call. values is a list of the Object property values to clamp.
    Returns a list (same order as input) of the clamped values. Replaces the
    per-keyframe clamp_daz_prop round trip that dominated "Apply Adjustments".
    """
    return _call("daz_clamp_batch", arkit_name or '', prop_name,
                 [float(v) for v in values], bool(allow_negative))


def apply_prediction_delay(frames, delay_seconds):
    return _call("apply_prediction_delay", frames, float(delay_seconds))


def apply_silence_suppression(frames, rms, sr, hop, fps):
    return _call("apply_silence_suppression", frames, list(rms),
                 float(sr), int(hop), float(fps))


def apply_eye_controls(frames, params, boundary_times):
    return _call("apply_eye_controls", frames, params, list(boundary_times))


def correct_phoneme_frames(frames, fps, phonemes, correction_strength, frame_offset):
    return _call("correct_phoneme_frames", frames, int(fps), phonemes,
                 float(correction_strength), int(frame_offset))


def apply_emotion_fusion(frames, segments, envelope, fps, frame_offset, cross_fade_sec):
    return _call("apply_emotion_fusion", frames, segments, list(envelope),
                 float(fps), int(frame_offset), float(cross_fade_sec))


def repair_lip_closure(frames, phonemes, fps, frame_offset, window_frames,
                       frame_range_start, frame_range_end):
    res = _call("repair_lip_closure", frames, phonemes, int(fps), int(frame_offset),
                int(window_frames), int(frame_range_start), int(frame_range_end))
    return res[0], res[1]


def build_daz_mapping(existing_props, gen):
    return _call("build_daz_mapping", list(existing_props), int(gen))


def daz_write_values(weights, mapping):
    return _call("daz_write_values", weights, mapping)


def clamp_daz_prop(arkit_name, prop_name, value, allow_negative):
    return _call("clamp_daz_prop", arkit_name or "", prop_name,
                 float(value), bool(allow_negative))


def compensate_mouth_close(weight, jaw_open):
    return _call("compensate_mouth_close", float(weight), float(jaw_open))


def build_faceit_mapping(existing_bones):
    return _call("build_faceit_mapping", list(existing_bones))


def adapt_faceit_weights(weights):
    return _call("adapt_faceit_weights", weights)


def is_faceit_down_direction(arkit):
    return _call("is_faceit_down_direction", arkit)


def faceit_write_values(weights, mapping, overrides):
    return _call("faceit_write_values", weights, mapping, overrides)


def gaussian_smooth(values, smoothing):
    return _call("gaussian_smooth", list(values), float(smoothing))


def trim_char_to_speech(char_start, char_end, silence_regions):
    r = _call("trim_char_to_speech", float(char_start), float(char_end),
              [[float(a), float(b)] for a, b in silence_regions])
    return r[0], r[1]


def trim_segment_to_speech_static(seg_start, seg_end, silence_regions):
    r = _call("trim_segment_to_speech_static", float(seg_start), float(seg_end),
              [[float(a), float(b)] for a, b in silence_regions])
    return r[0], r[1]


def redistribute_timestamps_core(chars, speech_segments, silence_regions, audio_duration):
    return _call("redistribute_timestamps_core", list(chars),
                 [[float(a), float(b)] for a, b in speech_segments],
                 [[float(a), float(b)] for a, b in silence_regions],
                 float(audio_duration))


# --- license (JSON interface) ---
def get_device_id():
    return _call("get_device_id")


def check_activated(device_id):
    return _call("check_activated", device_id)


def activate(key_b64, device_id):
    return _call("activate", key_b64, device_id)


def deactivate():
    _call("deactivate")


def verify_license():
    return _call("verify_license")


def verify_cloud_token(token_b64, device_id, expiry_ts):
    """Store/verify a cloud-issued token (base64 RSA signature over
    "device_id|expiry_ts"). Returns 1 if valid for this device, else 0."""
    return _call("verify_cloud_token", token_b64, device_id, int(expiry_ts))


def get_cloud_token():
    """Return the locally-stored cloud token as a dict
    {token, device_id, expiry_ts, last_verified}, or None if none stored."""
    return _call("get_cloud_token")


def convert_arkit_to_daz(weights, mapping):
    return _call("convert_arkit_to_daz", weights, mapping)


def convert_arkit_to_faceit(weights, mapping):
    return _call("convert_arkit_to_faceit", weights, mapping)


def write_values_batch(mode, frames, mapping, overrides=None):
    """Convert a whole clip's per-frame weights to rig values in one engine call.

    mode is "daz" or "faceit". frames is a list of objects/dicts exposing a
    'weights' mapping (BlendshapeFrame or plain dict). mapping is the ARKit ->
    rig mapping table. overrides is the Faceit divisor-override dict (optional).

    Returns a list (one entry per frame, same order as input) of
    {rig_prop: value} dicts. This replaces the per-frame JSON round trip of
    daz_write_values/faceit_write_values, which dominated the realtime
    phoneme and generation write paths.
    """
    batch = [{'weights': f.weights if hasattr(f, 'weights') else f['weights']}
             for f in frames]
    return _call("write_values_batch", mode, batch, mapping, overrides or {})


# --- pointer interfaces (numpy zero-copy) ---
def pca_reconstruct(coeffs, basis, mean):
    c = np.ascontiguousarray(coeffs, dtype=np.float32)
    b = np.ascontiguousarray(basis, dtype=np.float32)
    m = np.ascontiguousarray(mean, dtype=np.float32)
    n_frames, n_shapes = c.shape
    d = b.shape[1]
    out = np.empty(n_frames * d, dtype=np.float64)
    rc = _dll._zX7q6(
        c.ctypes.data_as(_c_float_p), n_frames, n_shapes,
        b.ctypes.data_as(_c_float_p), d,
        m.ctypes.data_as(_c_float_p),
        out.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
    if rc != 0:
        raise RuntimeError("pca_reconstruct failed (rc=%d)" % rc)
    return out.reshape(n_frames, d).tolist()


def detect_silence_regions(audio, sr, frame_ms):
    a = np.ascontiguousarray(audio, dtype=np.float32)
    buf = ctypes.create_string_buffer(1 << 16)
    rc = _dll._zX7q9(a.ctypes.data_as(_c_float_p), int(a.size),
                     float(sr), int(frame_ms), buf, len(buf))
    if rc != 0:
        raise RuntimeError("detect_silence_regions failed (rc=%d)" % rc)
    res = json.loads(buf.value.decode("utf-8"))
    return [(float(x[0]), float(x[1])) for x in res]


def ctc_forced_align(log_probs, targets, blank_id=0):
    lp = np.ascontiguousarray(log_probs, dtype=np.float64)
    T, V = lp.shape
    tg = np.ascontiguousarray(targets, dtype=np.int32)
    N = len(targets)
    out_frames = np.empty(N, dtype=np.int32)
    out_path = np.empty(T, dtype=np.int32)
    rc = _dll._zX7q7(
        lp.ctypes.data_as(_c_double_p), T, V,
        tg.ctypes.data_as(_c_int_p), N, int(blank_id),
        out_frames.ctypes.data_as(_c_int_p),
        out_path.ctypes.data_as(_c_int_p))
    if rc != 0:
        raise RuntimeError("ctc_forced_align failed (rc=%d)" % rc)
    return out_frames.tolist(), out_path.tolist()


def build_char_timestamps_ctc(log_probs, token_frames, targets, chars, audio_duration):
    lp = np.ascontiguousarray(log_probs, dtype=np.float64)
    T, V = lp.shape
    tf = np.ascontiguousarray(token_frames, dtype=np.int32)
    N = len(targets)
    tg = np.ascontiguousarray(targets, dtype=np.int32)
    chars_json = json.dumps(list(chars), ensure_ascii=False).encode("utf-8")
    buf = ctypes.create_string_buffer(1 << 20)
    rc = _dll._zX7q8(
        lp.ctypes.data_as(_c_double_p), T, V,
        tf.ctypes.data_as(_c_int_p), N,
        tg.ctypes.data_as(_c_int_p),
        chars_json, float(audio_duration), buf, len(buf))
    if rc != 0:
        raise RuntimeError("build_char_timestamps_ctc failed (rc=%d)" % rc)
    return json.loads(buf.value.decode("utf-8"))


def solver_create(neutral_flat, deltas_flat, params, active, mult, off,
                  sym_groups, cancel_groups, frontal_mask):
    neutral = np.ascontiguousarray(neutral_flat, dtype=np.float32)
    deltas = np.ascontiguousarray(deltas_flat, dtype=np.float32)
    # neutral: (V*3), deltas: (V*3*P) -> P = deltas.size / neutral.size
    n_verts = neutral.size // 3
    n_poses = deltas.size // neutral.size if neutral.size else 0
    if n_poses <= 0:
        n_poses = int(params.get("numPoses", 0))
    active_arr = np.ascontiguousarray(active, dtype=np.int32)
    mult_arr = np.ascontiguousarray(mult, dtype=np.float64)
    off_arr = np.ascontiguousarray(off, dtype=np.float64)
    sym_arr = np.ascontiguousarray(sym_groups, dtype=np.int32)
    cancel_arr = np.ascontiguousarray(cancel_groups, dtype=np.int32)
    mask_arr = np.ascontiguousarray(frontal_mask, dtype=np.int32) if len(frontal_mask) else None

    # params: {l2,temporal,l1,sym,template_bb}
    p = {"l2": float(params.get("l2", 0.2)),
         "temporal": float(params.get("temporal", 0.3)),
         "l1": float(params.get("l1", 0.2)),
         "sym": float(params.get("sym", 100.0)),
         "template_bb": float(params.get("template_bb", 54.85))}
    params_json = json.dumps(p).encode("utf-8")
    handle = _dll._zX7q2(
        neutral.ctypes.data_as(_c_float_p), n_verts,
        deltas.ctypes.data_as(_c_float_p), n_poses,
        params_json,
        active_arr.ctypes.data_as(_c_int_p), len(active_arr),
        mult_arr.ctypes.data_as(_c_double_p),
        off_arr.ctypes.data_as(_c_double_p),
        sym_arr.ctypes.data_as(_c_int_p),
        cancel_arr.ctypes.data_as(_c_int_p),
        mask_arr.ctypes.data_as(_c_int_p) if mask_arr is not None else None,
        len(mask_arr) if mask_arr is not None else 0)
    if handle == 0:
        raise RuntimeError("solver_create failed (A not positive definite?)")
    return int(handle)


def solver_solve(handle, target_vertices, n_frames):
    tgt = np.ascontiguousarray(target_vertices, dtype=np.float32)
    # Upper-bound buffer; the DLL returns the actual pose count.
    out = np.empty(n_frames * 64, dtype=np.float32)
    n_poses = _dll._zX7q3(handle, tgt.ctypes.data_as(_c_float_p), int(n_frames),
                          out.ctypes.data_as(_c_float_p))
    if n_poses <= 0:
        raise RuntimeError("solver_solve failed (rc=%d)" % n_poses)
    # pyd returned a bytes buffer of n_frames*n_poses floats.
    return out[:int(n_frames) * int(n_poses)].tobytes()


def solver_reset(handle):
    _dll._zX7q4(handle)


def solver_delete(handle):
    _dll._zX7q5(handle)

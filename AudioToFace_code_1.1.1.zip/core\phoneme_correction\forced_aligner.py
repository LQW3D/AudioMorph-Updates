"""CTC forced alignment for correcting ASR text-timestamp mismatches.

When the SenseVoice ASR misses characters in fast songs, the user edits the
text in the UI. The existing "Apply Edited Text" button reuses the original
timestamps (1:1 if char count matches, proportional fallback otherwise), but
this fails when characters were dropped — the timestamps no longer line up
with the actual speech.

This module solves the problem by running the SenseVoice ONNX model directly
via ONNX Runtime (not through sherpa_onnx) to extract the CTC emission
matrix, then performing Viterbi forced alignment between the user-corrected
text and the audio. The result is a per-character timestamp sequence that
precisely matches the corrected text to the audio.

Pipeline:
1. Extract 80-dim log-mel fbank features (kaldi-compatible: 25ms frame,
   10ms shift, Povey window, HTK mel scale, snip-edges=True)
2. LFR stacking (window=7, shift=6) -> 560-dim
3. CMVN normalization: (x + neg_mean) * inv_stddev
4. Run ONNX model -> logits [T, 25055]
5. log_softmax -> log probabilities
6. Viterbi forced alignment: find best path through [blank, t1, blank, t2, ...]
7. Convert frame indices to timestamps

Subprocess mode:
    Blender 5.0 ships with onnxruntime 1.19.2, which conflicts with
    sherpa-onnx 1.13.4 (requires 1.27+). In Blender 5.0 or when DML
    onnxruntime is loaded in the main process, this module runs in a
    subprocess via forced_align_worker.py to avoid the DLL conflict.
    This mirrors the LocalASR._USE_SUBPROCESS pattern.
"""

import os
import sys
import json
import tempfile
import subprocess
import logging
from typing import List, Dict, Optional, Tuple

import numpy as np

try:
    import bpy
    BLENDER_VERSION = bpy.app.version
except ImportError:
    BLENDER_VERSION = (0, 0, 0)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Subprocess detection (mirror local_asr._USE_SUBPROCESS)
# ---------------------------------------------------------------------------
_USE_SUBPROCESS = False

if BLENDER_VERSION[0] == 5 and BLENDER_VERSION[1] == 0:
    _USE_SUBPROCESS = True
else:
    try:
        # device_config.json lives in Blender's user config dir since the
        # device-detection migration (see core/device_detector._get_config_path).
        _config_path = os.environ.get("A2F_DEVICE_CONFIG")
        if not _config_path:
            try:
                import bpy as _bpy
                _cfg_dir = _bpy.utils.user_resource('CONFIG')
                if _cfg_dir:
                    _config_path = os.path.join(_cfg_dir, "device_config.json")
            except Exception:
                pass
        if not _config_path:
            _config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                "device_config.json")
        with open(_config_path, "r", encoding="utf-8") as _f:
            _cfg = json.load(_f)
        _py_ver = f"cp{sys.version_info.major}{sys.version_info.minor}"
        if _cfg.get("python_version") == _py_ver and _cfg.get("provider") == "DmlExecutionProvider":
            _USE_SUBPROCESS = True
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Constants (from SenseVoice model metadata)
# ---------------------------------------------------------------------------
LFR_WINDOW = 7
LFR_SHIFT = 6
FRAME_LENGTH_MS = 25
FRAME_SHIFT_MS = 10
SAMPLE_RATE = 16000
NUM_MEL_BINS = 80
NFFT = 512
BLANK_ID = 0

# SenseVoice prepends 4 control tokens before the actual CTC frames:
#   <|lang|>, <|emotion|>, <|event|>, <|withitn|/|noitn|>
# These consume the first 4 output frames and must be skipped when
# converting alignment frame indices to audio timestamps.
NUM_PREFIX_FRAMES = 4

# Language IDs (from model metadata)
LANG_ZH = 3
# Text norm IDs (from model metadata)
TEXT_NORM_WITH_ITN = 14


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------
def _get_addon_root() -> str:
    """Return absolute path to the addon root directory."""
    # core/phoneme_correction/forced_aligner.py -> addon root
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _get_model_path() -> str:
    return os.path.join(_get_addon_root(), "models", "asr_local", "model.int8.onnx")


def _get_tokens_path() -> str:
    return os.path.join(_get_addon_root(), "models", "asr_local", "tokens.txt")


def _get_cpu_pylibs_dir() -> str:
    """Return the CPU pylibs directory (contains onnxruntime 1.27+)."""
    addon_root = _get_addon_root()
    py_ver = f"cp{sys.version_info.major}{sys.version_info.minor}"
    if py_ver == "cp313":
        return os.path.join(addon_root, "pylibs_cp313")
    return os.path.join(addon_root, "pylibs")


# ---------------------------------------------------------------------------
# Token loading and text-to-token conversion
# ---------------------------------------------------------------------------
def load_tokens(path: str) -> Tuple[Dict[int, str], Dict[str, int]]:
    """Load tokens.txt -> (id2token, token2id)."""
    id2token = {}
    token2id = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.rsplit(" ", 1)
            if len(parts) != 2:
                continue
            tok, idx = parts[0], int(parts[1])
            id2token[idx] = tok
            token2id[tok] = idx
    return id2token, token2id


def _is_chinese_char(c: str) -> bool:
    return '\u4e00' <= c <= '\u9fff'


def text_to_token_ids(text: str, token2id: Dict[str, int]) -> Tuple[List[int], List[str]]:
    """Convert text to token IDs (Chinese chars only; punctuation skipped).

    Returns (token_ids, chars) where chars[i] is the original character
    for token_ids[i].
    """
    token_ids = []
    chars = []
    for c in text:
        if _is_chinese_char(c):
            if c in token2id:
                token_ids.append(token2id[c])
                chars.append(c)
            else:
                logger.warning("Char '%s' not in vocabulary, skipping", c)
    return token_ids, chars


# ---------------------------------------------------------------------------
# Kaldi-compatible fbank feature extraction
# ---------------------------------------------------------------------------
def extract_fbank(audio: np.ndarray, sr: int = SAMPLE_RATE,
                  num_mel_bins: int = NUM_MEL_BINS) -> np.ndarray:
    """Extract log-mel filterbank features (kaldi-fbank style).

    Implements kaldi's fbank feature extraction from scratch to ensure
    exact compatibility with sherpa_onnx's C++ backend:
    1. Frame the signal (25ms frame, 10ms shift, snip_edges=True)
    2. Remove DC offset per frame
    3. Apply Povey window (0.5 - 0.5*cos(2*pi*n/N))
    4. FFT -> power spectrum
    5. Apply mel triangular filterbank (HTK mel scale, low_freq=0)
    6. Take natural log

    No pre-emphasis, no dither, no energy, no CMN (CMVN applied later).
    """
    frame_length = int(sr * FRAME_LENGTH_MS / 1000)  # 400
    frame_shift = int(sr * FRAME_SHIFT_MS / 1000)    # 160

    num_frames = 1 + (len(audio) - frame_length) // frame_shift
    if num_frames <= 0:
        return np.zeros((0, num_mel_bins), dtype=np.float32)

    frames = np.zeros((num_frames, frame_length), dtype=np.float32)
    for i in range(num_frames):
        start = i * frame_shift
        frames[i] = audio[start:start + frame_length]

    # Remove DC offset per frame
    frames = frames - np.mean(frames, axis=1, keepdims=True)

    # Povey window: 0.5 - 0.5*cos(2*pi*n/N)
    n = np.arange(frame_length, dtype=np.float64)
    window = 0.5 - 0.5 * np.cos(2 * np.pi * n / frame_length)
    frames = frames * window[np.newaxis, :]

    # FFT -> power spectrum
    padded = np.zeros((num_frames, NFFT), dtype=np.float64)
    padded[:, :frame_length] = frames
    spectrum = np.fft.rfft(padded, axis=1)
    power_spectrum = np.abs(spectrum) ** 2

    # Mel triangular filterbank (HTK style, low_freq=0, high_freq=sr/2)
    low_freq = 0.0
    high_freq = sr / 2.0
    low_mel = 1127.0 * np.log(1.0 + low_freq / 700.0)
    high_mel = 1127.0 * np.log(1.0 + high_freq / 700.0)
    mel_centers = np.linspace(low_mel, high_mel, num_mel_bins + 2)
    center_freqs = 700.0 * (np.exp(mel_centers / 1127.0) - 1.0)

    num_fft_bins = NFFT // 2 + 1
    fft_bin_width = sr / NFFT
    bin_freqs = np.arange(num_fft_bins) * fft_bin_width

    mel_filters = np.zeros((num_mel_bins, num_fft_bins), dtype=np.float64)
    for i in range(num_mel_bins):
        left = center_freqs[i]
        center = center_freqs[i + 1]
        right = center_freqs[i + 2]
        for j in range(num_fft_bins):
            freq = bin_freqs[j]
            if freq <= left or freq >= right:
                mel_filters[i, j] = 0.0
            elif freq <= center:
                mel_filters[i, j] = (freq - left) / (center - left) if center > left else 0.0
            else:
                mel_filters[i, j] = (right - freq) / (right - center) if right > center else 0.0

    mel_energies = np.dot(power_spectrum, mel_filters.T)
    mel_energies = np.where(mel_energies > 0, mel_energies, 1e-10)
    mel_features = np.log(mel_energies)
    return mel_features.astype(np.float32)


def apply_lfr(features: np.ndarray, window: int = LFR_WINDOW,
              shift: int = LFR_SHIFT) -> np.ndarray:
    """Stack `window` consecutive frames with `shift` step.

    Output frame i = concat(frame[i*shift], ..., frame[i*shift+window-1])
    Padding: repeat last frame for incomplete windows at the end.
    """
    num_frames, feat_dim = features.shape
    output_dim = feat_dim * window
    num_output = (num_frames - window) // shift + 1
    if num_output <= 0:
        pad_count = window - num_frames + 1
        features = np.vstack([features, np.tile(features[-1:], (pad_count, 1))])
        num_output = 1

    last_start = (num_output - 1) * shift
    if last_start + window > features.shape[0]:
        pad_count = last_start + window - features.shape[0]
        features = np.vstack([features, np.tile(features[-1:], (pad_count, 1))])

    output = np.zeros((num_output, output_dim), dtype=np.float32)
    for i in range(num_output):
        start = i * shift
        output[i] = features[start:start + window].flatten()
    return output


def apply_cmvn(features: np.ndarray, neg_mean: np.ndarray,
               inv_stddev: np.ndarray) -> np.ndarray:
    """Apply CMVN: x_norm = (x + neg_mean) * inv_stddev.

    neg_mean stores -mean, inv_stddev stores 1/stddev. Both arrays have
    length 560 (LFR output dim). This matches sherpa_onnx's internal
    normalization verified against the reference implementation.
    """
    return (features + neg_mean) * inv_stddev


def parse_cmvn_from_metadata(meta) -> Tuple[np.ndarray, np.ndarray]:
    """Parse neg_mean and inv_stddev from ONNX model custom metadata."""
    neg_mean_str = meta.custom_metadata_map.get("neg_mean", "")
    inv_stddev_str = meta.custom_metadata_map.get("inv_stddev", "")
    neg_mean = np.array([float(x) for x in neg_mean_str.split(",")], dtype=np.float32)
    inv_stddev = np.array([float(x) for x in inv_stddev_str.split(",")], dtype=np.float32)
    return neg_mean, inv_stddev


# ---------------------------------------------------------------------------
# CTC Viterbi forced alignment
# ---------------------------------------------------------------------------
def ctc_forced_align(log_probs: np.ndarray, targets: List[int],
                     blank_id: int = BLANK_ID) -> Tuple[np.ndarray, np.ndarray]:
    """CTC forced alignment using Viterbi.

    Args:
        log_probs: [T, V] log probabilities (after log_softmax)
        targets: [N] target token IDs (no blanks)
        blank_id: CTC blank token id (0 for SenseVoice)

    Returns:
        token_frames: [N] frame index for each target token (best alignment)
        full_path: [T] token ID at each frame (full alignment path)

    The Viterbi DP runs in the compiled C++ engine
    (a2f_engine.ctc_forced_align).
    """
    try:
        import a2f_engine as _native
        frames_py, path_py = _native.ctc_forced_align(log_probs, targets, blank_id)
        return (
            np.array(frames_py, dtype=np.int32),
            np.array(path_py, dtype=np.int32),
        )
    except Exception as e:
        logger.error("C++ forced align unavailable: %s", e)
        T = log_probs.shape[0]
        N = len(targets)
        if N == 0:
            return np.array([], dtype=np.int32), np.full(T, blank_id, dtype=np.int32)
        return np.full(N, T - 1, dtype=np.int32), np.full(T, blank_id, dtype=np.int32)




def _compute_audio_energy(audio: np.ndarray, sr: int,
                          hop_ms: int = 10, win_ms: int = 30):
    """Compute short-time RMS energy of audio.

    Returns (energy_array, hop_seconds) where energy_array[i] is the
    RMS energy at time i * hop_seconds.
    """
    hop = max(1, int(sr * hop_ms / 1000))
    win = max(hop, int(sr * win_ms / 1000))
    n_frames = max(1, (len(audio) - win) // hop + 1)
    energy = np.zeros(n_frames, dtype=np.float64)
    for i in range(n_frames):
        s = i * hop
        e = min(s + win, len(audio))
        if e > s:
            energy[i] = float(np.sqrt(np.mean(audio[s:e] ** 2)))
    return energy, hop_ms / 1000.0


def build_char_timestamps(log_probs: np.ndarray, token_frames: np.ndarray,
                          targets: List[int], chars: List[str],
                          audio_duration: float,
                          audio_energy=None, energy_hop_sec=None) -> List[Dict]:
    """Build per-character timestamps with peak-based refinement.

    Improvements over the naive first-frame approach:
    1. Peak detection: find the frame with max log_prob for each char in its
       Viterbi region. The peak is more stable than the onset frame, especially
       for dropped characters where CTC emissions are weak and noisy.
    2. Sub-frame interpolation: weighted average of log-probs around the peak
       (±1 frame) gives sub-60ms precision, breaking the LFR frame grid.
    3. CTC blank-based boundaries: boundaries between adjacent chars are
       placed at the center of inter-char silence regions detected by CTC
       blank probability. This is far more reliable than audio energy for
       songs with background music. Falls back to midpoint when no silence
       is detected.
    4. LFR center offset: +30ms to account for the LFR window center, fixing
       a systematic early bias in all timestamps.

    Args:
        log_probs: [T, V] log probabilities from the model
        token_frames: [N] Viterbi-assigned first-frame index per char
        targets: [N] token IDs
        chars: [N] original characters
        audio_duration: total audio duration in seconds
        audio_energy: deprecated, kept for API compatibility (unused)
        energy_hop_sec: deprecated, kept for API compatibility (unused)

    Returns:
        List of {'char': str, 'start': float, 'end': float} dicts.
    """
    try:
        import a2f_engine as _native
        result = _native.build_char_timestamps_ctc(
            log_probs,
            [int(f) for f in token_frames],
            list(targets),
            list(chars),
            float(audio_duration),
        )
        return [
            {
                'char': r['char'],
                'start': float(r['start']),
                'end': float(r['end']),
            }
            for r in result
        ]
    except Exception as e:
        logger.error("C++ build_char_timestamps unavailable: %s", e)
        return []


# ---------------------------------------------------------------------------
# Main entry: forced alignment
# ---------------------------------------------------------------------------
def forced_align(audio_path: str, text: str,
                 language: int = LANG_ZH,
                 text_norm: int = TEXT_NORM_WITH_ITN,
                 callback=None) -> Optional[List[Dict]]:
    """Run forced alignment of text to audio.

    Args:
        audio_path: path to audio file (any format librosa can load)
        text: target text (Chinese characters; punctuation auto-skipped)
        language: language ID (zh=3, auto=0)
        text_norm: text norm ID (with_itn=14, without_itn=15)
        callback: optional progress callback (percent, message)

    Returns:
        List of {'char': str, 'start': float, 'end': float} dicts, or None on failure.
        'start'/'end' are in seconds. 'end' is the start of the next char
        (or audio end for the last char).
    """
    if _USE_SUBPROCESS:
        return _forced_align_via_subprocess(audio_path, text, language, text_norm, callback)
    return _forced_align_direct(audio_path, text, language, text_norm, callback)


def _forced_align_direct(audio_path: str, text: str,
                         language: int, text_norm: int,
                         callback=None) -> Optional[List[Dict]]:
    """Run forced alignment in the current process."""
    try:
        if callback:
            callback(5, "Loading tokens...")
        _, token2id = load_tokens(_get_tokens_path())
        token_ids, chars = text_to_token_ids(text, token2id)
        if not token_ids:
            logger.error("No valid Chinese characters in text")
            return None

        if callback:
            callback(15, "Loading audio...")
        import librosa
        audio, sr = librosa.load(audio_path, sr=SAMPLE_RATE, mono=True)
        audio_duration = len(audio) / float(sr)

        # Compute short-time energy for boundary refinement (detects
        # inter-character pauses so they don't inflate character durations)
        audio_energy, energy_hop_sec = _compute_audio_energy(audio, sr)

        if callback:
            callback(30, "Extracting features...")
        mel = extract_fbank(audio, sr=SAMPLE_RATE)
        lfr = apply_lfr(mel)

        if callback:
            callback(45, "Loading model...")
        # Set up DLL search paths for onnxruntime
        cpu_pylibs = _get_cpu_pylibs_dir()
        _ort_capi_dir = os.path.join(cpu_pylibs, "onnxruntime", "capi")
        if os.path.isdir(_ort_capi_dir) and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(_ort_capi_dir)

        import onnxruntime as ort
        so = ort.SessionOptions()
        so.log_severity_level = 3
        sess = ort.InferenceSession(_get_model_path(), sess_options=so,
                                     providers=["CPUExecutionProvider"])
        meta = sess.get_modelmeta()
        neg_mean, inv_stddev = parse_cmvn_from_metadata(meta)
        features = apply_cmvn(lfr, neg_mean, inv_stddev)

        if callback:
            callback(60, "Running model...")
        x = features[np.newaxis, :, :]
        x_length = np.array([features.shape[0]], dtype=np.int32)
        lang_arr = np.array([language], dtype=np.int32)
        tn_arr = np.array([text_norm], dtype=np.int32)
        outputs = sess.run(["logits"], {
            "x": x, "x_length": x_length,
            "language": lang_arr, "text_norm": tn_arr,
        })
        logits = outputs[0][0]  # [T, 25055]

        if callback:
            callback(75, "Aligning...")
        # log_softmax
        max_logits = np.max(logits, axis=-1, keepdims=True)
        exp_logits = np.exp(logits - max_logits)
        sum_exp = np.sum(exp_logits, axis=-1, keepdims=True)
        log_probs = np.log(exp_logits / sum_exp)

        token_frames, _ = ctc_forced_align(log_probs, token_ids, blank_id=BLANK_ID)

        if callback:
            callback(90, "Building timestamps...")

        # Build per-character timestamps with peak-based refinement +
        # energy-based boundary detection. Energy data enables the aligner
        # to place boundaries at silence centers between characters, preventing
        # pause absorption (critical for songs with inter-phrase pauses).
        result = build_char_timestamps(
            log_probs, token_frames, token_ids, chars, audio_duration,
            audio_energy=audio_energy, energy_hop_sec=energy_hop_sec,
        )

        if callback:
            callback(100, "Done")
        return result

    except Exception as e:
        logger.exception("Forced alignment failed: %s", e)
        return None


def _forced_align_via_subprocess(audio_path: str, text: str,
                                 language: int, text_norm: int,
                                 callback=None) -> Optional[List[Dict]]:
    """Run forced alignment in a subprocess (Blender 5.0 / DML onnxruntime conflict).

    Mirrors LocalASR._recognize_via_subprocess: spawns a worker process
    with Blender's bundled Python, which loads the correct onnxruntime
    version from pylibs without DLL conflicts.
    """
    if callback:
        callback(5, "Starting alignment worker...")

    worker_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'forced_align_worker.py'
    )

    fd, output_path = tempfile.mkstemp(suffix='.json')
    os.close(fd)

    # Use Blender's bundled Python (same as asr_worker.py)
    python_exe = os.path.join(sys.prefix, 'bin', 'python.exe')
    if not os.path.exists(python_exe):
        python_exe = sys.executable

    try:
        cmd = [
            python_exe,
            worker_path,
            '--audio_path', audio_path,
            '--text', text,
            '--language', str(language),
            '--text_norm', str(text_norm),
            '--output', output_path,
        ]

        if callback:
            callback(30, "Aligning (subprocess)...")

        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=180,
        )

        if result.returncode != 0:
            logger.error("Alignment worker failed (code=%d):\nSTDOUT: %s\nSTDERR: %s",
                         result.returncode, result.stdout, result.stderr)
            return None

        with open(output_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if not data.get('success'):
            logger.error("Alignment failed: %s", data.get('error', 'unknown'))
            return None

        if callback:
            callback(100, "Done")

        # Worker returns list of {'char', 'start', 'end'} dicts
        return data.get('chars', [])

    except subprocess.TimeoutExpired:
        logger.error("Alignment worker timed out")
        return None
    except Exception as e:
        logger.exception("Subprocess alignment failed: %s", e)
        return None
    finally:
        if output_path and os.path.exists(output_path):
            os.remove(output_path)


# ---------------------------------------------------------------------------
# Integration helper: convert alignment result to PhonemeSegment list
# ---------------------------------------------------------------------------
def align_to_phoneme_segments(aligned_chars: List[Dict]):
    """Convert forced alignment result to PhonemeSegment list.

    Reuses SpeechAnalyzer._char_to_phonemes so compound final splitting,
    initial duration factors, and bilabial/labiodental protections all
    apply identically to the existing phoneme correction pipeline.

    Args:
        aligned_chars: list of {'char', 'start', 'end'} from forced_align()

    Returns:
        List[PhonemeSegment] ready to be stored in AnimationCache._phoneme_data
    """
    from .speech_analyzer import SpeechAnalyzer

    analyzer = SpeechAnalyzer()
    phonemes = []
    for char_info in aligned_chars:
        char = char_info['char']
        start = char_info['start']
        end = char_info['end']
        char_phonemes = analyzer._char_to_phonemes(char, start, end)
        # Debug: print every char's phoneme split for verification
        ph_strs = [f"{p.phoneme}({p.phoneme_type},{p.start:.3f}-{p.end:.3f})" for p in char_phonemes]
        dur_ms = (end - start) * 1000
        print(f"  [Align] '{char}' dur={dur_ms:.0f}ms -> {ph_strs}")
        phonemes.extend(char_phonemes)
    return phonemes

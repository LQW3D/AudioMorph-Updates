"""Audio2Face ONNX inference module (cross-platform).

Replaces the Windows-only TensorRT worker (a2f_worker.exe) with a
pure-Python ONNX Runtime pipeline that works on CPU/CUDA/CoreML/DirectML.

Pipeline:
    Audio (16kHz) -> windowed batches -> ONNX -> 169-dim shapes coeffs
    -> AnimatorPca -> 24002 skin verts + 5602 tongue verts
    -> BlendshapeSolver (BVLS) -> 52 ARKit weights + 16 tongue weights
    -> 68-dim output per frame

Independent implementation. The BlendshapeSolver is based on the BVLS
(Bounded Variable Least Squares) algorithm using scipy.optimize.lsq_linear,
with L2 / temporal / L1 / symmetry regularization. No third-party
proprietary code is used.
"""

import os
import json
import numpy as np

# Native C++ engine (BVLS solver + protected recipes) compiled into a .pyd.
# The platform-ABI-matched binary (a2f_engine.cp311-win_amd64.pyd /
# cp313-win_amd64.pyd) lives in the addon root and is picked up by import.
import a2f_engine as _native


# ---------------------------------------------------------------------------
# PCA Animator
# ---------------------------------------------------------------------------

class AnimatorPca:
    """Reconstruct vertex positions from PCA shape coefficients.

    Formula:  vertices = coeffs @ shapes_matrix + shapes_mean
    where shapes_matrix has shape (num_shapes, num_verts, 3).
    """

    def __init__(self, shapes_matrix, shapes_mean):
        """
        Args:
            shapes_matrix: (num_shapes, num_verts, 3) PCA basis matrix.
            shapes_mean:   (num_verts, 3)            mean geometry.
        """
        self._num_shapes, self._num_verts, _ = shapes_matrix.shape
        # Flatten vertex dimension for matmul: (num_shapes, num_verts*3)
        self._basis = np.ascontiguousarray(
            shapes_matrix.reshape(self._num_shapes, -1), dtype=np.float32
        )
        self._mean = np.ascontiguousarray(shapes_mean.reshape(-1), dtype=np.float32)

    def reconstruct(self, coeffs):
        """Reconstruct vertices for multiple frames.

        Args:
            coeffs: (num_frames, num_shapes) PCA coefficients.

        Returns:
            (num_frames, num_verts, 3) vertex positions.

        The matmul runs in the compiled C++ engine
        (a2f_engine.pca_reconstruct) to protect the algorithm.
        """
        try:
            import a2f_engine as _native
            flat = np.asarray(
                _native.pca_reconstruct(coeffs, self._basis, self._mean),
                dtype=np.float32,
            )
        except Exception as e:
            raise RuntimeError(
                "[Audio2Face] PCA reconstruction requires the compiled "
                f"a2f_engine (C++ engine unavailable: {e})"
            ) from e
        return flat.reshape(coeffs.shape[0], self._num_verts, 3)


# ---------------------------------------------------------------------------
# Blendshape Solver (BVLS + regularization)
# ---------------------------------------------------------------------------

class BlendshapeSolver:
    """BVLS blendshape solver backed by the native C++ engine (a2f_engine.pyd).

    The heavy math (A-matrix build, Cholesky factorization, Stark-Parker
    active-set BVLS, cancel-pair refinement) runs inside the compiled native
    module so the protected solving recipe is not exposed in Python source.
    """

    def __init__(self, neutral, pose_deltas, config, frontal_mask=None):
        p = config["blendshape_params"]
        num_poses = int(p["numPoses"])

        active = [int(x) for x in p.get("bsSolveActivePoses", [1] * num_poses)]
        mult = [float(x) for x in p.get("bsWeightMultipliers", [1.0] * num_poses)]
        off = [float(x) for x in p.get("bsWeightOffsets", [0.0] * num_poses)]
        sym_groups = [int(x) for x in p.get("bsSolveSymmetryPoses", [-1] * num_poses)]
        cancel_groups = [int(x) for x in p.get("bsSolveCancelPoses", [-1] * num_poses)]

        params = {
            "l2": float(p.get("strengthL2regularization", 0.2)),
            "temporal": float(p.get("strengthTemporalSmoothing", 0.3)),
            "l1": float(p.get("strengthL1regularization", 0.2)),
            "sym": float(p.get("strengthSymmetry", 100.0)),
            "template_bb": float(p.get("templateBBSize", 54.85)),
        }

        # Contiguous float32 buffers for the native layer.
        neutral_flat = np.ascontiguousarray(neutral.reshape(-1), dtype=np.float32)
        if isinstance(pose_deltas, np.ndarray) and pose_deltas.ndim == 3:
            # (num_verts, 3, num_poses) -> C-order flat (row*num_poses + pose)
            deltas_flat = np.ascontiguousarray(pose_deltas, dtype=np.float32).reshape(-1)
        else:
            # list of (num_verts, 3) -> stack -> (num_poses, num_verts*3) -> T
            stacked = np.stack([d.reshape(-1) for d in pose_deltas], axis=1)
            deltas_flat = np.ascontiguousarray(stacked, dtype=np.float32).reshape(-1)

        mask = [] if frontal_mask is None else [int(v) for v in frontal_mask]

        self.num_poses = num_poses
        self._handle = _native.solver_create(
            neutral_flat, deltas_flat, params,
            active, mult, off, sym_groups, cancel_groups, mask,
        )

    def solve_batch(self, target_vertices):
        n_frames = int(target_vertices.shape[0])
        tgt = np.ascontiguousarray(target_vertices, dtype=np.float32).reshape(-1)
        out = _native.solver_solve(self._handle, tgt, n_frames)
        return np.frombuffer(out, dtype=np.float32).reshape(n_frames, self.num_poses)

    def reset_temporal(self):
        _native.solver_reset(self._handle)

    def __del__(self):
        h = getattr(self, "_handle", None)
        if h is not None:
            try:
                _native.solver_delete(h)
            except Exception:
                pass


class OnnxModel:
    """Thin wrapper around onnxruntime.InferenceSession.

    Supported Execution Provider priority:
        1. CUDAExecutionProvider  - NVIDIA GPU + CUDA (requires onnxruntime-gpu)
        2. DmlExecutionProvider   - Windows GPU via DirectML (NVIDIA/AMD/Intel)
        3. CoreMLExecutionProvider - macOS (CocoaPods only, no PyPI package)
        4. CPUExecutionProvider   - CPU fallback (default bundled)

    Automatically falls back to CPU when the GPU provider is unavailable.
    DirectML requires disabling mem_pattern and using sequential execution mode.
    """

    def __init__(self, onnx_path, preferred_providers=None):
        import onnxruntime as ort

        if preferred_providers is None:
            preferred_providers = [
                "CUDAExecutionProvider",
                "DmlExecutionProvider",       # DirectML (Windows GPU)
                "CoreMLExecutionProvider",    # macOS
                "CPUExecutionProvider",
            ]

        available = ort.get_available_providers()
        candidates = [p for p in preferred_providers if p in available]

        # Try providers one by one, fall back to the next on failure
        # get_available_providers() only reflects compile-time, not runtime hardware availability
        self._session = None
        self._providers = []
        last_error = None

        for p in candidates:
            try:
                so = ort.SessionOptions()
                if p == "DmlExecutionProvider":
                    # DirectML official requirement: disable memory pattern
                    # optimization + sequential execution
                    so.enable_mem_pattern = False
                    so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
                    self._session = ort.InferenceSession(
                        onnx_path, sess_options=so,
                        providers=[p, "CPUExecutionProvider"]
                    )
                else:
                    self._session = ort.InferenceSession(
                        onnx_path, providers=[p, "CPUExecutionProvider"]
                    )
                self._providers = self._session.get_providers()
                break
            except Exception as e:
                last_error = e
                continue

        if self._session is None:
            # All providers failed, pure CPU fallback
            self._session = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
            self._providers = self._session.get_providers()

        self._input_names = [i.name for i in self._session.get_inputs()]
        self._output_name = self._session.get_outputs()[0].name

    @property
    def providers(self):
        return self._providers

    def infer(self, audio_windows, emotion=None):
        """Run batched inference.

        Args:
            audio_windows: (batch, 1, 8320) float32 audio.
            emotion:       (batch, 1, 26) float32 emotion vector, or None.

        Returns:
            (batch, 1, 169) float32 shapes coefficients.
        """
        batch = audio_windows.shape[0]
        if emotion is None:
            emotion = np.zeros((batch, 1, 26), dtype=np.float32)

        # Long audio (e.g. >30s = >1800 frames) causes ONNX Runtime to
        # allocate huge intermediate buffers for InstanceNormalization,
        # leading to OOM (e.g. 18.4GB for 96s audio). Chunk the batch
        # and run inference sequentially, then concatenate results.
        # 128 frames per chunk keeps memory usage modest (~400MB peak).
        _MAX_CHUNK = 128

        if batch <= _MAX_CHUNK:
            feed = {
                self._input_names[0]: audio_windows.astype(np.float32, copy=False),
                self._input_names[1]: emotion.astype(np.float32, copy=False),
            }
            outputs = self._session.run(None, feed)
            return outputs[0]  # (batch, 1, 169)

        # Chunked inference for long audio
        out_chunks = []
        for start in range(0, batch, _MAX_CHUNK):
            end = min(start + _MAX_CHUNK, batch)
            chunk_audio = audio_windows[start:end].astype(np.float32, copy=False)
            chunk_emotion = emotion[start:end].astype(np.float32, copy=False)
            feed = {
                self._input_names[0]: chunk_audio,
                self._input_names[1]: chunk_emotion,
            }
            out = self._session.run(None, feed)[0]  # (chunk, 1, 169)
            out_chunks.append(out)
        return np.concatenate(out_chunks, axis=0)


# ---------------------------------------------------------------------------
# Main context (compatible with old A2FContext interface)
# ---------------------------------------------------------------------------

# Output frame rate (matches a2f_ms_config keyframer_fps)
_OUTPUT_FPS = 60.0
# Audio sample rate
_SAMPLE_RATE = 16000
# ONNX input window size (samples = 520ms @ 16kHz)
_WINDOW_LEN = 8320
# Half window (center offset)
_WINDOW_HALF = 4160
# Emotion vector length (10 explicit + 16 implicit = 26)
_EMOTION_LEN = 26


class A2FOnnxContext:
    """Cross-platform Audio2Face inference context using ONNX Runtime.

    Provides the same interface as the old A2FContext:
        - weight_count property
        - process_audio(samples, **kwargs) -> list[list[float]]
        - reset()
        - close()
        - context manager (__enter__ / __exit__)
    """

    def __init__(self, model_dir):
        """
        Args:
            model_dir: path to the model directory (e.g. models/james_v3.0/).
        """
        self._model_dir = model_dir
        self._closed = False

        # --- load network_info.json ---
        ni_path = os.path.join(model_dir, "network_info.json")
        with open(ni_path, "r") as f:
            net_info = json.load(f)

        self._model_type = net_info["id"]["type"]  # "regression" or "diffusion"

        if self._model_type == "diffusion":
            self._init_v3(model_dir, net_info)
        else:
            self._init_v2(model_dir, net_info)

        # output: 52 ARKit + 16 tongue = 68
        self._weight_count = 52 + 16
        self._frame_count = 0

    def _init_v2(self, model_dir, net_info):
        """Initialize for v2.x regression models (PCA-based)."""
        params = net_info["params"]
        self._num_skin_shapes = params["num_shapes_skin"]      # 140
        self._num_tongue_shapes = params["num_shapes_tongue"]  # 10
        self._num_skin_verts = params["num_verts_skin"]        # 24002
        self._num_tongue_verts = params["num_verts_tongue"]    # 5602
        # 169 = 140 skin + 10 tongue + 15 jaw + 4 eyes
        self._total_shapes = (
            self._num_skin_shapes + self._num_tongue_shapes + 15 + 4
        )

        # --- load model_data.npz (PCA matrices) ---
        md_path = os.path.join(model_dir, "model_data.npz")
        md = np.load(md_path)
        self._animator_skin = AnimatorPca(
            md["shapes_matrix_skin"],   # (140, 24002, 3)
            md["shapes_mean_skin"],     # (24002, 3)
        )
        self._animator_tongue = AnimatorPca(
            md["shapes_matrix_tongue"],  # (10, 5602, 3)
            md["shapes_mean_tongue"],    # (5602, 3)
        )

        # --- load blendshape data and configs ---
        bs_skin_cfg = self._load_json(model_dir, "bs_skin_config.json")
        bs_tongue_cfg = self._load_json(model_dir, "bs_tongue_config.json")

        bs_skin = np.load(os.path.join(model_dir, "bs_skin.npz"))
        bs_tongue = np.load(os.path.join(model_dir, "bs_tongue.npz"))

        # neutral and pose deltas
        skin_neutral = bs_skin["neutral"]               # (24002, 3)
        skin_poses = self._build_pose_deltas(
            bs_skin, bs_skin["poseNames"], skip_neutral=True
        )
        tongue_neutral = bs_tongue["neutral"]           # (5602, 3)
        tongue_poses = self._build_pose_deltas(
            bs_tongue, bs_tongue["poseNames"], skip_neutral=True
        )

        # frontal mask for skin solver (optional, speeds up solving)
        frontal_mask = None
        if "frontalMask" in bs_skin.files:
            frontal_mask = bs_skin["frontalMask"]

        # --- create solvers ---
        self._solver_skin = BlendshapeSolver(
            skin_neutral, skin_poses, bs_skin_cfg, frontal_mask=frontal_mask
        )
        self._solver_tongue = BlendshapeSolver(
            tongue_neutral, tongue_poses, bs_tongue_cfg, frontal_mask=None
        )

        # --- load ONNX model ---
        onnx_path = os.path.join(model_dir, "network.onnx")
        if not os.path.isfile(onnx_path):
            raise FileNotFoundError(f"ONNX model not found: {onnx_path}")
        self._onnx = OnnxModel(onnx_path)

    def _init_v3(self, model_dir, net_info):
        """Initialize for v3.x diffusion models (direct vertex delta output).

        v3.0 outputs vertex deltas directly (no PCA reconstruction needed).
        The ONNX model takes audio + identity + emotion + latents + noise,
        runs 2-step diffusion, and outputs 60 frames of vertex deltas.
        Only the center 30 frames are used per inference window.

        v3.0 uses multi-character model files (Claire/James/Mark). We load
        James-specific files by reading model.json to resolve the correct
        file paths based on the identity index.
        """
        params = net_info["params"]
        audio_params = net_info["audio_params"]

        # --- v3 diffusion parameters ---
        self._num_diffusion_steps = params["num_diffusion_steps"]  # 2
        self._num_frames_center = params["num_frames_center"]      # 30
        self._left_trunc = params["num_frames_left_truncate"]      # 15
        self._right_trunc = params["num_frames_right_truncate"]    # 15
        self._total_output_frames = (
            self._left_trunc + self._num_frames_center + self._right_trunc  # 60
        )
        self._buffer_len = audio_params["buffer_len"]              # 16000
        self._padding_left = audio_params["padding_left"]          # 16000
        self._padding_right = audio_params["padding_right"]        # 16000

        # --- output dimensions ---
        # 88831 = 72006 (skin, 24002*3) + 16806 (tongue, 5602*3) + 15 (jaw, 5*3) + 4 (eyes)
        self._skin_size = params["skin_size"]      # 72006
        self._tongue_size = params["tongue_size"]  # 16806
        self._jaw_size = params["jaw_size"]         # 15
        self._eyes_size = params["eyes_size"]       # 4
        self._total_pred_size = (
            self._skin_size + self._tongue_size + self._jaw_size + self._eyes_size
        )
        self._num_skin_verts = self._skin_size // 3    # 24002
        self._num_tongue_verts = self._tongue_size // 3  # 5602

        # --- identity vector for James (index 1 in [Claire, James, Mark]) ---
        identities = params["identities"]
        james_idx = identities.index("James")
        self._identity = np.zeros((1, len(identities)), dtype=np.float32)
        self._identity[0, james_idx] = 1.0

        # --- read model.json to resolve James-specific file paths ---
        model_json = self._load_json(model_dir, "model.json")
        model_data_path = model_json["modelDataPaths"][james_idx]
        bs_paths = model_json["blendshapePaths"][james_idx]

        # --- load model_data (neutral positions, no PCA in v3) ---
        md = np.load(os.path.join(model_dir, model_data_path))
        self._neutral_skin = md["neutral_skin"]      # (24002, 3)
        self._neutral_tongue = md["neutral_tongue"]  # (5602, 3)

        # --- load blendshape data and configs (same format as v2) ---
        bs_skin_cfg = self._load_json(model_dir, bs_paths["skin"]["config"])
        bs_tongue_cfg = self._load_json(model_dir, bs_paths["tongue"]["config"])
        bs_skin = np.load(os.path.join(model_dir, bs_paths["skin"]["data"]))
        bs_tongue = np.load(os.path.join(model_dir, bs_paths["tongue"]["data"]))

        # neutral and pose deltas (same as v2)
        skin_neutral = bs_skin["neutral"]
        skin_poses = self._build_pose_deltas(
            bs_skin, bs_skin["poseNames"], skip_neutral=True
        )
        tongue_neutral = bs_tongue["neutral"]
        tongue_poses = self._build_pose_deltas(
            bs_tongue, bs_tongue["poseNames"], skip_neutral=True
        )

        # frontal mask for skin solver
        frontal_mask = None
        if "frontalMask" in bs_skin.files:
            frontal_mask = bs_skin["frontalMask"]

        # --- create solvers (BVLS unchanged, same ARKit 52 + tongue 16) ---
        self._solver_skin = BlendshapeSolver(
            skin_neutral, skin_poses, bs_skin_cfg, frontal_mask=frontal_mask
        )
        self._solver_tongue = BlendshapeSolver(
            tongue_neutral, tongue_poses, bs_tongue_cfg, frontal_mask=None
        )

        # --- load ONNX model ---
        onnx_path = os.path.join(model_dir, "network.onnx")
        if not os.path.isfile(onnx_path):
            raise FileNotFoundError(f"ONNX model not found: {onnx_path}")
        self._onnx = OnnxModel(onnx_path)

        # --- v3 specific: pre-compute diffusion noise (deterministic) ---
        # Fixed seed ensures the same audio always produces the same animation.
        # Each diffusion step uses a different noise tensor (RNG state advances).
        self._noise_scale = 0.1
        self._latent_shape = (2, 2, 1, 256)
        self._noise_shape = (1, 3, self._total_output_frames, self._total_pred_size)
        rng = np.random.RandomState(42)
        self._noise_arrays = [
            (rng.randn(*self._noise_shape).astype(np.float32) * self._noise_scale)
            for _ in range(self._num_diffusion_steps)
        ]

        # --- v3 windowing parameters ---
        # Each inference: 1s audio (16000 samples) -> 30 center frames (0.5s @ 60fps)
        # Audio window is centered on the output block, so consecutive windows
        # overlap by 50%. Hop between blocks = 30 frames = 8000 samples (0.5s).
        self._v3_hop_samples = self._buffer_len // 2  # 8000
        self._v3_frames_per_block = self._num_frames_center  # 30

    # -- public API (compatible with old A2FContext) -----------------------

    @property
    def weight_count(self):
        return self._weight_count

    @property
    def frame_count(self):
        return self._frame_count

    @property
    def providers(self):
        """List of ONNX execution providers actually in use."""
        return self._onnx.providers if self._onnx else ["CPUExecutionProvider"]

    def _infer_diffusion(self, audio_window, emotion_window):
        """Run multi-step diffusion inference for a single audio window.

        Args:
            audio_window: (1, 16000) float32 audio samples.
            emotion_window: (1, 30, 10) float32 emotion vectors.

        Returns:
            (30, total_pred_size) float32 vertex deltas (center frames only).
        """
        input_latents = np.zeros(self._latent_shape, dtype=np.float32)
        prediction = None

        for step in range(self._num_diffusion_steps):
            feed = {
                "window": audio_window,
                "identity": self._identity,
                "emotion": emotion_window,
                "input_latents": input_latents,
                "noise": self._noise_arrays[step],
            }
            outputs = self._onnx._session.run(None, feed)
            prediction = outputs[0]       # (1, 60, 88831)
            output_latents = outputs[1]  # (2, 2, 1, 256)
            input_latents = output_latents  # feed back for next step

        # Extract center 30 frames (skip left/right truncation)
        center = prediction[0,
                            self._left_trunc: self._left_trunc + self._num_frames_center]
        return center  # (30, 88831)

    def _process_audio_v3(self, samples, emotion_vectors=None, **kwargs):
        """v3 diffusion inference: audio -> vertex deltas -> BVLS solver.

        v3.0 pipeline:
            1. Pad audio with 1s silence on each side (padding_left/right)
            2. For each 30-frame block (0.5s @ 60fps):
               a. Extract 1s audio window centered on the block
               b. Build 30-frame emotion vector (10 explicit dims only)
               c. Run 2-step diffusion -> 60-frame prediction
               d. Extract center 30 frames of vertex deltas
               e. Add deltas to neutral -> target vertices
               f. BVLS solve -> 52 skin + 16 tongue weights
            3. Concatenate all blocks -> (n_frames, 68)

        Args:
            samples: 1-D float32 array of 16kHz mono audio.
            emotion_vectors: (n_frames, 26) or None. v3 only uses the first
                             10 explicit dims; the 16 implicit dims are
                             ignored (v3 handles emotion natively via
                             diffusion, no implicit vector hack needed).
            **kwargs: accepted but ignored (API compatibility).

        Returns:
            list[list[float]] with shape (num_frames, 68).
        """
        import sys
        import time as _time

        def _log(msg):
            print(f"[A2F-v3 {_time.time():.1f}] {msg}", file=sys.stderr, flush=True)

        t_start = _time.time()
        audio = np.asarray(samples, dtype=np.float32)
        if audio.ndim > 1:
            audio = audio.flatten()

        # --- compute total output frames ---
        hop = int(round(_SAMPLE_RATE / _OUTPUT_FPS))  # 267 samples for 60fps
        n_frames = max(1, int(np.ceil(len(audio) / hop)))
        _log(f"v3 process_audio: {len(audio)} samples ({len(audio)/_SAMPLE_RATE:.1f}s), "
             f"{n_frames} frames @ 60fps")

        # --- pad audio with silence on each side ---
        # padding_left/right = 16000 (1s) ensures edge blocks have full context.
        padded = np.zeros(self._padding_left + len(audio) + self._padding_right,
                          dtype=np.float32)
        padded[self._padding_left: self._padding_left + len(audio)] = audio

        # --- prepare per-frame emotion (10 explicit dims only) ---
        if emotion_vectors is None:
            emo_per_frame = np.zeros((n_frames, 10), dtype=np.float32)
        else:
            ev = np.asarray(emotion_vectors, dtype=np.float32)
            if ev.ndim != 2:
                raise ValueError(f"emotion_vectors must be 2-D, got {ev.ndim}-D")
            # v3 only needs first 10 explicit dims; pad if fewer
            n_emo = min(ev.shape[1], 10)
            emo_per_frame = np.zeros((ev.shape[0], 10), dtype=np.float32)
            emo_per_frame[:, :n_emo] = ev[:, :n_emo]
            # pad to n_frames if emotion is shorter
            if emo_per_frame.shape[0] < n_frames:
                last = emo_per_frame[-1:] if len(emo_per_frame) > 0 else np.zeros((1, 10), dtype=np.float32)
                pad_rows = np.repeat(last, n_frames - emo_per_frame.shape[0], axis=0)
                emo_per_frame = np.concatenate([emo_per_frame, pad_rows], axis=0)
            elif emo_per_frame.shape[0] > n_frames:
                emo_per_frame = emo_per_frame[:n_frames]

        # --- compute number of inference blocks ---
        # Each block produces 30 center frames (0.5s). Hop between blocks
        # is 30 frames = 8000 samples (0.5s) in the original audio.
        n_blocks = (n_frames + self._v3_frames_per_block - 1) // self._v3_frames_per_block
        _log(f"v3 inference: {n_blocks} blocks of {self._v3_frames_per_block} frames")

        # --- allocate output arrays ---
        skin_weights_all = np.zeros(
            (n_frames, self._solver_skin.num_poses), dtype=np.float32
        )
        tongue_weights_all = np.zeros(
            (n_frames, self._solver_tongue.num_poses), dtype=np.float32
        )

        t_diff_total = 0.0
        t_bvls_total = 0.0

        for block_idx in range(n_blocks):
            frame_start = block_idx * self._v3_frames_per_block
            frame_end = min(frame_start + self._v3_frames_per_block, n_frames)
            actual_frames = frame_end - frame_start

            # --- extract 1s audio window centered on this block ---
            # Block center time = (frame_start + frame_end) / 2 / fps
            block_center_sample = int(
                ((frame_start + frame_end) / 2.0) / _OUTPUT_FPS * _SAMPLE_RATE
            )
            # Audio window: [center - 0.5s, center + 0.5s] in padded array
            audio_start = block_center_sample + self._padding_left - self._buffer_len // 2
            audio_end = audio_start + self._buffer_len

            # Clamp to valid range (shouldn't happen with padding, but safety first)
            if audio_start < 0:
                audio_start = 0
            if audio_end > len(padded):
                audio_end = len(padded)

            audio_window = np.zeros((1, self._buffer_len), dtype=np.float32)
            audio_window[0, :audio_end - audio_start] = padded[audio_start:audio_end]

            # --- build 30-frame emotion vector ---
            emo_window = np.zeros((1, self._num_frames_center, 10), dtype=np.float32)
            for j in range(actual_frames):
                src = frame_start + j
                dst = j
                if src < emo_per_frame.shape[0]:
                    emo_window[0, dst, :] = emo_per_frame[src]
            # If actual_frames < 30, pad remaining with last emotion
            if actual_frames < self._v3_frames_per_block:
                last_emo = emo_window[0, actual_frames - 1, :]
                for j in range(actual_frames, self._v3_frames_per_block):
                    emo_window[0, j, :] = last_emo

            # --- run 2-step diffusion ---
            t0 = _time.time()
            pred_center = self._infer_diffusion(audio_window, emo_window)
            t_diff_total += _time.time() - t0

            # --- extract skin and tongue vertex deltas ---
            # Only use the actual_frames from this block (may be < 30 for last block)
            skin_flat = pred_center[:actual_frames, :self._skin_size]
            tongue_flat = pred_center[:actual_frames,
                                       self._skin_size: self._skin_size + self._tongue_size]

            skin_delta = skin_flat.reshape(actual_frames, self._num_skin_verts, 3)
            tongue_delta = tongue_flat.reshape(actual_frames, self._num_tongue_verts, 3)

            # Add deltas to neutral to get target vertices
            skin_target = skin_delta + self._neutral_skin[np.newaxis, :, :]
            tongue_target = tongue_delta + self._neutral_tongue[np.newaxis, :, :]

            # --- BVLS solve (temporal state maintained across blocks) ---
            t0 = _time.time()
            skin_weights_all[frame_start:frame_end] = \
                self._solver_skin.solve_batch(skin_target)
            tongue_weights_all[frame_start:frame_end] = \
                self._solver_tongue.solve_batch(tongue_target)
            t_bvls_total += _time.time() - t0

            # Progress log every 5 blocks or on the last block
            if block_idx % 5 == 0 or block_idx == n_blocks - 1:
                _log(f"  block {block_idx+1}/{n_blocks}: frames {frame_start}-{frame_end-1}, "
                     f"diff={t_diff_total:.1f}s, bvls={t_bvls_total:.1f}s")

        _log(f"v3 inference done: diff={t_diff_total:.2f}s, bvls={t_bvls_total:.2f}s, "
             f"total={_time.time()-t_start:.2f}s")

        # --- combine to 68-dim output ---
        combined = np.concatenate([skin_weights_all, tongue_weights_all], axis=1)
        self._frame_count = combined.shape[0]

        t0 = _time.time()
        result = combined.tolist()
        _log(f"Convert to list: {_time.time()-t0:.2f}s ({combined.shape})")
        return result

    def process_audio(self, samples, emotion_vectors=None, **kwargs):
        """Process audio samples and return per-frame blendshape weights.

        Dispatches to v2 (regression) or v3 (diffusion) implementation
        based on the model type detected at initialization.

        Args:
            samples: list[float] or 1-D numpy array of 16kHz mono audio.
            emotion_vectors: optional numpy array of shape (n_frames, 26)
                             containing per-frame NVIDIA emotion vectors.
                             v2 uses all 26 dims (10 explicit + 16 implicit).
                             v3 uses only the first 10 explicit dims.
                             If None, zeros are used (neutral expression).
            **kwargs: accepted but ignored (strength/smoothing params are
                      handled internally; the ONNX model already produces
                      correct output).

        Returns:
            list[list[float]] with shape (num_frames, 68).
            First 52 entries are ARKit blendshape weights,
            next 16 entries are tongue blendshape weights.
        """
        if self._model_type == "diffusion":
            return self._process_audio_v3(samples, emotion_vectors, **kwargs)
        return self._process_audio_v2(samples, emotion_vectors, **kwargs)

    def _process_audio_v2(self, samples, emotion_vectors=None, **kwargs):
        """v2.x regression inference: audio -> PCA shapes -> BVLS solver.

        v2 pipeline:
            1. Slide 520ms window per frame (hop = 267 samples = 1/60s)
            2. ONNX inference -> 169-dim PCA shape coefficients
            3. PCA reconstruction -> 24002 skin + 5602 tongue vertices
            4. BVLS solve -> 52 skin + 16 tongue weights
            5. Output (n_frames, 68)
        """
        import sys
        import time as _time

        def _log(msg):
            """Log to stderr (visible in both direct and subprocess modes)."""
            print(f"[A2F-Onnx {_time.time():.1f}] {msg}", file=sys.stderr, flush=True)

        t_pa_start = _time.time()
        audio = np.asarray(samples, dtype=np.float32)
        if audio.ndim > 1:
            audio = audio.flatten()

        # --- build windowed batches ---
        hop = int(round(_SAMPLE_RATE / _OUTPUT_FPS))  # 267 samples for 60fps
        n_frames = max(1, int(np.ceil(len(audio) / hop)))
        _log(f"process_audio: {len(audio)} samples, {n_frames} frames @ 60fps")

        # pad audio: _WINDOW_HALF on each side so center-aligned windows work
        pad_left = _WINDOW_HALF
        pad_right = _WINDOW_HALF
        padded = np.zeros(pad_left + len(audio) + pad_right, dtype=np.float32)
        padded[pad_left: pad_left + len(audio)] = audio

        # build (n_frames, 1, 8320) batch
        windows = np.zeros((n_frames, 1, _WINDOW_LEN), dtype=np.float32)
        for i in range(n_frames):
            center = i * hop + _WINDOW_HALF  # position in padded array
            start = center - _WINDOW_HALF
            end = center + _WINDOW_HALF
            # guaranteed to be in bounds due to padding
            windows[i, 0, :] = padded[start:end]

        # --- build per-frame emotion vectors ---
        if emotion_vectors is None:
            emotions = np.zeros((n_frames, 1, _EMOTION_LEN), dtype=np.float32)
        else:
            ev = np.asarray(emotion_vectors, dtype=np.float32)
            if ev.ndim != 2 or ev.shape[0] != n_frames:
                raise ValueError(
                    f"emotion_vectors shape mismatch: expected ({n_frames}, 26), "
                    f"got {ev.shape}"
                )
            emotions = ev.reshape(n_frames, 1, _EMOTION_LEN)

        # --- ONNX inference (batched to bound memory) ---
        _INFERENCE_BATCH = 128
        skin_weights_all = np.zeros((n_frames, self._solver_skin.num_poses), dtype=np.float32)
        tongue_weights_all = np.zeros((n_frames, self._solver_tongue.num_poses), dtype=np.float32)

        t_onnx_total = 0.0
        t_bvls_total = 0.0
        n_chunks = (n_frames + _INFERENCE_BATCH - 1) // _INFERENCE_BATCH
        _log(f"Starting inference: {n_chunks} chunks of {_INFERENCE_BATCH} frames")

        for chunk_idx, start in enumerate(range(0, n_frames, _INFERENCE_BATCH)):
            end = min(start + _INFERENCE_BATCH, n_frames)
            win_batch = windows[start:end]
            emo_batch = emotions[start:end]

            t0 = _time.time()
            shapes_batch = self._onnx.infer(win_batch, emotion=emo_batch)
            shapes_batch = shapes_batch[:, 0, :]
            t_onnx_total += _time.time() - t0

            skin_coeffs = shapes_batch[:, :self._num_skin_shapes]
            tongue_coeffs = shapes_batch[:, self._num_skin_shapes:
                                          self._num_skin_shapes + self._num_tongue_shapes]

            skin_verts = self._animator_skin.reconstruct(skin_coeffs)
            tongue_verts = self._animator_tongue.reconstruct(tongue_coeffs)

            t0 = _time.time()
            skin_weights_all[start:end] = self._solver_skin.solve_batch(skin_verts)
            tongue_weights_all[start:end] = self._solver_tongue.solve_batch(tongue_verts)
            t_bvls_total += _time.time() - t0

            if chunk_idx % 10 == 0 or chunk_idx == n_chunks - 1:
                _log(f"  chunk {chunk_idx+1}/{n_chunks}: frames {start}-{end-1}, "
                     f"onnx={t_onnx_total:.1f}s, bvls={t_bvls_total:.1f}s")

        _log(f"Inference done: onnx={t_onnx_total:.2f}s, bvls={t_bvls_total:.2f}s, "
             f"total={_time.time()-t_pa_start:.2f}s")

        # --- combine to 68-dim output ---
        combined = np.concatenate([skin_weights_all, tongue_weights_all], axis=1)
        self._frame_count = combined.shape[0]

        t0 = _time.time()
        result = combined.tolist()
        _log(f"Convert to list: {_time.time()-t0:.2f}s ({combined.shape})")
        return result

    def reset(self):
        """Reset state for a new audio clip."""
        self._frame_count = 0
        self._solver_skin.reset_temporal()
        self._solver_tongue.reset_temporal()

    def close(self):
        """Release ONNX session resources."""
        if not self._closed:
            self._onnx = None
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def __del__(self):
        self.close()

    # -- helpers ------------------------------------------------------------

    @staticmethod
    def _load_json(model_dir, filename):
        path = os.path.join(model_dir, filename)
        with open(path, "r") as f:
            return json.load(f)

    @staticmethod
    def _build_pose_deltas(npz_data, pose_names, skip_neutral=True):
        """Build (num_verts, 3, num_poses) array from named pose arrays.

        Args:
            npz_data:   opened npz file.
            pose_names:  array of pose name strings (may be bytes).
            skip_neutral: if True, skip index 0 (neutral pose).

        Returns:
            (num_verts, 3, num_poses) or (num_verts*3, num_poses) array.
        """
        names = []
        for n in pose_names:
            if isinstance(n, bytes):
                n = n.decode("utf-8")
            names.append(n)

        start = 1 if skip_neutral else 0
        pose_list = []
        for name in names[start:]:
            if name in npz_data.files:
                arr = npz_data[name]
                if arr.ndim == 2 and arr.shape[1] == 3:
                    pose_list.append(arr)
                else:
                    pose_list.append(arr.reshape(-1, 3))
            else:
                # missing pose -> zero delta
                shape = npz_data[names[0]].shape if names[0] in npz_data.files else (0, 3)
                pose_list.append(np.zeros(shape, dtype=np.float32))

        # stack: (num_poses, num_verts, 3) -> transpose to (num_verts, 3, num_poses)
        stacked = np.stack(pose_list, axis=0)  # (P, V, 3)
        return np.transpose(stacked, (1, 2, 0))  # (V, 3, P)

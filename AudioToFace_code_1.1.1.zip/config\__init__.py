from .mapping import ARKIT_BLENDSHAPES

__all__ = [
    'ARKIT_BLENDSHAPES',
]
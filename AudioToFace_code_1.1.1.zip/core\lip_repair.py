"""Lip closure auto-repair module.

Identifies bilabial stop/nasal (b/p/m) closure peaks from phoneme data,
then forces a clean lip closure at the phoneme's midpoint frame by
setting:
    MouthClose   = 1.0   (full closure, equivalent to lip_closure_combined=-1)
    JawOpen      = 0.0    (jaw must be closed for lips to meet)
    MouthLowerDownL/R = 0.0  (lower lip must not pull down)

The peak frame is the midpoint of the bilabial phoneme's time range,
NOT the frame with the highest MouthClose value. This ensures we
always repair at the correct position even when the model fails to
close the lips (MouthClose stays near 0 throughout the segment).

A small window (±N frames) around each peak is adjusted with linear
edge tapering: the peak frame gets factor=1.0 (full closure target),
and the surrounding frames ramp linearly from 0.0 (window boundary)
to 1.0 (peak frame) so the transition into and out of the closure
blends smoothly with the rest of the animation. The caller applies
Gaussian smoothing afterwards, so we keep the taper linear here to
avoid double-smoothing.

This module is intentionally conservative: it only touches frames within
the window around bilabial phoneme midpoints, leaving all other sounds
untouched.
"""

from typing import List, Dict, Any, Tuple, Optional


# Target values applied at the peak frame (factor=1.0).
# These mirror the effect of setting lip_closure_combined = -1:
#   MouthClose multiplier = 1.0 - (-1) = 2.0  -> strong closure
#   JawOpen multiplier    = 1.0 + (-1) = 0.0  -> jaw fully closed
#   MouthLowerDown mult.  = 0.0              -> lower lip stays up
# Using absolute target values here (not multipliers) gives us precise
# control over the peak frame's mouth state regardless of the model's
# original output.
# The target values (MouthClose=1.0, JawOpen=0.0, MouthLowerDown=0.0) and
# the repair algorithm live in the compiled C++ engine
# (a2f_engine.repair_lip_closure).


def _is_bilabial_phoneme(phoneme: str) -> bool:
    """b, p, m are bilabial closure sounds."""
    return phoneme in ('b', 'p', 'm')


def _find_bilabial_segments(phoneme_data: Any) -> List[Tuple[float, float, str]]:
    """Return list of (start_time, end_time, phoneme) for bilabial sounds.

    phoneme_data may be a list of PhonemeSegment objects or dicts.
    Times are in seconds, already including any frame_offset adjustment
    applied upstream (we receive the raw phoneme timeline here).
    """
    segments = []
    if not phoneme_data:
        return segments

    for ph in phoneme_data:
        if hasattr(ph, 'phoneme'):
            p_phoneme = ph.phoneme
            p_type = ph.phoneme_type
            p_start = ph.start
            p_end = ph.end
        else:
            p_phoneme = ph.get('phoneme', '')
            p_type = ph.get('phoneme_type', '')
            p_start = ph.get('start', 0.0)
            p_end = ph.get('end', 0.0)

        if p_type == 'initial' and _is_bilabial_phoneme(p_phoneme):
            segments.append((p_start, p_end, p_phoneme))

    return segments


def repair_lip_closure(
    frames: List[Dict[str, Any]],
    phoneme_data: Any,
    fps: int,
    frame_offset: int = 0,
    window_frames: int = 2,
    frame_range: Optional[Tuple[int, int]] = None,
) -> Tuple[List[Dict[str, Any]], int, set]:
    """Auto-repair bilabial closure issues in the given frames.

    The core repair algorithm (bilabial peak detection, window tapering,
    MouthClose/JawOpen/MouthLowerDown target enforcement) runs in the
    compiled C++ engine (a2f_engine.pyd) to protect the IP. This function
    converts phoneme data to the C++ format, calls the engine, and
    computes modified_indices by diffing original vs repaired frames.

    Args:
        frames: List of {'time': float, 'weights': {name: value}} dicts.
        phoneme_data: PhonemeSegment list (or compatible dicts) from ASR.
        fps: Frame rate.
        frame_offset: Offset of this clip on the timeline (in frames).
        window_frames: Half-window size around each peak (±N frames).
        frame_range: Optional (start, end) absolute timeline frame numbers.

    Returns:
        (repaired_frames, num_repaired_peaks, modified_indices)
    """
    if not frames:
        return [], 0, set()

    fr_start = frame_range[0] if frame_range else 0
    fr_end = frame_range[1] if frame_range else 0

    # Convert phoneme data to C++ format: {phoneme, type, start, end}.
    cpp_phonemes = []
    for ph in (phoneme_data or []):
        if hasattr(ph, 'phoneme'):
            cpp_phonemes.append({
                "phoneme": ph.phoneme,
                "type": ph.phoneme_type,
                "start": float(ph.start),
                "end": float(ph.end),
            })
        else:
            cpp_phonemes.append({
                "phoneme": ph.get('phoneme', ''),
                "type": ph.get('phoneme_type', ''),
                "start": float(ph.get('start', 0.0)),
                "end": float(ph.get('end', 0.0)),
            })

    # Delegate to C++ engine.
    try:
        import a2f_engine as _native
        result = _native.repair_lip_closure(
            frames, cpp_phonemes, int(fps), int(frame_offset),
            int(window_frames), int(fr_start), int(fr_end),
        )
        repaired_frames = result[0]
        num_peaks = result[1]
        # Compute modified_indices by diffing original vs repaired.
        modified_indices = set()
        for i in range(min(len(frames), len(repaired_frames))):
            orig_w = frames[i].get('weights', {})
            new_w = repaired_frames[i].get('weights', {})
            for name, val in new_w.items():
                if abs(orig_w.get(name, 0.0) - val) > 1e-9:
                    modified_indices.add(i)
                    break
            # Also check for removed keys
            if i not in modified_indices:
                for name in orig_w:
                    if name not in new_w or abs(orig_w[name] - new_w.get(name, 0.0)) > 1e-9:
                        modified_indices.add(i)
                        break
        return repaired_frames, num_peaks, modified_indices
    except Exception as e:
        print(f"[LipRepair] C++ engine unavailable ({e}); "
              f"returning frames unchanged")
        return [dict(f) for f in frames], 0, set()


def has_bilabial_phonemes(phoneme_data: Any) -> bool:
    """Quick check whether the phoneme data contains any b/p/m sounds."""
    return len(_find_bilabial_segments(phoneme_data)) > 0

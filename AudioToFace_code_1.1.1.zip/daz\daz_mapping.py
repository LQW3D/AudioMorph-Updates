"""ARKit 52 -> DAZ FACS property mapping.

The DAZ FACS driver chain (set up by the import_daz addon) is:

    rig["<prop>"]                    (Object-level custom property, the slider input)
        ↓  driver on rig.data
    rig.data["<prop>(fin)"]          (Armature data property, the driven output)
        ↓  driver on mesh shape keys
    mesh shape_key["<prop>"].value   (final mesh deformation)

We MUST write keyframes to the Object-level property (the slider input),
never to the (fin) property (which is the driven output). Writing to (fin)
has no effect because (fin) is overridden by its driver on every evaluation.

This module ships two mapping tables, transcribed from the official DAZ
addon JSON files:
    - import_daz/data/facs/genesis81.json  (Genesis 8.1)
    - import_daz/data/facs/genesis9.json   (Genesis 9)

Auto-detection picks the table whose properties actually exist on the rig
Object, so the same code works for both generations without relying on the
optional DazRig RNA marker (which is not always populated).

Notes on bidirectional controllers:
Some DAZ controllers express two opposite ARKit directions on a single
property using a sign. For example:
    EyeLookUpLeft   -> facs_ctrl_EyeLookUp-DownLeft,  +1
    EyeLookDownLeft -> facs_ctrl_EyeLookUp-DownLeft,  -1
The mapping below encodes the sign as the second tuple element, and the
write path multiplies the ARKit weight by this sign.

Notes on _div2 properties (Genesis 8.1 only):
G8.1 FACS blendshape properties whose name ends in "_div2" have a driver
that divides the Object-level input by 2 before driving the mesh shape
key. This means writing value=1.0 to the Object property produces a final
shape key value of 0.5 — half the intended deformation.

To compensate, the scale for all _div2 properties is set to 2.0, so:
    Object prop value = ARKit_weight * 2.0
    Driver output     = Object prop value / 2.0 = ARKit_weight * 1.0
This restores the full deformation strength, matching G9 behavior.
"""

from typing import Dict, List, Tuple


def _detect_generation(rig) -> str:
    """Detect whether the rig is Genesis 8.1 or Genesis 9 by signature props.

    The distinguishing property is the jaw-open input:
      - G8.1 uses a bone-driven property: facs_jnt_JawOpen
      - G9    uses a blendshape property: facs_bs_JawOpen
    Both generations share facs_bs_TongueOut, so that is not a discriminator.

    Returns 'G81', 'G9', or '' if neither signature is found.
    """
    if rig is None:
        return ''
    obj_keys = {k for k in rig.keys() if isinstance(k, str)}
    if 'facs_jnt_JawOpen' in obj_keys:
        return 'G81'
    if 'facs_bs_JawOpen' in obj_keys:
        return 'G9'
    return ''


def get_daz_mapping(rig) -> Dict[str, List[Tuple[str, float]]]:
    """Return ARKit -> [(prop, scale)] mapping for this rig.

    Only properties that actually exist on the rig Object are included, so
    the write path never references a missing property. The (fin) output
    properties on rig.data are NOT consulted, because they are driven
    outputs and their existence does not imply that the matching Object
    property is a valid input.

    The mapping tables, _div2 compensation and generation detection logic
    live in the compiled C++ engine (a2f_engine.pyd) to protect the IP.
    This function extracts the rig's property names in Python
    (Blender-specific), then delegates the table lookup and filtering to
    the native engine.

    Args:
        rig: Blender Object of type ARMATURE (the DAZ control rig).

    Returns:
        Dict mapping ARKit expression name -> list of (prop, scale).
        Empty dict if the rig is not a DAZ FACS rig or the engine is
        unavailable.
    """
    if rig is None or rig.type != 'ARMATURE':
        return {}

    existing_obj_props = {k for k in rig.keys() if isinstance(k, str)}
    if not existing_obj_props:
        return {}

    gen = _detect_generation(rig)
    gen_int = 0 if gen == '' else (1 if gen == 'G81' else 2)

    try:
        import a2f_engine as _native
        props_list = sorted(existing_obj_props)
        return _native.build_daz_mapping(props_list, gen_int)
    except Exception:
        return {}


def detect_daz_rig(rig) -> bool:
    """Return True if the given armature object looks like a DAZ FACS rig.

    Detection is based on the presence of facs_* Object-level properties
    (the slider inputs), not the (fin) driven outputs.
    """
    if rig is None or rig.type != 'ARMATURE':
        return False
    for key in rig.keys():
        if isinstance(key, str) and key.startswith("facs_"):
            return True
    return False


def count_daz_facs_props(rig) -> int:
    """Return the number of FACS input properties on the rig Object."""
    if rig is None:
        return 0
    count = 0
    if hasattr(rig, 'keys'):
        count += sum(1 for k in rig.keys()
                     if isinstance(k, str) and k.startswith("facs_"))
    return count

"""Preset template operators.

Provides three operators (plus a refresh helper) for managing parameter
preset templates stored as JSON files under config/presets/. Templates are
shared by the Animation and DAZ pages: loading applies the template to
whichever page is currently active.

Operators:
1. AUDIO2FACE_OT_save_as_preset
   - Prompts for a name and writes the current page's SDK parameters to
     config/presets/<name>.json.
2. AUDIO2FACE_OT_load_preset
   - Reads the selected preset file and applies it to the current page.
3. AUDIO2FACE_OT_delete_preset
   - Deletes the selected preset file from disk.
4. AUDIO2FACE_OT_refresh_presets
   - Forces the EnumProperty to re-scan the presets folder. Useful after
     external file operations.
"""

import json
import os
import re

import bpy
from bpy.props import StringProperty

from ..properties import _DEFAULT_KEYS, _PRESETS_DIR, _preset_id_to_name
from ..utils.i18n import t, tr


def _current_props(context):
    """Return the property group for the currently active page.

    Only the DAZ page remains; always return scene.audio2face_daz_props.
    """
    return context.scene.audio2face_daz_props


def _sanitize_name(name: str) -> str:
    """Strip path separators and unsafe chars from a user-supplied name.

    The result is used directly as a filename, so we must prevent directory
    traversal and invalid Windows characters.
    """
    if not name:
        return ""
    # Remove characters that are invalid in Windows filenames
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip()
    # Collapse runs of whitespace/underscores
    cleaned = re.sub(r'[\s_]+', '_', cleaned).strip('_.')
    return cleaned


def _collect_settings(props) -> dict:
    """Snapshot the SDK-related fields from a property group."""
    data = {}
    for key in _DEFAULT_KEYS:
        if hasattr(props, key):
            try:
                data[key] = getattr(props, key)
            except Exception:
                pass
    return data


def _apply_settings(props, data: dict):
    """Apply a settings dict to a property group (skip unknown keys)."""
    for key in _DEFAULT_KEYS:
        if key in data and hasattr(props, key):
            try:
                setattr(props, key, data[key])
            except Exception:
                pass


def _preset_path(name: str) -> str:
    return os.path.join(_PRESETS_DIR, f"{name}.json")


class AUDIO2FACE_OT_save_as_preset(bpy.types.Operator):
    """Save the current page's parameters as a named preset template.

    The file is written to config/presets/<name>.json and immediately
    available in the preset dropdown.
    """
    bl_idname = "audio2face.save_as_preset"
    bl_label = t("Save as Preset")
    bl_description = t("Save current parameters as a named preset template")
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: StringProperty(
        name=t("Preset Name"),
        description=t("Name for the new preset template (used as the filename)"),
        default="",
    )

    def execute(self, context):
        name = _sanitize_name(self.preset_name)
        if not name:
            self.report({'ERROR'}, tr("Preset name is empty or invalid"))
            return {'CANCELLED'}

        os.makedirs(_PRESETS_DIR, exist_ok=True)
        path = _preset_path(name)

        props = _current_props(context)
        data = _collect_settings(props)
        data['_meta'] = {
            'name': name,
            'source_page': props.active_page if hasattr(props, 'active_page') else 'ANIMATION',
        }

        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.report({'ERROR'}, tr("Failed to save preset") + f": {e}")
            return {'CANCELLED'}

        # Force the enum to re-scan on next UI draw by triggering a property
        # redraw. Blender caches enum items per session, so we use
        # context.region.tag_redraw() via a harmless property update.
        self.report({'INFO'}, tr("Preset saved") + f": {name}")
        print(f"[Audio2Face] Preset saved: {path}")
        return {'FINISHED'}

    def invoke(self, context, event):
        # Open the rename popup so the user can type a name
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=320)


class AUDIO2FACE_OT_load_preset(bpy.types.Operator):
    """Load the selected preset template into the current page."""
    bl_idname = "audio2face.load_preset"
    bl_label = t("Load Preset")
    bl_description = t("Apply the selected preset template to the current page")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = _current_props(context)
        selection = props.preset_selection
        if not selection or selection == 'NONE':
            self.report({'WARNING'}, tr("No preset selected"))
            return {'CANCELLED'}

        # Translate the ASCII enum identifier back to the real filename stem.
        name = _preset_id_to_name(selection)
        if not name:
            self.report({'ERROR'}, tr("Preset file not found"))
            return {'CANCELLED'}

        path = _preset_path(name)
        if not os.path.exists(path):
            self.report({'ERROR'}, tr("Preset file not found") + f": {name}")
            return {'CANCELLED'}

        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, tr("Failed to load preset") + f": {e}")
            return {'CANCELLED'}

        _apply_settings(props, data)
        self.report({'INFO'}, tr("Preset loaded") + f": {name}")
        print(f"[Audio2Face] Preset loaded: {path}")
        return {'FINISHED'}


class AUDIO2FACE_OT_delete_preset(bpy.types.Operator):
    """Delete the selected preset template file from disk."""
    bl_idname = "audio2face.delete_preset"
    bl_label = t("Delete Preset")
    bl_description = t("Delete the selected preset template file")
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: StringProperty(
        name=t("Preset Name"),
        default="",
    )

    def execute(self, context):
        if not self.preset_name:
            props = _current_props(context)
            # Translate the ASCII enum identifier to the real filename stem.
            self.preset_name = _preset_id_to_name(props.preset_selection)

        if not self.preset_name:
            self.report({'WARNING'}, tr("No preset selected"))
            return {'CANCELLED'}

        path = _preset_path(self.preset_name)
        if not os.path.exists(path):
            self.report({'ERROR'}, tr("Preset file not found"))
            return {'CANCELLED'}

        try:
            os.remove(path)
        except Exception as e:
            self.report({'ERROR'}, tr("Failed to delete preset") + f": {e}")
            return {'CANCELLED'}

        # Reset the dropdown selection
        props = _current_props(context)
        try:
            props.preset_selection = 'NONE'
        except Exception:
            pass

        self.report({'INFO'}, tr("Preset deleted") + f": {self.preset_name}")
        print(f"[Audio2Face] Preset deleted: {path}")
        return {'FINISHED'}

    def invoke(self, context, event):
        # Confirm before deleting
        props = _current_props(context)
        # Translate the ASCII enum identifier to the real filename stem so
        # the confirm dialog shows a human-readable name and execute() gets
        # a valid filename (not 'PRESET_0').
        self.preset_name = _preset_id_to_name(props.preset_selection)
        if not self.preset_name:
            self.report({'WARNING'}, tr("No preset selected"))
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(self, event)


classes = [
    AUDIO2FACE_OT_save_as_preset,
    AUDIO2FACE_OT_load_preset,
    AUDIO2FACE_OT_delete_preset,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

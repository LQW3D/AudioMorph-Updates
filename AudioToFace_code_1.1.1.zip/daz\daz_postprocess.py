"""DAZ mode post-processing operators.

Mirrors operators/apply_adjustments.py but reads/writes the Object-level
facs_* custom property fcurves on the DAZ rig (the slider inputs that
drive the rig.data (fin) chain) instead of mesh shape-key fcurves. The
weight-domain logic (multipliers, MouthClose compensation, Gaussian
smoothing, lip-repair peak detection) is reused from the shared modules:
- core/animation_cache.AnimationCache (segment lookup, original weights)
- core/lip_repair.repair_lip_closure (bilabial peak detection)
- daz_driver.apply_blendshapes_to_daz_rig (final write to rig Object props)

Provides:
- AUDIO2FACE_OT_daz_apply_adjustments: smoothing + closure fine-tuning
- AUDIO2FACE_OT_daz_set_frame_range: set frame range to full animation
- AUDIO2FACE_OT_daz_repair_lip_closure: auto-fix b/p/m bilabial closures
"""

import bpy
from typing import Dict

from ..utils.i18n import t, tr
from ..core import license_manager
from ..core.animation_cache import AnimationCache
from .daz_driver import clamp_daz_prop_value
from .faceit_mapping import get_faceit_mapping
from .faceit_driver import apply_blendshapes_to_faceit_rig


def _get_daz_rig():
    """Resolve the DAZ rig Object from the AnimationCache target_object."""
    rig_name = AnimationCache.get_target_object()
    if not rig_name:
        return None
    return bpy.data.objects.get(rig_name)


def _get_rig_object_fcurves(rig):
    """Return the Object-level facs_* fcurves on the rig's animation action.

    Delegates to daz_driver._get_rig_object_fcurves. If no action exists yet
    (e.g. postprocess invoked before generate), we ensure one is created
    with proper slot binding via _ensure_action_slot, so the same code path
    works on Blender 4.x and 5.x.
    """
    from .daz_driver import _get_rig_object_fcurves as _driver_get_fcurves
    from .daz_driver import _ensure_action_slot
    if rig is None:
        return []
    _ensure_action_slot(rig)
    return _driver_get_fcurves(rig)


def _apply_daz_postprocess(rig, multipliers, frame_start, frame_end,
                           post_smoothing, post_strength):
    """Apply multipliers + smoothing to Object-level facs_* fcurves on rig.

    Strategy mirrors apply_adjustments._apply_from_cache_module:
    1. For each Object-level facs_* fcurve, look up the source ARKit name
       via the cached mapping (reverse lookup).
    2. For each keyframe in [frame_start, frame_end], read the source
       weight from the AnimationCache (which now contains SDK + silence +
       emotion + phoneme — the full data packet B), apply multiplier *
       post_strength, apply the same MouthClose compensation as the write
       path, then Gaussian-smooth.
    3. Write the adjusted values back to the fcurve's keyframe_points.

    Emotion is already baked into the cache baseline (applied at generate
    time before cache storage), so no separate emotion re-apply is needed.
    """
    import a2f_engine as _native

    mapping = AnimationCache.get_mapping()  # arkit_name -> [(obj_prop, scale), ...]
    fps = AnimationCache.get_fps()

    # Build reverse lookup: obj_prop -> (arkit_name, scale).
    # For two-way DAZ controls (e.g. facs_ctrl_EyeLookUp-DownLeft driven by
    # both EyeLookUp at scale +1 and EyeLookDown at scale -1), a single
    # obj_prop maps to multiple (arkit_name, scale) pairs. Storing only the
    # last one would make post-processing divide the fcurve value by the
    # wrong scale, flipping or zeroing the animation. Instead, mark such
    # props as ambiguous and skip them in post-processing (they keep their
    # original values, which is safe because the binding pipeline already
    # wrote correct values during generation).
    prop_to_arkit = {}
    ambiguous_props = set()
    for arkit_name, pairs in mapping.items():
        for obj_prop, scale in pairs:
            if obj_prop in prop_to_arkit:
                # Already mapped to a different arkit_name -> two-way control
                ambiguous_props.add(obj_prop)
            else:
                prop_to_arkit[obj_prop] = (arkit_name, scale)

    # We write to Object-level properties, so animation is on rig.animation_data
    anim_data = rig.animation_data
    if not anim_data or not anim_data.action:
        print("[Audio2Face DAZ] No animation action on rig")
        return

    fcurves = _get_rig_object_fcurves(rig)
    if not fcurves:
        print(f"[Audio2Face DAZ] No fcurves found on {rig.name}")
        return

    # Pre-build frame index from AnimationCache segments.
    # Cache now contains SDK + silence + emotion + phoneme (data packet B),
    # so post-processing reads the full emotion-fused baseline.
    segment_frame_index = {}
    for seg in AnimationCache._segments:
        idx = {}
        for fd in seg.frames:
            fd_frame_num = round(fd.time * seg.fps) + 1
            idx[fd_frame_num] = fd
        segment_frame_index[id(seg)] = idx
    segments_lookup = AnimationCache._segments

    # Pre-build fcurve lookup: prop -> fcurve
    fcurve_by_prop = {}
    for fc in fcurves:
        dp = fc.data_path
        if dp.startswith('["') and dp.endswith('"]'):
            prop_name = dp[2:-2]
            fcurve_by_prop[prop_name] = fc

    for obj_prop, fc in fcurve_by_prop.items():
        # Skip two-way control props: their single fcurve encodes two ARKit
        # weights (positive/negative), so we cannot reverse-lookup a single
        # (arkit_name, scale) pair. Leaving them unchanged is safe.
        if obj_prop in ambiguous_props:
            continue
        arkit_info = prop_to_arkit.get(obj_prop)
        if not arkit_info:
            continue
        arkit_name, scale = arkit_info
        multiplier = multipliers.get(arkit_name, 1.0)

        # Collect original values for keyframes in range.
        original_values = {}
        # Cache per-frame weights for context-aware clamping (f/v detection).
        frame_weights_cache = {}
        for kp in fc.keyframe_points:
            # Use round() rather than int() truncation: Blender stores frame
            # numbers as float, and 11.0 may be stored as 10.9999... which
            # int() would truncate to 10 (off-by-one frame drift).
            frame_num = int(round(kp.co.x))
            if frame_start <= frame_num <= frame_end:
                # Find the matching segment/frame from the index.
                frame_data = None
                for seg in segments_lookup:
                    idx = segment_frame_index.get(id(seg))
                    if idx:
                        # Frame data is keyed by round(time * fps) + 1,
                        # which is relative to audio start. For segments
                        # with frame_offset, the timeline frame number is
                        # frame_offset + relative_frame.
                        relative_frame = frame_num - seg.frame_offset
                        frame_data = idx.get(relative_frame)
                        if frame_data is not None:
                            break
                if frame_data is not None:
                    cached_value = frame_data.weights.get(arkit_name, 0.0)
                    # Cache weights for context-aware clamp in write phase.
                    frame_weights_cache[frame_num] = frame_data.weights
                    # Apply the same MouthClose compensation as the write
                    # path so post-processing matches generation behavior.
                    # The algorithm (weight guard, compensation, max_close cap)
                    # lives in the native engine.
                    if arkit_name == 'MouthClose':
                        jaw_open = frame_data.weights.get('JawOpen', 0.0)
                        cached_value = _native.compensate_mouth_close(
                            cached_value, jaw_open)
                    # The Object property value = arkit_weight * scale.
                    # Post-processing operates in the arkit weight domain,
                    # so divide by scale to recover the weight, then re-multiply
                    # by scale at write time.
                    original_values[frame_num] = cached_value
                else:
                    original_values[frame_num] = kp.co.y / scale if scale != 0 else kp.co.y

        if not original_values:
            continue

        # Apply multiplier + strength.
        adjusted_values = {}
        for frame_num, original_value in original_values.items():
            adjusted_value = original_value * multiplier * post_strength
            adjusted_value = max(-1.0, min(1.0, adjusted_value))
            adjusted_values[frame_num] = adjusted_value

        # Gaussian smoothing.
        if post_smoothing > 0.0 and len(adjusted_values) > 1:
            adjusted_values = _smooth_values(adjusted_values, post_smoothing)

        # Write back to fcurve (re-multiply by scale to get Object prop value).
        updated_count = 0
        for kp in fc.keyframe_points:
            frame_num = int(round(kp.co.x))
            if frame_start <= frame_num <= frame_end and frame_num in adjusted_values:
                prop_value = adjusted_values[frame_num] * scale
                # Apply the SAME clamp as the generation path so post-process
                # does not re-introduce the lip-inversion artifact. Without
                # this, running "Apply Adjustments" would bypass the clamp
                # and write full-scale MouthPress/MouthRoll/MouthShrugLower
                # values back onto the rig (the exact bug that caused severe
                # lip inversion on "妹妹" after applying adjustments).
                fw = frame_weights_cache.get(frame_num)
                prop_value = clamp_daz_prop_value(arkit_name, obj_prop, prop_value, fw)
                kp.co.y = prop_value
                kp.handle_left_type = 'AUTO'
                kp.handle_right_type = 'AUTO'
                updated_count += 1

        fc.update()

    print(f"[Audio2Face DAZ] Post-process done: rig={rig.name}, "
          f"range={frame_start}-{frame_end}, smoothing={post_smoothing}, "
          f"strength={post_strength}")


def _smooth_values(values_dict, smoothing):
    """Gaussian smoothing on a {frame_num: value} dict (same as mesh path).

    The Gaussian kernel / window / sigma math runs in the compiled C++ engine
    (a2f_engine.gaussian_smooth) to protect the post-processing recipe.
    """
    if not values_dict or smoothing <= 0.0:
        return values_dict

    sorted_frames = sorted(values_dict.keys())
    sorted_values = [values_dict[f] for f in sorted_frames]

    import a2f_engine as _native
    smoothed = _native.gaussian_smooth(sorted_values, smoothing)

    return {f: smoothed[i] for i, f in enumerate(sorted_frames)}


def _smooth_arkit_weights(frames, smoothing):
    """Apply Gaussian smoothing to each ARKit weight across frames.

    Mirrors operators/apply_adjustments._smooth_arkit_weights but operates
    on BlendshapeFrame lists for the rebuild-based postprocess path used
    by Faceit rigs. The Gaussian kernel math runs in the C++ engine.
    """
    if not frames or smoothing <= 0.0:
        return

    all_names = set()
    for frame in frames:
        all_names.update(frame.weights.keys())

    import a2f_engine as _native
    for name in all_names:
        values = [frame.weights.get(name, 0.0) for frame in frames]
        if len(values) < 3:
            continue
        smoothed = _native.gaussian_smooth(values, smoothing)
        for i, frame in enumerate(frames):
            frame.weights[name] = smoothed[i]


def _apply_faceit_postprocess(rig, multipliers, frame_start, frame_end,
                               post_smoothing, post_strength):
    """Apply multipliers + smoothing to Faceit pose bone animation.

    Uses the rebuild approach (same as operators/apply_adjustments.
    _apply_postprocess_to_rig for A2F_RIG):
    1. Read segments from AnimationCache (contains SDK+silence+emotion+phoneme)
    2. For each segment overlapping [frame_start, frame_end]:
       - Copy frames, apply multipliers * post_strength
       - Apply Gaussian smoothing to ARKit weight time series
       - Write via apply_blendshapes_to_faceit_rig
    3. Segments completely outside the range are skipped so the user can
       independently adjust one segment without rewriting others.
    """
    from ..core.blendshape import BlendshapeFrame

    segments = AnimationCache._segments
    if not segments:
        print("[Audio2Face Faceit] Post-process: no cached segments")
        return

    fps = AnimationCache.get_fps()
    mapping = get_faceit_mapping(rig)
    if not mapping:
        print(f"[Audio2Face Faceit] Post-process: no Faceit mapping on {rig.name}")
        return

    strength = post_strength if post_strength > 0 else 1.0
    has_multipliers = bool(multipliers)

    processed_count = 0
    skipped_count = 0
    for seg in segments:
        seg_offset = seg.frame_offset
        if not seg.frames:
            continue

        seg_start = round(seg.frames[0].time * fps) + 1 + seg_offset
        seg_end = round(seg.frames[-1].time * fps) + 1 + seg_offset

        if seg_end < frame_start or seg_start > frame_end:
            skipped_count += 1
            continue

        # Copy frames from cache (preserves phoneme correction + emotion).
        frames = []
        for fd in seg.frames:
            frames.append(BlendshapeFrame(
                time=fd.time,
                weights=dict(fd.weights),
            ))
        if not frames:
            continue

        # Apply multipliers + post_strength within the user's frame range.
        if has_multipliers or strength != 1.0:
            for frame in frames:
                rel_frame = round(frame.time * fps) + 1 + seg_offset
                if frame_start <= rel_frame <= frame_end:
                    new_weights = {}
                    for arkit_name, weight in frame.weights.items():
                        multiplier = multipliers.get(arkit_name, 1.0)
                        new_weight = weight * multiplier * strength
                        new_weight = max(-1.0, min(1.0, new_weight))
                        new_weights[arkit_name] = new_weight
                    frame.weights = new_weights

        # Gaussian smoothing on ARKit weight time series (pre-write).
        if post_smoothing > 0.0 and len(frames) > 1:
            _smooth_arkit_weights(frames, post_smoothing)

        # Write to Faceit pose bones. apply_blendshapes_to_faceit_rig
        # overwrites keyframes in this segment's range; segments outside
        # [frame_start, frame_end] are untouched (skipped above).
        apply_blendshapes_to_faceit_rig(
            rig, frames, mapping,
            fps=fps, frame_offset=seg_offset,
        )
        processed_count += 1

    print(f"[Audio2Face Faceit] Post-process: processed {processed_count} segments "
          f"(skipped {skipped_count} out of range), "
          f"multipliers={'yes' if has_multipliers else 'no'}, smoothing={post_smoothing}")


def _apply_postprocess_dispatch(rig, multipliers, frame_start, frame_end,
                                 post_smoothing, post_strength):
    """Dispatch post-process by cached target_type.

    - DAZ_RIG:    fcurve-based path (reads/writes Object-level facs_* props)
    - FACEIT_RIG: rebuild path (reads cache, re-writes pose bone transforms)
    """
    target_type = AnimationCache.get_target_type()
    if target_type == 'FACEIT_RIG':
        _apply_faceit_postprocess(
            rig, multipliers, frame_start, frame_end,
            post_smoothing, post_strength,
        )
    else:
        _apply_daz_postprocess(
            rig, multipliers, frame_start, frame_end,
            post_smoothing, post_strength,
        )


class AUDIO2FACE_OT_daz_apply_adjustments(bpy.types.Operator):
    bl_idname = "audio2face.daz_apply_adjustments"
    bl_label = t("Apply Adjustments to Animation Curves")
    bl_description = t("Apply parameter adjustments to DAZ FACS animation curves in the specified frame range")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        return AnimationCache.has_data() and _get_daz_rig() is not None

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        props = context.scene.audio2face_daz_props

        if not AnimationCache.has_data():
            self.report({'ERROR'}, tr("No animation data, please generate first"))
            return {'CANCELLED'}

        frame_start = props.frame_start
        frame_end = props.frame_end
        if frame_start > frame_end:
            self.report({'ERROR'}, tr("Start frame cannot be greater than end frame"))
            return {'CANCELLED'}

        rig = _get_daz_rig()
        if rig is None:
            self.report({'ERROR'}, tr("DAZ rig not found"))
            return {'CANCELLED'}

        multipliers = self._build_multipliers(props)

        # Dispatch by cached target_type: DAZ_RIG uses the fcurve path,
        # FACEIT_RIG uses the rebuild path. Both read the same cache
        # baseline (SDK + silence + emotion + phoneme).
        _apply_postprocess_dispatch(
            rig, multipliers, frame_start, frame_end,
            props.post_smoothing, props.post_strength,
        )

        self.report({'INFO'}, tr("Applied adjustments to frames") + f" {frame_start}-{frame_end}")
        return {'FINISHED'}

    def _build_multipliers(self, props) -> Dict[str, float]:
        """Build per-ARKit multipliers (same logic as apply_adjustments.py).

        The channel grouping, the 1.0±v lip-closure formula and the
        mouth_scale / pucker_scale / mouth_stretch_scale channel sets live
        in the compiled C++ engine
        (a2f_engine.build_postprocess_multipliers).
        """
        params = {
            "lip_closure_combined": float(getattr(props, "lip_closure_combined", 0.0)),
            "mouth_close_adjust": float(getattr(props, "mouth_close_adjust", 0.0)),
            "jaw_open_adjust": float(getattr(props, "jaw_open_adjust", 0.0)),
            "mouth_lower_down_adjust": float(getattr(props, "mouth_lower_down_adjust", 0.0)),
            "mouth_scale": float(getattr(props, "mouth_scale", 1.0)),
            "pucker_scale": float(getattr(props, "pucker_scale", 1.0)),
            "mouth_stretch_scale": float(getattr(props, "mouth_stretch_scale", 1.0)),
        }
        try:
            import a2f_engine as _native
            return _native.build_postprocess_multipliers(params)
        except Exception as e:
            print(f"[Audio2Face DAZ] C++ engine unavailable ({e}); using empty multipliers")
            return {}


class AUDIO2FACE_OT_daz_set_frame_range(bpy.types.Operator):
    bl_idname = "audio2face.daz_set_frame_range"
    bl_label = t("Set Frame Range")
    bl_description = t("Set the frame range to the full animation range")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return AnimationCache.has_data()

    def execute(self, context):
        props = context.scene.audio2face_daz_props

        if not AnimationCache.has_data():
            self.report({'ERROR'}, tr("No animation data"))
            return {'CANCELLED'}

        frame_start, frame_end = AnimationCache.get_frame_range()
        props.frame_start = frame_start
        props.frame_end = frame_end
        self.report({'INFO'}, f"{tr('Frame range set to')} {frame_start}-{frame_end}")
        return {'FINISHED'}


class AUDIO2FACE_OT_daz_repair_lip_closure(bpy.types.Operator):
    """Auto-repair bilabial closure (b/p/m).

    Reuses core/lip_repair.repair_lip_closure for peak detection, then
    writes repaired frames back to the rig. Dispatch by cached
    target_type: DAZ_RIG writes Object-level facs_* props, FACEIT_RIG
    writes pose bone transforms.
    """
    bl_idname = "audio2face.daz_repair_lip_closure"
    bl_label = t("Repair Lip Closure")
    bl_description = t("Auto-detect and fix bilabial closure issues (b/p/m sounds)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        return (AnimationCache.has_data()
                and AnimationCache.has_phoneme_data()
                and _get_daz_rig() is not None)

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        props = context.scene.audio2face_daz_props

        from ..core.lip_repair import repair_lip_closure, has_bilabial_phonemes

        if not AnimationCache.has_data():
            self.report({'ERROR'}, tr("No animation data, please generate first"))
            return {'CANCELLED'}
        if not AnimationCache.has_phoneme_data():
            self.report({'ERROR'}, tr("No phoneme data, enable phoneme correction and regenerate"))
            return {'CANCELLED'}

        phoneme_data = AnimationCache.get_phoneme_data()
        if not has_bilabial_phonemes(phoneme_data):
            self.report({'INFO'}, tr("No bilabial sounds (b/p/m) detected, nothing to repair"))
            return {'FINISHED'}

        fps = AnimationCache.get_fps()
        frame_offset = AnimationCache.get_phoneme_frame_offset()

        segment = AnimationCache.get_segment_by_offset(frame_offset)
        if not segment or not segment.frames:
            self.report({'ERROR'}, tr("No animation segment found for this clip"))
            return {'CANCELLED'}

        # Convert segment frames to dict format for lip_repair.
        frames_dicts = []
        for f in segment.frames:
            if hasattr(f, 'time'):
                frames_dicts.append({'time': f.time, 'weights': dict(f.weights)})
            else:
                frames_dicts.append({'time': f['time'], 'weights': dict(f['weights'])})

        repaired_frames, num_peaks, modified_indices = repair_lip_closure(
            frames_dicts,
            phoneme_data,
            fps,
            frame_offset=frame_offset,
            window_frames=2,
            frame_range=(props.frame_start, props.frame_end),
        )

        if num_peaks == 0:
            self.report({'INFO'}, tr("No closure peaks detected, nothing to repair"))
            return {'FINISHED'}

        # Mirror repaired frames back into the cache segment so a subsequent
        # Apply Adjustments reads the repaired values as the new baseline.
        for i, frame in enumerate(repaired_frames):
            if i in modified_indices and i < len(segment.frames):
                seg_frame = segment.frames[i]
                if hasattr(seg_frame, 'weights'):
                    seg_frame.weights = dict(frame['weights'])
                else:
                    seg_frame['weights'] = dict(frame['weights'])

        # Re-write the full repaired segment to the rig.
        # Dispatch by cached target_type: DAZ -> facs_* props, Faceit ->
        # pose bone transforms. Both use the same repaired weight frames.
        from ..core.blendshape import BlendshapeFrame
        from .daz_mapping import get_daz_mapping
        from .daz_driver import apply_blendshapes_to_daz_rig

        rig = _get_daz_rig()
        if rig is None:
            self.report({'ERROR'}, tr("rig not found"))
            return {'CANCELLED'}

        target_type = AnimationCache.get_target_type()
        bs_frames = [
            BlendshapeFrame(time=f['time'], weights=f['weights'])
            for f in repaired_frames
        ]

        if target_type == 'FACEIT_RIG':
            mapping = get_faceit_mapping(rig)
            apply_blendshapes_to_faceit_rig(
                rig, bs_frames, mapping,
                fps=fps, frame_offset=frame_offset,
            )
        else:
            mapping = get_daz_mapping(rig)
            apply_blendshapes_to_daz_rig(
                rig, bs_frames, mapping,
                fps=fps, frame_offset=frame_offset,
            )

        # Run the same smoothing pass as Apply Adjustments so the repaired
        # frames blend naturally with neighbors. Dispatch by target_type.
        _apply_postprocess_dispatch(
            rig,
            multipliers={},
            frame_start=props.frame_start,
            frame_end=props.frame_end,
            post_smoothing=props.post_smoothing,
            post_strength=props.post_strength if props.post_strength > 0 else 1.0,
        )

        print(f"[Audio2Face {target_type}] Lip repair: fixed {num_peaks} peaks, "
              f"{len(modified_indices)} frames modified")
        self.report({'INFO'}, f"{tr('Repaired bilabial closure peaks')}: {num_peaks}")
        return {'FINISHED'}


classes = [
    AUDIO2FACE_OT_daz_apply_adjustments,
    AUDIO2FACE_OT_daz_set_frame_range,
    AUDIO2FACE_OT_daz_repair_lip_closure,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

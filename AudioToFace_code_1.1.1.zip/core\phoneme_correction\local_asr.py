"""Local offline ASR using Sherpa-ONNX + SenseVoice.

Completely offline, no network needed.

SenseVoice advantages over Paraformer-small:
  - REAL character-level timestamps (CTC decoding)
  - Punctuation support (use_itn=True)
  - 5 languages: zh/yue/en/ja/ko
  - Extra outputs: language, emotion, event tags

Pipeline:
    1. Load audio with librosa (any format -> 16kHz mono float32)
    2. Recognize with SenseVoice (int8, ~226MB)
    3. Extract REAL char-level timestamps from result.tokens + result.timestamps
    4. Split text into utterances by punctuation
    5. Build utterance-level timestamps from char timestamps

The char-level timestamps are consumed by speech_analyzer.get_phonemes_from_chars()
to drive the b/p/m lip correction pass.

Blender 5.0 workaround:
    Blender 5.0 ships with onnxruntime 1.19.2, which conflicts with sherpa-onnx
    requiring onnxruntime 1.27+. For Blender 5.0, ASR runs in a subprocess
    to avoid the DLL conflict.
"""

import os
import re
import sys
import json
import tempfile
import subprocess
import logging
from typing import Optional, List, Dict

try:
    import bpy
    BLENDER_VERSION = bpy.app.version
except ImportError:
    BLENDER_VERSION = (0, 0, 0)

try:
    import numpy as np
except ImportError:
    np = None

logger = logging.getLogger(__name__)

_USE_SUBPROCESS = False

# Blender 5.0 ships with onnxruntime 1.19.2, conflicting with sherpa-onnx 1.13.4 (requires 1.27+)
if BLENDER_VERSION[0] == 5 and BLENDER_VERSION[1] == 0:
    _USE_SUBPROCESS = True
else:
    # Other versions: detect whether the DML version of onnxruntime is used
    # The DML version of onnxruntime 1.19.2 also conflicts with sherpa-onnx 1.13.4
    # After the main process has loaded the DML version of onnxruntime, importing sherpa_onnx fails DLL initialization
    try:
        # device_config.json lives in Blender's user config dir since the
        # device-detection migration (see core/device_detector._get_config_path).
        # Subprocess workers receive the path via A2F_DEVICE_CONFIG.
        _config_path = os.environ.get("A2F_DEVICE_CONFIG")
        if not _config_path:
            try:
                import bpy as _bpy
                _cfg_dir = _bpy.utils.user_resource('CONFIG')
                if _cfg_dir:
                    _config_path = os.path.join(_cfg_dir, "device_config.json")
            except Exception:
                pass
        if not _config_path:
            _config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                "device_config.json")
        with open(_config_path, "r", encoding="utf-8") as _f:
            import json as _json
            _cfg = _json.load(_f)
        _py_ver = f"cp{sys.version_info.major}{sys.version_info.minor}"
        if _cfg.get("python_version") == _py_ver and _cfg.get("provider") == "DmlExecutionProvider":
            _USE_SUBPROCESS = True
    except Exception:
        pass


# ---------------------------------------------------------------------------
# ASR result container
# ---------------------------------------------------------------------------

class ASRResult:
    """Utterance-level ASR result.

    Attributes:
        text: recognized text for this utterance
        start_time: utterance start time in seconds
        end_time: utterance end time in seconds
    """

    def __init__(self, text: str, start_time: float, end_time: float):
        self.text = text
        self.start_time = start_time
        self.end_time = end_time


# ---------------------------------------------------------------------------
# Model path resolution
# ---------------------------------------------------------------------------

def _get_model_dir() -> str:
    """Return absolute path to models/asr_local/."""
    # core/phoneme_correction/local_asr.py -> addon root
    addon_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(addon_root, "models", "asr_local")


def _get_model_files() -> Dict[str, str]:
    """Return dict of model file paths."""
    d = _get_model_dir()
    return {
        "model": os.path.join(d, "model.int8.onnx"),
        "tokens": os.path.join(d, "tokens.txt"),
    }


# ---------------------------------------------------------------------------
# Chinese text helpers
# ---------------------------------------------------------------------------

# Chinese punctuation that splits utterances
_UTTERANCE_SPLIT_RE = re.compile(r'(?<=[，。！？；,\.!?;])')


def _is_chinese_char(c: str) -> bool:
    """True if c is a CJK Unified Ideograph."""
    return '\u4e00' <= c <= '\u9fff'


def _count_chinese(s: str) -> int:
    return sum(1 for c in s if _is_chinese_char(c))


def _split_into_utterances(text: str) -> List[str]:
    """Split recognized text into utterances by punctuation."""
    parts = _UTTERANCE_SPLIT_RE.split(text)
    return [p.strip() for p in parts if p.strip()]


# ---------------------------------------------------------------------------
# LocalASR
# ---------------------------------------------------------------------------

class LocalASR:
    """Local offline ASR backend using Sherpa-ONNX + SenseVoice.

    Interface:
      - recognize(audio_path, callback) -> List[ASRResult]
      - get_last_task_resp() -> dict (marker for local mode)
      - get_chars_with_timestamps(task_resp) -> List[Dict]
      - get_text(results) -> str
      - get_words_with_timestamps(results) -> List[Dict]
    """

    # Class-level singleton: the SenseVoice recognizer (226MB) is expensive
    # to load (~3-5s). Cache it across instances so repeated "Generate
    # Animation" calls don't reload the model.
    _shared_recognizer = None

    # Class-level shared char-level timestamps. CRITICAL:
    # SpeechAnalyzer is instantiated twice in generate.py (once in _run_asr,
    # once in _apply_phoneme_correction), each holding its own LocalASR
    # instance. Without this shared cache, the second instance's _chars is
    # empty, causing get_phonemes_from_chars() to fall back to utterance-level
    # uniform time distribution (each char gets equal slice of utterance
    # duration) — this misaligns phoneme correction with actual audio by
    # 0.5s+, causing severe lip poke-through.
    _shared_chars: List[Dict] = []
    _shared_utterances: List["ASRResult"] = []

    def __init__(self):
        if np is None:
            raise ImportError("numpy not available")
        self._recognizer = None
        self._audio_duration = 0.0
        self._full_text = ""
        self._utterances: List[ASRResult] = []
        self._chars: List[Dict] = []  # real char-level timestamps from SenseVoice
        self._task_resp = {"local": True}  # marker so get_phonemes_from_chars works

    def _ensure_recognizer(self):
        """Lazy-load the SenseVoice recognizer (first call).

        Uses class-level singleton to avoid reloading the 226MB model on
        every LocalASR instance. This saves ~3-5s on repeated Generate
        Animation calls.
        """
        if self._recognizer is not None:
            return

        # Reuse shared recognizer if already loaded
        if LocalASR._shared_recognizer is not None:
            self._recognizer = LocalASR._shared_recognizer
            return

        try:
            import sherpa_onnx
        except ImportError as e:
            raise ImportError(
                "sherpa_onnx not available. "
                "Please ensure pylibs/sherpa_onnx or pylibs_cp313/sherpa_onnx is installed."
            ) from e

        files = _get_model_files()
        if not os.path.isfile(files["model"]):
            raise FileNotFoundError(
                f"SenseVoice model not found: {files['model']}. "
                "Please ensure models/asr_local/model.int8.onnx exists."
            )

        # use_itn=True enables inverse text normalization -> adds punctuation
        # Punctuation is critical for splitting utterances correctly
        LocalASR._shared_recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
            model=files["model"],
            tokens=files["tokens"],
            num_threads=2,
            use_itn=True,
            language="auto",
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
        )
        self._recognizer = LocalASR._shared_recognizer

    def recognize(self, audio_path: str = None, audio_bytes: bytes = None, callback=None) -> List[ASRResult]:
        """Recognize audio file, return list of ASRResult (utterance-level)."""
        if audio_path is None and audio_bytes is None:
            raise ValueError("No audio provided")

        if _USE_SUBPROCESS:
            return self._recognize_via_subprocess(audio_path, audio_bytes, callback)

        self._ensure_recognizer()

        if callback:
            callback(5, "Loading audio...")

        try:
            import librosa
        except ImportError as e:
            raise ImportError("librosa not available for audio loading") from e

        if audio_path:
            audio, sr = librosa.load(audio_path, sr=16000, mono=True)
        else:
            import io as _io
            audio, sr = librosa.load(_io.BytesIO(audio_bytes), sr=16000, mono=True)

        self._audio_duration = len(audio) / float(sr)

        if callback:
            callback(30, "Recognizing...")

        stream = self._recognizer.create_stream()
        stream.accept_waveform(sr, audio)
        self._recognizer.decode_stream(stream)
        result = stream.result
        self._full_text = result.text.strip()

        tokens = list(result.tokens)
        timestamps = list(result.timestamps)

        if callback:
            callback(70, "Building timestamps...")

        self._build_timestamps(tokens, timestamps, audio, sr)

        LocalASR._shared_chars = self._chars
        LocalASR._shared_utterances = self._utterances

        if callback:
            callback(100, "Done")

        return self._utterances

    def _recognize_via_subprocess(self, audio_path: str = None, audio_bytes: bytes = None, callback=None) -> List[ASRResult]:
        """Recognize audio via subprocess (Blender 5.0 workaround for onnxruntime conflict)."""
        if callback:
            callback(5, "Starting ASR worker...")

        if audio_bytes is not None:
            fd, temp_audio_path = tempfile.mkstemp(suffix='.wav')
            try:
                os.write(fd, audio_bytes)
            finally:
                os.close(fd)
            audio_path = temp_audio_path
        elif audio_path is None:
            raise ValueError("No audio provided")

        worker_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'asr_worker.py'
        )

        model_dir = _get_model_dir()

        fd, output_path = tempfile.mkstemp(suffix='.json')
        os.close(fd)

        python_exe = os.path.join(sys.prefix, 'bin', 'python.exe')
        if not os.path.exists(python_exe):
            python_exe = sys.executable

        try:
            cmd = [
                python_exe,
                worker_path,
                '--audio_path', audio_path,
                '--model_dir', model_dir,
                '--output', output_path,
            ]

            if callback:
                callback(30, "Recognizing...")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode != 0:
                raise RuntimeError(
                    f"ASR worker failed (code={result.returncode}):\n"
                    f"STDOUT: {result.stdout}\nSTDERR: {result.stderr}"
                )

            with open(output_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not data.get('success'):
                raise RuntimeError(f"ASR failed: {data.get('error', 'unknown')}")

            self._full_text = data.get('full_text', '')
            self._audio_duration = data.get('duration', 0.0)

            tokens = data.get('tokens', [])
            timestamps = data.get('timestamps', [])
            # silence_regions was computed in the subprocess to avoid numpy
            # RecursionError in Blender 5.0's main process
            silence_regions = data.get('silence_regions', [])

            if callback:
                callback(70, "Building timestamps...")

            # No need to load audio in main process — silence_regions is
            # already computed by the worker. Passing audio=None avoids
            # triggering numpy operations that crash in Blender 5.0.
            self._build_timestamps(
                tokens, timestamps, audio=None, sr=16000,
                silence_regions=silence_regions,
            )

            LocalASR._shared_chars = self._chars
            LocalASR._shared_utterances = self._utterances

            if callback:
                callback(100, "Done")

            return self._utterances

        finally:
            if output_path and os.path.exists(output_path):
                os.remove(output_path)
            if audio_bytes is not None and audio_path and os.path.exists(audio_path):
                os.remove(audio_path)

    def _detect_silence_regions(self, audio, sr: int, frame_ms: int = 30) -> List[tuple]:
        """Detect silence regions in audio using energy analysis.

        Returns list of (start_sec, end_sec) tuples for silence regions
        longer than 150ms. Used to create gaps between char timestamps so
        the phoneme corrector returns None during silence (preserving
        model output instead of applying adjacent char's viseme).

        This solves the "mouth jitter during pauses" issue: without gaps,
        contiguous char timestamps cause corrector to apply phoneme
        correction during inter-sentence pauses, making the mouth move
        when it should be relaxed.

        The energy VAD runs in the compiled C++ engine
        (a2f_engine.detect_silence_regions).
        """
        if np is None or len(audio) == 0:
            return []
        frame_size = int(sr * frame_ms / 1000)
        if frame_size < 1:
            return []
        if len(audio) // frame_size < 2:
            return []
        try:
            import a2f_engine as _native
            return [
                (float(s), float(e))
                for s, e in _native.detect_silence_regions(audio, float(sr), int(frame_ms))
            ]
        except Exception as e:
            print(f"[Audio2Face ASR] C++ engine unavailable ({e}); skipping VAD trimming")
            return []

    def _trim_char_to_speech(self, char_start: float, char_end: float,
                              silence_regions: List[tuple]) -> tuple:
        """Trim silence from a char's [start, end] range.

        If silence overlaps char boundaries, trim the char to only cover
        actual speech. This creates gaps between chars where silence was,
        so the phoneme corrector returns None during those gaps.

        Conservative trimming: only trim if the silence covers a significant
        portion of the char's boundary. Min char duration is 50ms to avoid
        zero-length segments.

        The trimming logic runs in the compiled C++ engine
        (a2f_engine.trim_char_to_speech).
        """
        if not silence_regions:
            return char_start, char_end
        try:
            import a2f_engine as _native
            return _native.trim_char_to_speech(
                float(char_start), float(char_end),
                [[float(s), float(e)] for s, e in silence_regions],
            )
        except Exception as e:
            print(f"[Audio2Face ASR] C++ engine unavailable ({e}); skipping trim")
            return char_start, char_end

    def _build_timestamps(self, tokens: List[str], timestamps: List[float],
                          audio=None, sr: int = 16000, silence_regions=None):
        """Build char-level and utterance-level timestamps from SenseVoice output.

        SenseVoice outputs one timestamp per token (token start time in seconds).
        For Chinese, each token is a single character (including punctuation).

        VAD trimming: We detect silence regions via energy analysis and trim
        them from char timestamps. This creates gaps between chars/sentences
        where the phoneme corrector returns None (preserving model output).
        This solves two issues:
        1. Mouth jitter during pauses: without gaps, corrector applies
           adjacent char's viseme during silence, making mouth move when
           it should be relaxed.
        2. Bilabial poke-through: now solved by apply_adjustments max_close
           cap, so silence regions can safely preserve model output.

        Silence regions > 150ms are trimmed (shorter pauses are natural
        intra-sentence gaps, kept absorbed in char durations).
        """
        self._utterances = []
        self._chars = []

        if not tokens or not timestamps or len(tokens) != len(timestamps):
            return

        # Detect silence regions for VAD trimming.
        # If silence_regions was pre-computed by the subprocess worker
        # (Blender 5.0 mode), use it directly. Otherwise compute it here
        # from the audio signal (Blender 5.2 direct mode).
        if silence_regions is None:
            silence_regions = []
            if audio is not None:
                silence_regions = self._detect_silence_regions(audio, sr)

        # Build char-level timestamps (Chinese chars only, skip punctuation/spaces)
        # Trim silence from char boundaries to create inter-char gaps
        raw_chars = []
        for i, (tok, ts) in enumerate(zip(tokens, timestamps)):
            if i + 1 < len(timestamps):
                end = timestamps[i + 1]
            else:
                end = self._audio_duration

            if not _is_chinese_char(tok):
                continue

            # Trim silence from char timestamps to create gaps
            trimmed_start, trimmed_end = self._trim_char_to_speech(
                float(ts), float(end), silence_regions
            )

            raw_chars.append({
                'char': tok,
                'start': trimmed_start,
                'end': trimmed_end,
                'conf': 1.0,
            })

        self._chars = raw_chars

        if not self._chars:
            if self._full_text:
                self._utterances.append(ASRResult(
                    text=self._full_text,
                    start_time=0.0,
                    end_time=self._audio_duration,
                ))
            return

        # Build utterance-level timestamps by splitting text on punctuation
        utterance_texts = _split_into_utterances(self._full_text)
        if not utterance_texts:
            utterance_texts = [self._full_text]

        char_idx = 0
        for u_text in utterance_texts:
            u_chinese_count = _count_chinese(u_text)
            if u_chinese_count == 0:
                continue

            if char_idx + u_chinese_count > len(self._chars):
                u_chars = self._chars[char_idx:]
                char_idx = len(self._chars)
            else:
                u_chars = self._chars[char_idx:char_idx + u_chinese_count]
                char_idx += u_chinese_count

            if not u_chars:
                continue

            u_start = u_chars[0]['start']
            u_end = u_chars[-1]['end']
            self._utterances.append(ASRResult(
                text=u_text,
                start_time=u_start,
                end_time=u_end,
            ))

    def get_last_task_resp(self) -> Optional[Dict]:
        """Return marker dict so get_phonemes_from_chars can be called."""
        return self._task_resp if self._chars else None

    def get_chars_with_timestamps(self, task_resp: Dict) -> List[Dict]:
        """Return real char-level timestamps from SenseVoice.

        Falls back to class-level shared cache if this instance's _chars
        is empty (which happens when a new SpeechAnalyzer/LocalASR is
        created in _apply_phoneme_correction after ASR was already run
        in _run_asr with a different instance).
        """
        if self._chars:
            return self._chars
        # Fallback to class-level shared cache populated by a previous
        # recognize() call on another instance.
        return LocalASR._shared_chars

    def get_text(self, results: List[ASRResult]) -> str:
        return ''.join([r.text for r in results])

    def get_words_with_timestamps(self, results: List[ASRResult]) -> List[Dict]:
        words = []
        for result in results:
            words.append({
                'word': result.text,
                'start': result.start_time,
                'end': result.end_time,
                'conf': 1.0,
            })
        return words

    # -----------------------------------------------------------------------
    # Timestamp realignment based on acoustic boundary detection
    # -----------------------------------------------------------------------

    @staticmethod
    def _detect_speech_segments(
        audio, sr: int,
        frame_ms: int = 30,
        top_db: int = 40,
        min_speech_ms: int = 80,
        min_silence_ms: int = 150,
    ) -> List[tuple]:
        """Detect speech segments in audio using energy-based VAD + librosa effects.split.

        This is more robust than the simple energy threshold in _detect_silence_regions
        because it uses librosa's adaptive thresholding (top_db) which handles varying
        background noise levels across the audio file.

        Args:
            audio: numpy float32 array (16kHz mono)
            sr: sample rate (typically 16000)
            frame_ms: frame size in ms for internal analysis
            top_db: threshold (in dB) below the signal peak considered silence
            min_speech_ms: minimum speech segment duration in ms
            min_silence_ms: minimum silence gap duration in ms

        Returns:
            List of (start_sec, end_sec) tuples for detected speech segments.
            Segments are non-overlapping and sorted by start time.
        """
        if np is None or len(audio) == 0:
            return []

        try:
            import librosa
        except ImportError:
            # Fallback: use our simple energy detector
            silence = LocalASR._detect_silence_regions_static(audio, sr, frame_ms)
            # Invert silence regions to get speech regions
            speech = []
            prev_end = 0.0
            for sil_start, sil_end in silence:
                if prev_end < sil_start:
                    speech.append((prev_end, sil_start))
                prev_end = sil_end
            duration = len(audio) / float(sr)
            if prev_end < duration:
                speech.append((prev_end, duration))
            return speech

        # librosa.effects.split returns (sample_start, sample_end) based on
        # an adaptive threshold. We post-process to merge short gaps and
        # remove too-short segments.
        try:
            frame_length = max(256, int(sr * frame_ms / 1000))
            # Ensure frame_length is power of 2 for STFT
            import math as _m
            frame_length = 2 ** int(_m.ceil(_m.log2(frame_length)))
            hop_length = frame_length // 4

            boundaries = librosa.effects.split(
                audio,
                top_db=top_db,
                frame_length=frame_length,
                hop_length=hop_length,
            )
        except Exception:
            boundaries = np.array([], dtype=np.int64).reshape(0, 2)

        if len(boundaries) == 0:
            return []

        # Convert sample indices to seconds
        segments = [(float(s) / sr, float(e) / sr) for s, e in boundaries]

        # Merge segments separated by less than min_silence_ms (keep intra-word
        # gaps from splitting a single syllable cluster into multiple segments)
        min_silence_sec = min_silence_ms / 1000.0
        merged = []
        for seg in segments:
            if not merged:
                merged.append(list(seg))
            else:
                gap = seg[0] - merged[-1][1]
                if gap < min_silence_sec:
                    # Extend previous segment to cover the gap
                    merged[-1][1] = seg[1]
                else:
                    merged.append(list(seg))

        # Remove segments shorter than min_speech_ms (transient clicks, etc.)
        min_speech_sec = min_speech_ms / 1000.0
        merged = [(s, e) for s, e in merged if (e - s) >= min_speech_sec]

        return merged

    @staticmethod
    def _detect_silence_regions_static(audio, sr: int, frame_ms: int = 30) -> List[tuple]:
        """Static version of _detect_silence_regions for use in @staticmethod contexts.

        Runs in the compiled C++ engine (a2f_engine.detect_silence_regions).
        """
        if np is None or len(audio) == 0:
            return []
        frame_size = int(sr * frame_ms / 1000)
        if frame_size < 1:
            return []
        if len(audio) // frame_size < 2:
            return []
        try:
            import a2f_engine as _native
            return [
                (float(s), float(e))
                for s, e in _native.detect_silence_regions(audio, float(sr), int(frame_ms))
            ]
        except Exception as e:
            print(f"[Audio2Face ASR] C++ engine unavailable ({e}); no silence regions")
            return []

    @staticmethod
    def redistribute_timestamps_by_audio(
        edited_text: str,
        audio_path: str = None,
        audio_bytes: bytes = None,
    ) -> List[Dict]:
        """Re-distribute edited Chinese characters onto timestamps derived from
        acoustic boundary detection.

        This solves the "fast song lyrics have misaligned timestamps after text
        correction" problem: when ASR misses characters and the user adds them
        back, the old proportional fallback distributes chars evenly within each
        utterance, ignoring actual speech boundaries.

        Instead, we:
        1. Load the audio and detect all speech segments via librosa VAD.
        2. Count the total speech duration and per-segment durations.
        3. Assign edited Chinese characters to speech segments proportionally
           based on each segment's share of total speech duration.
        4. Within each segment, distribute chars evenly across the segment's
           time range (no intra-segment VAD available, but segment boundaries
           are correct so inter-char gaps line up with real pauses).

        Falls back to the original shared_chars / shared_utterances when audio
        cannot be loaded (conservative degradation).

        Args:
            edited_text: user-corrected text (Chinese characters extracted from it)
            audio_path: absolute path to the audio file, or None if audio_bytes is used
            audio_bytes: raw audio bytes, or None if audio_path is used

        Returns:
            List of char-level timestamp dicts: [{'char', 'start', 'end', 'conf':1.0}]
            Returns [] if everything fails (caller should handle empty list).
        """
        # 1. Extract Chinese chars from edited text
        edited_chars = [c for c in edited_text if _is_chinese_char(c)]
        if not edited_chars:
            return []

        # 2. Try to load audio
        if audio_path is None and audio_bytes is None:
            # No audio available: fall back to the original shared timestamps
            # via the proportional re-distribution in get_phonemes_from_edited_text
            return []

        try:
            import librosa
        except ImportError:
            return []

        try:
            if audio_path:
                audio, sr = librosa.load(audio_path, sr=16000, mono=True)
            else:
                import io as _io
                audio, sr = librosa.load(_io.BytesIO(audio_bytes), sr=16000, mono=True)
        except Exception:
            return []

        if len(audio) == 0:
            return []

        # 3. Detect speech segments (librosa adaptive VAD; kept in Python)
        speech_segments = LocalASR._detect_speech_segments(audio, sr)

        # 4-7. Proportional char assignment (largest-remainder), per-segment
        #      distribution and silence trimming run in the compiled C++
        #      engine (a2f_engine.redistribute_timestamps_core). It also
        #      handles the no-speech uniform fallback and the trailing
        #      leftover append.
        silence_regions = LocalASR._detect_silence_regions_static(audio, sr)
        total_duration = len(audio) / float(sr)
        try:
            import a2f_engine as _native
            assigned_chars = _native.redistribute_timestamps_core(
                edited_chars, speech_segments, silence_regions, total_duration,
            )
        except Exception as e:
            print(f"[Audio2Face ASR] C++ engine unavailable ({e}); no timestamps")
            return []
        return [
            {
                'char': r['char'],
                'start': r['start'],
                'end': r['end'],
                'conf': 1.0,
            }
            for r in assigned_chars
        ]

    @staticmethod
    def _trim_segment_to_speech_static(seg_start: float, seg_end: float,
                                       silence_regions: List[tuple]) -> tuple:
        """Static version of _trim_char_to_speech, but works on segment-level ranges.

        Trims segment start/end so they don't overlap large silence regions.
        Conservative: only trims when silence covers >30% of the segment boundary
        region, to avoid cutting off weak consonants.

        Runs in the compiled C++ engine (a2f_engine.trim_segment_to_speech_static).
        """
        if not silence_regions:
            return seg_start, seg_end
        try:
            import a2f_engine as _native
            return _native.trim_segment_to_speech_static(
                float(seg_start), float(seg_end),
                [[float(s), float(e)] for s, e in silence_regions],
            )
        except Exception as e:
            print(f"[Audio2Face ASR] C++ engine unavailable ({e}); skipping trim")
            return seg_start, seg_end

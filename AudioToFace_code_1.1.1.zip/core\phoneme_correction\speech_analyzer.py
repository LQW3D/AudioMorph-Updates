"""Chinese phoneme extraction

Based on ASR recognition results and the pypinyin library, converts Chinese text into phoneme sequences.
Each phoneme includes start and end times, used later for mapping to ARKit shape keys.
"""

from typing import List, Dict, Optional, Tuple

from .local_asr import LocalASR, ASRResult

try:
    from pypinyin import pinyin, Style
except ImportError:
    pinyin = None
    Style = None


class PhonemeSegment:
    """A phoneme segment (initial or final)"""
    def __init__(self, phoneme: str, phoneme_type: str, start: float, end: float):
        self.phoneme = phoneme          # Phoneme string, e.g. 'b', 'a', 'zh'
        self.phoneme_type = phoneme_type  # 'initial' or 'final'
        self.start = start              # Start time (seconds)
        self.end = end                  # End time (seconds)
        self.duration = end - start

    def __repr__(self):
        return f"PhonemeSegment({self.phoneme}, {self.phoneme_type}, {self.start:.3f}-{self.end:.3f})"


class SpeechAnalyzer:
    """Chinese phoneme analyzer"""

    def __init__(self):
        """Initialize with the local offline ASR backend (Sherpa-ONNX Paraformer)."""
        self.asr = LocalASR()

    def recognize(self, audio_path: str, callback=None) -> Tuple[List[ASRResult], Optional[Dict]]:
        """Run ASR recognition

        Returns:
            (utterances, task_resp)
            utterances: list of recognition results
            task_resp: raw task response (with char-level timestamps)
        """
        if pinyin is None:
            if callback:
                callback(0, "pypinyin not available")
            return [], None

        if callback:
            callback(5, "Loading audio...")

        utterances = self.asr.recognize(audio_path, callback=callback)
        task_resp = self.asr.get_last_task_resp()

        return utterances, task_resp

    def get_phonemes_from_chars(self, task_resp: Dict) -> List[PhonemeSegment]:
        """Extract phoneme sequence from ASR char-level timestamps

        The char-level timestamps of LocalASR are returned by get_chars_with_timestamps().
        """
        if task_resp is None:
            return []

        chars = self.asr.get_chars_with_timestamps(task_resp)
        if not chars:
            return []

        phonemes = []
        for char_info in chars:
            char = char_info['char']
            start = char_info['start']
            end = char_info['end']

            # Skip non-Chinese characters (punctuation, digits, spaces)
            if not self._is_chinese_char(char):
                continue

            char_phonemes = self._char_to_phonemes(char, start, end)
            phonemes.extend(char_phonemes)

        return phonemes

    def get_phonemes_from_text(self, text: str, utterances: List[ASRResult]) -> List[PhonemeSegment]:
        """Extract phoneme sequence from user text (or ASR text) + utterance timestamps

        When char-level timestamps are unavailable, distribute using utterance-level timestamps.
        """
        if not utterances:
            return []

        phonemes = []
        for u in utterances:
            u_text = u.text
            u_start = u.start_time
            u_end = u.end_time
            u_duration = u_end - u_start

            # Extract Chinese characters
            chinese_chars = [c for c in u_text if self._is_chinese_char(c)]
            if not chinese_chars:
                continue

            # Distribute time evenly by character count
            char_duration = u_duration / len(chinese_chars)
            for i, char in enumerate(chinese_chars):
                c_start = u_start + i * char_duration
                c_end = u_start + (i + 1) * char_duration
                char_phonemes = self._char_to_phonemes(char, c_start, c_end)
                phonemes.extend(char_phonemes)

        return phonemes

    def get_phonemes_from_edited_text(self, edited_text: str) -> List[PhonemeSegment]:
        """Generate phonemes from user-edited ASR text, reusing original timestamps.

        This is used when the user manually fixes ASR misrecognitions (e.g. song
        lyrics where "花" is misrecognized as "我"). Instead of re-running ASR,
        we reuse the original char-level timestamps and only replace the characters.

        Strategy:
        - If edited text's Chinese char count == original char count:
          1:1 replacement, preserve exact timestamps (best accuracy).
        - If char count differs:
          Distribute edited text across original utterance time ranges
          proportionally (fallback, less accurate but robust).
        """
        original_chars = LocalASR._shared_chars
        original_utterances = LocalASR._shared_utterances

        if not original_chars and not original_utterances:
            return []

        edited_chars = [c for c in edited_text if self._is_chinese_char(c)]
        if not edited_chars:
            return []

        if original_chars and len(edited_chars) == len(original_chars):
            # Char count matches: 1:1 replace, preserve exact timestamps.
            # This is the ideal path — the user fixed individual misrecognized
            # characters without changing the total count.
            phonemes = []
            for orig, new_char in zip(original_chars, edited_chars):
                char_phonemes = self._char_to_phonemes(
                    new_char, orig['start'], orig['end']
                )
                phonemes.extend(char_phonemes)
            return phonemes

        # Char count mismatch (user added/removed characters):
        # Fall back to utterance-level proportional distribution.
        if not original_utterances:
            return []

        total_orig = sum(
            1 for u in original_utterances
            for c in u.text if self._is_chinese_char(c)
        )
        if total_orig == 0:
            return []

        char_idx = 0
        modified_utterances = []
        for u in original_utterances:
            orig_count = sum(
                1 for c in u.text if self._is_chinese_char(c)
            )
            if orig_count == 0:
                modified_utterances.append(ASRResult(
                    text=u.text, start_time=u.start_time, end_time=u.end_time
                ))
                continue
            # Proportional allocation: this utterance gets a share of edited
            # chars proportional to its original char count.
            new_count = max(1, round(orig_count * len(edited_chars) / total_orig))
            new_text = ''.join(edited_chars[char_idx:char_idx + new_count])
            char_idx += new_count
            modified_utterances.append(ASRResult(
                text=new_text, start_time=u.start_time, end_time=u.end_time
            ))

        return self.get_phonemes_from_text('', modified_utterances)

    def _char_to_phonemes(self, char: str, start: float, end: float) -> List[PhonemeSegment]:
        """Convert a single Chinese character to phoneme sequence.

        Returns [initial segment, final segment] or [final segment].
        Pinyin decomposition is delegated to the native C++ engine, which
        owns all the spelling tables (initial duration factors, compound-final
        splits, nasal-coda caps, JQX umlaut correction), so Python keeps no
        plaintext tables.
        """
        if pinyin is None:
            return []

        try:
            # Get pinyin without tones
            pinyin_list = pinyin(char, style=Style.NORMAL, heteronym=False)
            if not pinyin_list or not pinyin_list[0]:
                return []

            py = pinyin_list[0][0].lower()
            if not py:
                return []

            # Decompose via the native engine.
            import a2f_engine as _native
            cpp_segments = _native.split_pinyin(py, start, end)
            return [
                PhonemeSegment(
                    seg['phoneme'],
                    seg['phoneme_type'],
                    seg['start'],
                    seg['end'],
                )
                for seg in cpp_segments
            ]

        except Exception:
            return []

    def _is_chinese_char(self, char: str) -> bool:
        """Check if a character is Chinese"""
        if not char:
            return False
        code = ord(char)
        # CJK Unified Ideographs range
        return 0x4E00 <= code <= 0x9FFF

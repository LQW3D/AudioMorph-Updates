"""Automatic update operators for AudioToFace.

Handles the three independent update parts (code / model / deps):
  - code/deps : download -> verify -> stage -> detach-and-relay -> restart Blender
  - model     : download -> verify -> replace in place (no restart)

Network work runs on a background thread; a Blender timer polls the shared
state so the UI progress bar updates without ever blocking the main thread.
"""

import threading
import time

import bpy
from bpy.props import FloatProperty, StringProperty

from ..core import updater
from ..utils.i18n import t, tr


# Module name used as the addon key in bpy.context.preferences.addons.
_ADDON_KEY = "AudioToFace"


# Shared update state. Written by the worker thread, read by the UI timer.
_UPDATE_STATE = {
    "phase": "idle",   # idle|downloading|restart_pending|restarting|done|error
    "part": "",        # code|model|deps
    "progress": 0.0,   # 0..100
    "message": "",     # status key (English, translated for display)
}

# Manifest cache. The network fetch runs on a background thread so the UI
# thread never blocks. draw() reads this dict synchronously (pure in-memory,
# no I/O). A stale or empty cache triggers a background refresh that is picked
# up on later draws.
_manifest_cache = {"time": 0.0, "data": None, "fetching": False}

# Minimum interval between background manifest refreshes (seconds).
_MANIFEST_TTL = 300


def _fetch_manifest_bg():
    """Background task: fetch the manifest and store it in the cache."""
    _manifest_cache["fetching"] = True
    try:
        _manifest_cache["data"] = updater.get_manifest()
        _manifest_cache["time"] = time.time()
    except Exception:
        pass
    finally:
        _manifest_cache["fetching"] = False


def _ensure_manifest_async():
    """Start a background fetch if the cache is empty or stale. Never blocks."""
    now = time.time()
    if _manifest_cache["fetching"]:
        return
    if (_manifest_cache["data"] is None
            or now - _manifest_cache["time"] > _MANIFEST_TTL):
        threading.Thread(target=_fetch_manifest_bg, daemon=True).start()


def get_update_parts():
    """Return parts with a newer version, read from the cached manifest.

    Never performs network I/O on the calling (UI) thread. Kicks off an
    async refresh if needed; the result appears on subsequent draws.
    """
    _ensure_manifest_async()
    manifest = _manifest_cache["data"]
    if not manifest:
        return []
    return updater.check_updates(manifest)


def _prefs():
    try:
        return bpy.context.preferences.addons.get(_ADDON_KEY).preferences
    except Exception:
        return None


def _progress_cb(downloaded, total):
    if total:
        _UPDATE_STATE["progress"] = min(95.0, downloaded * 100.0 / total)
    else:
        _UPDATE_STATE["progress"] = min(95.0, _UPDATE_STATE["progress"] + 0.5)


def _worker(part, entry):
    try:
        _UPDATE_STATE.update(
            phase="downloading", part=part, progress=0.0, message="")
        zip_path = updater.download_part(part, entry, progress_cb=_progress_cb)
        if not zip_path:
            _UPDATE_STATE.update(phase="error", message="download_failed")
            return
        _UPDATE_STATE["progress"] = 100.0
        if part == "model":
            ok, msg = updater.apply_model_update(zip_path)
            if ok:
                _UPDATE_STATE.update(phase="done", message="update_success")
            else:
                _UPDATE_STATE.update(phase="error", message=msg or "apply_failed")
        else:
            # code/deps: stage + detach-and-relay already launched inside.
            ok, msg = updater.apply_code_or_deps_update(zip_path, part)
            if ok:
                _UPDATE_STATE.update(phase="restart_pending", message="restart_pending")
            else:
                _UPDATE_STATE.update(phase="error", message=msg or "apply_failed")
    except Exception as e:
        _UPDATE_STATE.update(phase="error", message=str(e))


def _finish_restart():
    """Relay is already waiting on our pid; ask Blender to quit now."""
    _UPDATE_STATE["phase"] = "restarting"
    try:
        bpy.ops.wm.wm_quit_blender()
    except Exception:
        pass


def _reset_state():
    _UPDATE_STATE.update(phase="idle", part="", progress=0.0, message="")


def _update_timer():
    prefs = _prefs()
    if prefs is None:
        return None
    state = _UPDATE_STATE
    phase = state["phase"]

    if phase == "idle":
        return None  # stop polling

    if phase == "downloading":
        prefs.download_progress = state["progress"]
        prefs.update_status = t("Downloading update...")
        return 0.1

    if phase == "restart_pending":
        prefs.update_status = t("Update ready, restarting Blender...")
        _finish_restart()
        return 0.1

    if phase == "restarting":
        # Blender is about to quit; keep the timer alive until exit.
        return 0.1

    if phase == "done":
        prefs.download_progress = 100.0
        prefs.update_status = t("Update complete.")
        _reset_state()
        return None

    if phase == "error":
        prefs.download_progress = 0.0
        prefs.update_status = t("Update failed. See console for details.")
        _reset_state()
        return None

    return None


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class AUDIO2FACE_OT_update_part(bpy.types.Operator):
    """Download and install the update for one part"""
    bl_idname = "audio2face.update_part"
    bl_label = t("Update")
    bl_description = t("Download and install the update for this component")

    part: StringProperty(default="code")

    def execute(self, context):
        part = self.part
        # Use the cached manifest so this never blocks the UI thread.
        _ensure_manifest_async()
        manifest = _manifest_cache["data"]
        entry = (manifest or {}).get(part) if manifest else None
        if not entry:
            self.report({'WARNING'},
                        tr("No update available for this part."))
            return {'CANCELLED'}
        if _UPDATE_STATE["phase"] in (
                "downloading", "restart_pending", "restarting"):
            self.report({'WARNING'},
                        tr("An update is already in progress."))
            return {'CANCELLED'}

        _UPDATE_STATE.update(phase="downloading", part=part,
                             progress=0.0, message="")
        thread = threading.Thread(
            target=_worker, args=(part, entry), daemon=True)
        thread.start()
        if not bpy.app.timers.is_registered(_update_timer):
            bpy.app.timers.register(_update_timer, first_interval=0.1)
        return {'FINISHED'}


class AUDIO2FACE_OT_open_preferences(bpy.types.Operator):
    """Open Blender preferences and show the AudioToFace addon"""
    bl_idname = "audio2face.open_preferences"
    bl_label = t("Open Preferences")
    bl_description = t("Open Blender preferences and show the AudioToFace addon")

    def execute(self, context):
        try:
            context.window_manager.preferences_type = 'ADDONS'
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
            context.preferences.active_section = 'ADDONS'
        except Exception:
            pass
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Addon preferences panel (three update buttons + descriptions + progress)
# ---------------------------------------------------------------------------

# (part, name_key, desc_key, icon)
_PART_SPECS = (
    ("code", "Functional Code", "Core plugin logic and engine", 'FILE_SCRIPT'),
    ("model", "AI Model", "The animation model files", 'SHAPEKEY_DATA'),
    ("deps", "Dependencies", "Bundled runtime libraries", 'PACKAGE'),
)


class AudioToFacePreferences(bpy.types.AddonPreferences):
    bl_idname = "AudioToFace"

    download_progress: FloatProperty(
        name="Download Progress", default=0.0, min=0.0, max=100.0,
        subtype='PERCENTAGE')
    update_status: StringProperty(default="")

    def draw(self, context):
        layout = self.layout
        state = _UPDATE_STATE
        updates = get_update_parts()

        box = layout.box()
        box.label(text=t("Updates"), icon='FILE_REFRESH')

        for part, name_key, desc_key, icon in _PART_SPECS:
            has = part in updates
            sub = box.box()

            # Header row: name + availability badge.
            head = sub.row()
            head.label(text=t(name_key), icon=icon)
            if has:
                head.alert = True
                head.label(text=t("Update Available"), icon='INFO')

            # Update button (red/clickable when available, grey otherwise).
            row = sub.row()
            op = row.operator(
                "audio2face.update_part",
                text=t("Update") if has else t("Up to date"))
            op.part = part
            if not has:
                row.enabled = False

            # Function intro text.
            sub.label(text=t(desc_key), icon='NONE')

            # Live progress for the part currently being downloaded.
            if state["phase"] == "downloading" and state["part"] == part:
                sub.prop(self, "download_progress",
                         text=t("Progress"), slider=True)
            elif state["phase"] == "done" and state["part"] == part:
                sub.label(text=t("Update complete."), icon='CHECKMARK')
            elif state["phase"] == "error" and state["part"] == part:
                sub.label(text=t("Update failed. See console for details."),
                          icon='ERROR')

        if self.update_status:
            st = layout.row()
            st.alert = True
            st.label(text=self.update_status, icon='INFO')


classes = (
    AUDIO2FACE_OT_update_part,
    AUDIO2FACE_OT_open_preferences,
    AudioToFacePreferences,
)
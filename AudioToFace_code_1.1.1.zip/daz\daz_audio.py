"""DAZ mode audio import operator.

Mirrors operators/import_audio.py but reads the audio file path from the
DAZ-specific property (scene.audio2face_daz_props.audio_file) so the DAZ
page maintains its own state independent of the Animation page.
"""

import bpy
import os

from ..utils.i18n import t, tr


class AUDIO2FACE_OT_daz_import_audio(bpy.types.Operator):
    bl_idname = "audio2face.daz_import_audio"
    bl_label = t("Import Audio")
    bl_description = t("Import selected audio file to VSE timeline at the current playhead position")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.audio2face_daz_props
        audio_file = props.audio_file

        if not audio_file:
            self.report({'ERROR'}, tr("Please select an audio file first"))
            return {'CANCELLED'}

        if not os.path.exists(audio_file):
            self.report({'ERROR'}, tr("Audio file does not exist") + f": {audio_file}")
            return {'CANCELLED'}

        # Ensure the scene has a sequence_editor data block (created on demand,
        # no need for an open Video Sequence Editor window).
        if not context.scene.sequence_editor:
            context.scene.sequence_editor_create()

        frame_start = int(context.scene.frame_current)
        seq_editor = context.scene.sequence_editor
        sound_strip = None

        try:
            # Low-level API: create the sound strip directly (no file browser
            # dialog). Blender 5.0+ uses 'strips'; older versions use 'sequences'.
            strips_collection = getattr(seq_editor, 'strips', None)
            if strips_collection is None:
                strips_collection = getattr(seq_editor, 'sequences', None)

            if strips_collection is not None and hasattr(strips_collection, 'new_sound'):
                sound_strip = strips_collection.new_sound(
                    name=os.path.basename(audio_file),
                    filepath=audio_file,
                    channel=1,
                    frame_start=frame_start
                )
                print("[Audio2Face DAZ] Created sound strip via low-level API")
            else:
                self.report({'ERROR'}, tr("Audio import failed") + ": " + tr("Sequence editor API not available"))
                return {'CANCELLED'}

            # Guard defensively: if new_sound() returned None, treat as failure.
            if not sound_strip:
                self.report({'ERROR'}, tr("Audio import failed") + ": " + tr("Sequence editor returned empty strip"))
                return {'CANCELLED'}

            # Set the scene's frame range to match the audio range so the
            # timeline automatically focuses on the imported audio.
            audio_start = int(sound_strip.frame_final_start)
            audio_end = int(sound_strip.frame_final_end)
            context.scene.frame_start = audio_start
            context.scene.frame_end = audio_end
            print(f"[Audio2Face DAZ] Audio range: {audio_start}-{audio_end}, "
                  f"scene set to {context.scene.frame_start}-{context.scene.frame_end}")

            props.status_message = f"{t('Imported audio to VSE at frame')} {frame_start}"
            self.report({'INFO'}, tr('Imported audio to VSE at frame') + f" {frame_start}")

        except Exception as e:
            self.report({'ERROR'}, tr("Audio import failed") + f": {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


classes = [AUDIO2FACE_OT_daz_import_audio]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

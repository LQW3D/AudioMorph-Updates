"""Audio2Face SDK interface (ONNX-based, cross-platform).

This module provides the A2FContext class that the rest of the plugin
calls to generate blendshape animation from audio.

Previously this module spawned a2f_worker.exe (Windows-only TensorRT).
It now delegates to core.a2f_onnx.A2FOnnxContext which runs the same
NVIDIA model via ONNX Runtime, working on CPU / CUDA / DirectML / CoreML.

The public interface (A2FContext) is unchanged so callers (operators/generate.py)
need no modification.

Blender 5.0 workaround:
    Blender 5.0 ships with onnxruntime 1.19.2, which conflicts with our
    onnxruntime 1.26. For Blender 5.0, SDK runs in a subprocess to avoid
    the DLL conflict.
"""

import os
import sys
import json
import tempfile
import subprocess

try:
    import bpy
    BLENDER_VERSION = bpy.app.version
except ImportError:
    BLENDER_VERSION = (0, 0, 0)

_USE_SUBPROCESS = BLENDER_VERSION[0] == 5 and BLENDER_VERSION[1] == 0

if not _USE_SUBPROCESS:
    from .a2f_onnx import A2FOnnxContext


class A2FError(Exception):
    pass


def _resolve_model_dir(model_json_path: str) -> str:
    """Given the path to model.json, return the model directory.

    Also verifies that network.onnx exists; if not, raises A2FError with
    a helpful message.
    """
    if not os.path.isfile(model_json_path):
        raise A2FError(f"model.json not found: {model_json_path}")

    model_dir = os.path.dirname(model_json_path)

    # Prefer ONNX; fall back to TRT (old worker) only if ONNX is missing.
    onnx_path = os.path.join(model_dir, "network.onnx")
    if not os.path.isfile(onnx_path):
        raise A2FError(
            f"ONNX model not found: {onnx_path}\n"
            "The cross-platform ONNX model file is required. "
            "Please ensure network.onnx is in the model directory."
        )

    return model_dir


class A2FContext:
    """Audio2Face inference context (ONNX-based).

    Drop-in replacement for the old worker-based A2FContext.
    All strength/smoothing kwargs are accepted for API compatibility
    but are handled internally by the ONNX model + BlendshapeSolver.
    """

    def __init__(self, model_json_path: str):
        self._model_dir = _resolve_model_dir(model_json_path)
        
        if _USE_SUBPROCESS:
            self._ctx = None
            self._worker_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'a2f_worker.py'
            )
            self._python_exe = os.path.join(sys.prefix, 'bin', 'python.exe')
            if not os.path.exists(self._python_exe):
                self._python_exe = sys.executable
        else:
            self._ctx = A2FOnnxContext(self._model_dir)

    @property
    def weight_count(self) -> int:
        if _USE_SUBPROCESS:
            return 68
        return self._ctx.weight_count

    @property
    def frame_count(self) -> int:
        if _USE_SUBPROCESS:
            return self._last_frame_count if hasattr(self, '_last_frame_count') else 0
        return self._ctx.frame_count

    @property
    def providers(self):
        if _USE_SUBPROCESS:
            return self._last_providers if hasattr(self, '_last_providers') else ["CPUExecutionProvider"]
        return self._ctx.providers

    def process_audio(self, samples, emotion_vectors=None, **kwargs):
        if _USE_SUBPROCESS:
            return self._process_audio_via_subprocess(samples, emotion_vectors=emotion_vectors)
        return self._ctx.process_audio(samples, emotion_vectors=emotion_vectors, **kwargs)

    def _process_audio_via_subprocess(self, samples, emotion_vectors=None):
        import numpy as np

        # Use binary .npy format for large arrays instead of JSON text.
        # For 96s audio (1.5M floats): .npy = 6MB vs JSON = 23MB,
        # and numpy save/load is ~10x faster than json dump/load.
        fd, samples_path = tempfile.mkstemp(suffix='.npy')
        os.close(fd)
        fd, emotion_path = tempfile.mkstemp(suffix='.npy')
        os.close(fd)
        fd, output_path = tempfile.mkstemp(suffix='.npy')
        os.close(fd)
        fd, meta_path = tempfile.mkstemp(suffix='.json')
        os.close(fd)
        fd, log_path = tempfile.mkstemp(suffix='.log')
        os.close(fd)

        # Key performance optimization: redirect stderr to file instead of
        # using a pipe. The previous Popen + read-thread approach consumed
        # main-process CPU and reduced subprocess parallelism. With file
        # redirection, the main process blocks fully on wait() while the
        # subprocess gets exclusive CPU. After completion, the log file is
        # read for display; on timeout, the last progress can still be read
        # from the file.
        print(f"[Audio2Face SDK] Starting subprocess worker (log: {log_path})...", flush=True)

        try:
            np.save(samples_path, np.asarray(samples, dtype=np.float32))

            if emotion_vectors is not None:
                np.save(emotion_path, np.asarray(emotion_vectors, dtype=np.float32))
            else:
                np.save(emotion_path, np.array([], dtype=np.float32))

            cmd = [
                self._python_exe,
                self._worker_path,
                '--model_dir', self._model_dir,
                '--samples', samples_path,
                '--emotion', emotion_path,
                '--output', output_path,
                '--meta', meta_path,
            ]

            # Redirect stderr to file, and stdout to the same file.
            # The main process does not read from the pipe, so the subprocess
            # gets exclusive CPU.
            with open(log_path, 'w', encoding='utf-8') as log_file:
                # Pass the resolved device-config path to the worker so it
                # reads the same config the main process uses (per-user dir).
                _worker_env = dict(os.environ)
                try:
                    from .device_detector import _get_config_path as _a2f_cfg_path
                    _worker_env["A2F_DEVICE_CONFIG"] = _a2f_cfg_path()
                except Exception:
                    pass
                process = subprocess.Popen(
                    cmd,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,  # stderr merged into stdout
                    text=True,
                    encoding='utf-8',
                    env=_worker_env,
                )

                try:
                    process.wait(timeout=1800)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                    # Read the last progress from the log file
                    last_lines = ""
                    try:
                        with open(log_path, 'r', encoding='utf-8') as f:
                            lines = f.readlines()
                            last_lines = ''.join(lines[-20:])
                    except Exception:
                        pass
                    raise RuntimeError(
                        f"A2F worker timed out after 1800s.\n"
                        f"Last log lines:\n{last_lines}"
                    )

            # After processing completes, read the log and display it
            try:
                with open(log_path, 'r', encoding='utf-8') as f:
                    log_content = f.read()
                if log_content.strip():
                    print(log_content, flush=True)
            except Exception:
                pass

            if process.returncode != 0:
                # Read the log for the error message
                log_content = ""
                try:
                    with open(log_path, 'r', encoding='utf-8') as f:
                        log_content = f.read()
                except Exception:
                    pass
                raise RuntimeError(
                    f"A2F worker failed (code={process.returncode}):\n{log_content}"
                )

            with open(meta_path, 'r', encoding='utf-8') as f:
                meta = json.load(f)

            if not meta.get('success'):
                raise RuntimeError(f"A2F failed: {meta.get('error', 'unknown')}")

            self._last_frame_count = meta.get('frame_count', 0)
            self._last_providers = meta.get('providers', ["CPUExecutionProvider"])

            # Directly return the numpy array converted to list (keep interface compatible)
            return np.load(output_path).tolist()

        finally:
            for p in [samples_path, emotion_path, output_path, meta_path, log_path]:
                if p and os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass

    def reset(self):
        if not _USE_SUBPROCESS and self._ctx is not None:
            self._ctx.reset()

    def close(self):
        if not _USE_SUBPROCESS and self._ctx is not None:
            self._ctx.close()
            self._ctx = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

import bpy
import os
import wave
from typing import Dict, List, Any
from ..utils.i18n import t, tr
from ..core.phoneme_correction import PhonemeCorrector
from ..core.phoneme_correction.speech_analyzer import SpeechAnalyzer

_SDK_MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                "models", "james_v3.0", "model.json")

# Worker output is 68 channels: the first 52 are the ARKit blendshape order used by
# the expression preset, followed by 16 tongue-solver poses from bs_tongue.npz.
# The 68-channel naming table and the multiplier mapping live in the compiled
# C++ engine (a2f_engine.map_sdk_output) to protect the mapping recipe.


# ---------------------------------------------------------------------------
# Silence suppression: dampen lip-sync noise during audio pauses.
# ---------------------------------------------------------------------------

# Channels suppressed to near-zero during silence. These are the lip-sync
# channels that the NVIDIA model may drive with small non-zero noise during
# pauses, causing the mouth to twitch. Eye/brow channels are preserved so
# natural blinks and eye darts continue during pauses.
# The channel set and the suppression algorithm live in the compiled C++
# engine (a2f_engine.apply_silence_suppression).


def _apply_silence_suppression(frames, audio_path: str, fps: float,
                                frame_offset: int = 0) -> None:
    """Suppress lip-sync noise during silent segments of the audio.

    Computes a per-frame amplitude envelope from the source audio, detects
    silence frames (amplitude below 5% of peak), and scales down the
    lip-sync channels on those frames in-place. Eye/brow channels are
    preserved so blinks and eye darts continue naturally during pauses.

    The function is a no-op if the audio file cannot be loaded or if every
    frame is above the silence threshold.

    Args:
        frames: list of BlendshapeFrame (modified in-place).
        audio_path: source audio file for amplitude analysis.
        fps: scene frame rate.
        frame_offset: frame number offset (segment start, unused here
            because the frames list is already segment-local).
    """
    if not frames or not audio_path or not os.path.isfile(audio_path):
        print(f"[Audio2Face] Silence suppression skipped: frames={len(frames) if frames else 0}, "
              f"audio={'missing' if not audio_path or not os.path.isfile(audio_path) else audio_path}")
        return

    try:
        import librosa
    except ImportError:
        print("[Audio2Face] Silence suppression skipped: librosa not available")
        return

    try:
        y, sr = librosa.load(audio_path, sr=None, mono=True)
    except Exception as e:
        print(f"[Audio2Face] Silence suppression skipped: audio load failed: {e}")
        return

    if len(y) == 0:
        print("[Audio2Face] Silence suppression skipped: empty audio")
        return

    # Compute RMS energy per ~30ms hop (matching human perception window).
    hop = 512
    rms = librosa.feature.rms(y=y, hop_length=hop, frame_length=hop * 2)[0]
    if len(rms) == 0:
        print("[Audio2Face] Silence suppression skipped: RMS empty")
        return

    # Silence detection (5% peak threshold), the suppressed channel set and
    # the smoothstep relaxation recipe run in the compiled C++ engine.
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_silence_suppression(
            frames_dicts, [float(v) for v in rms], float(sr), hop, float(fps)
        )
    except Exception as e:
        print(f"[Audio2Face] Silence suppression skipped: C++ engine unavailable ({e})")
        return

    for fd, rd in zip(frames, result):
        fd.weights = dict(rd["weights"])
    print(f"[Audio2Face] Silence suppression: applied to {len(frames)} frames "
          f"(threshold=5% of peak)")


def _load_audio_wav(wav_path: str) -> list[float]:
    """Read a 16kHz mono WAV and return float samples."""
    with wave.open(wav_path, 'rb') as wf:
        if wf.getnchannels() != 1:
            raise ValueError(f"Expected mono audio, got {wf.getnchannels()} channels")
        if wf.getframerate() != 16000:
            raise ValueError(f"Expected 16000 Hz sample rate, got {wf.getframerate()} Hz")
        n = wf.getnframes()
        raw = wf.readframes(n)
    import struct
    fmt = f"<{n}h"
    samples_i16 = struct.unpack(fmt, raw)
    return [s / 32768.0 for s in samples_i16]


def _build_weight_multipliers(props) -> dict[str, float]:
    """Build per-blendshape weight multipliers from UI properties.

    The channel grouping and the damping/base recipe (0.7 / 0.8 / 0.15 / 0.4)
    live in the compiled C++ engine (a2f_engine.build_weight_multipliers) to
    protect the IP. This wrapper reads the UI props and delegates.
    """
    params = {
        "jaw_open_multiplier": float(getattr(props, "jaw_open_multiplier", 1.0)),
        "mouth_close_multiplier": float(getattr(props, "mouth_close_multiplier", 1.0)),
        "jaw_left_right_multiplier": float(getattr(props, "jaw_left_right_multiplier", 1.0)),
        "mouth_roll_lower_multiplier": float(getattr(props, "mouth_roll_lower_multiplier", 1.0)),
        "mouth_shrug_lower_multiplier": float(getattr(props, "mouth_shrug_lower_multiplier", 1.0)),
        "mouth_lower_down_multiplier": float(getattr(props, "mouth_lower_down_multiplier", 1.0)),
        "mouth_roll_upper_multiplier": float(getattr(props, "mouth_roll_upper_multiplier", 1.0)),
        "mouth_shrug_upper_multiplier": float(getattr(props, "mouth_shrug_upper_multiplier", 1.0)),
        "mouth_upper_up_multiplier": float(getattr(props, "mouth_upper_up_multiplier", 1.0)),
    }
    try:
        import a2f_engine as _native
        return _native.build_weight_multipliers(params)
    except Exception as e:
        print(f"[Audio2Face] C++ engine unavailable ({e}); using identity multipliers")
        return {}


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _copy_frame(frame, weights: Dict[str, float] | None = None, time: float | None = None):
    from ..core.blendshape import BlendshapeFrame
    return BlendshapeFrame(
        time=frame.time if time is None else time,
        weights=dict(frame.weights if weights is None else weights),
        emotions=getattr(frame, "emotions", None),
    )


def _lerp_weights(a: Dict[str, float], b: Dict[str, float], factor: float) -> Dict[str, float]:
    names = set(a.keys()) | set(b.keys())
    return {
        name: a.get(name, 0.0) * (1.0 - factor) + b.get(name, 0.0) * factor
        for name in names
    }


def _sample_frame_weights(frames: List[Any], source_time: float) -> Dict[str, float]:
    if not frames:
        return {}
    if source_time <= frames[0].time:
        return dict(frames[0].weights)
    if source_time >= frames[-1].time:
        return dict(frames[-1].weights)

    # Frames are uniformly generated, so a short linear scan is enough for the
    # clip sizes this operator handles and avoids assumptions after resampling.
    for i in range(1, len(frames)):
        prev_frame = frames[i - 1]
        next_frame = frames[i]
        if source_time <= next_frame.time:
            span = max(1e-6, next_frame.time - prev_frame.time)
            factor = (source_time - prev_frame.time) / span
            return _lerp_weights(prev_frame.weights, next_frame.weights, factor)
    return dict(frames[-1].weights)


def _apply_prediction_delay(frames: List[Any], delay_seconds: float) -> List[Any]:
    """Shift mouth-shape channels by a prediction delay.

    The mouth-shape channel set, lerp sampling and per-channel override run
    in the compiled C++ engine (a2f_engine.apply_prediction_delay). Emotions
    are preserved.
    """
    if not frames or abs(delay_seconds) < 1e-4:
        return frames
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_prediction_delay(frames_dicts, float(delay_seconds))
        return [
            _copy_frame(fr, weights=rd["weights"])
            for fr, rd in zip(frames, result)
        ]
    except Exception as e:
        print(f"[Audio2Face] Prediction delay skipped: C++ engine unavailable ({e})")
        return frames


def _apply_eye_controls(frames: List[Any], props, utterances=None) -> List[Any]:
    if not frames:
        return frames

    params = {
        "eyeballs_strength": float(getattr(props, "eyeballs_strength", 1.0)),
        "saccade_strength": float(getattr(props, "saccade_strength", 0.0)),
        "blink_interval": float(getattr(props, "blink_interval", 0.0)),
        "blink_strength": float(getattr(props, "blink_strength", 1.0)),
    }

    boundary_times: List[float] = []
    if utterances:
        try:
            for u in utterances:
                start_t = getattr(u, "start_time", None)
                if start_t is not None:
                    boundary_times.append(float(start_t))
        except Exception:
            boundary_times = []

    # The eye-channel sets, saccade generator (fixed-seed MT19937), drift
    # model and blink recipe run in the compiled C++ engine.
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_eye_controls(frames_dicts, params, boundary_times)
        return [
            _copy_frame(fr, weights=rd["weights"])
            for fr, rd in zip(frames, result)
        ]
    except Exception as e:
        print(f"[Audio2Face] Eye controls skipped: C++ engine unavailable ({e})")
        return frames




def _apply_advanced_controls(frames: List[Any], props, utterances=None) -> List[Any]:
    frames = _apply_prediction_delay(frames, getattr(props, "prediction_delay", 0.0))
    frames = _apply_eye_controls(frames, props, utterances=utterances)
    # Emotion vectors are disabled (NVIDIA emotion inference produces poor
    # results). emotion_vectors is always None in _process_with_sdk.
    return frames


class AUDIO2FACE_OT_generate(bpy.types.Operator):
    bl_idname = "audio2face.generate"
    bl_label = t("Generate Animation")
    bl_description = t("Generate facial animation from audio")
    bl_options = {'REGISTER', 'UNDO'}

    def _run_asr(self, props, audio_path):
        """Run ASR recognition (shared by emotion recognition and phoneme correction)

        Returns:
            (utterances, task_resp)
            Returns (None, None) if ASR fails
        """
        try:
            print("[Audio2Face] ASR: starting recognition...")
            import time as _time
            _t_init = _time.time()
            analyzer = SpeechAnalyzer()
            print(f"[Audio2Face] ⏱ ASR SpeechAnalyzer init: {_time.time() - _t_init:.2f}s")

            def _asr_callback(progress, message):
                print(f"[Audio2Face] ASR {progress}%: {message}")

            _t_recog = _time.time()
            utterances, task_resp = analyzer.recognize(audio_path, callback=_asr_callback)
            print(f"[Audio2Face] ⏱ ASR recognize: {_time.time() - _t_recog:.2f}s")

            if not utterances:
                print("[Audio2Face] ASR returned no results")
                self.report({'WARNING'}, tr("ASR returned no results"))
                return None, None

            text_preview = analyzer.asr.get_text(utterances)[:50]
            print(f"[Audio2Face] ASR done: {len(utterances)} utterances, text='{text_preview}'")
            return utterances, task_resp

        except Exception as e:
            import traceback
            print(f"[Audio2Face] ASR failed: {e}")
            traceback.print_exc()
            self.report({'WARNING'}, tr("ASR failed") + f": {e}")
            return None, None

    def _apply_phoneme_correction(self, frames, props, audio_path, utterances=None, task_resp=None, fps=None):
        """Perform phoneme correction

        Flow:
        1. ASR recognition -> character-level timestamps (reuse precomputed results or re-recognize)
        2. Text -> pinyin -> phoneme sequence
        3. Model inference results + phonemes -> fusion correction

        Returns:
            (corrected_frames, phoneme_data)
            Returns (original frames, None) if ASR fails
        """
        try:
            # 1. ASR recognition (reuse precomputed results)
            if utterances is not None and task_resp is not None:
                print("[Audio2Face] Phoneme correction: reusing ASR results")
                analyzer = SpeechAnalyzer()
            else:
                print("[Audio2Face] Phoneme correction: starting ASR recognition...")
                analyzer = SpeechAnalyzer()

                def _asr_callback(progress, message):
                    print(f"[Audio2Face] ASR {progress}%: {message}")

                utterances, task_resp = analyzer.recognize(audio_path, callback=_asr_callback)

                if utterances:
                    text_preview = analyzer.asr.get_text(utterances)[:50]
                    print(f"[Audio2Face] ASR done: {len(utterances)} utterances, text='{text_preview}'")

            if not utterances:
                print("[Audio2Face] Phoneme correction skipped: ASR returned no results")
                self.report({'WARNING'}, tr("Phoneme correction skipped: ASR failed"))
                return frames, None

            # 3. Extract phoneme sequence
            import time as _time
            _t_ph_start = _time.time()
            phonemes = analyzer.get_phonemes_from_chars(task_resp)
            if not phonemes:
                # Character-level timestamps unavailable, use utterance-level
                phonemes = analyzer.get_phonemes_from_text('', utterances)
            print(f"[Audio2Face] ⏱ Phoneme extraction: {_time.time() - _t_ph_start:.2f}s ({len(phonemes) if phonemes else 0} segments)")

            if not phonemes:
                print("[Audio2Face] Phoneme correction skipped: no phonemes extracted")
                return frames, None

            print(f"[Audio2Face] Phonemes extracted: {len(phonemes)} segments")

            # 4. Fusion correction
            _t_correct_start = _time.time()
            corrector = PhonemeCorrector()
            frames_list = [
                {'time': f.time, 'weights': f.weights}
                for f in frames
            ]

            corrected = corrector.correct_frames(
                model_frames=frames_list,
                fps=fps if fps is not None else 30,
                phonemes=phonemes,
                correction_strength=props.phoneme_correction_strength,
                frame_offset=0,  # Phoneme times are based on audio 0s, consistent with frames' time
            )
            print(f"[Audio2Face] ⏱ Corrector.correct_frames: {_time.time() - _t_correct_start:.2f}s")

            # Convert back to BlendshapeFrame
            _t_convert_start = _time.time()
            from ..core.blendshape import BlendshapeFrame
            result = [
                BlendshapeFrame(time=f['time'], weights=f['weights'])
                for f in corrected
            ]
            print(f"[Audio2Face] ⏱ Convert to BlendshapeFrame: {_time.time() - _t_convert_start:.2f}s")

            print(f"[Audio2Face] Phoneme correction applied: strength={props.phoneme_correction_strength:.2f}")
            self.report({'INFO'}, tr("Phoneme correction applied"))
            return result, phonemes

        except Exception as e:
            import traceback
            print(f"[Audio2Face] Phoneme correction failed: {e}")
            traceback.print_exc()
            self.report({'WARNING'}, tr("Phoneme correction failed") + f": {e}")
            return frames, None

    def _process_with_sdk(self, props, utterances=None, fps=None):
        from ..core.a2f_sdk import A2FContext
        from ..core.blendshape import BlendshapeFrame
        import tempfile

        if not os.path.isfile(_SDK_MODEL_PATH):
            raise FileNotFoundError(
                f"Model file not found: {_SDK_MODEL_PATH}\n"
                "Please make sure the model files are properly installed."
            )

        print(f"[Audio2Face SDK] Using local SDK inference...")

        import time as _time
        _t_load_start = _time.time()
        audio_path = props.audio_file
        tmp_wav = None
        if not (audio_path.lower().endswith('.wav')):
            import librosa
            import soundfile as sf
            audio, _ = librosa.load(audio_path, sr=16000, mono=True)
            _fd, tmp_wav = tempfile.mkstemp(suffix='.wav')
            os.close(_fd)
            sf.write(tmp_wav, audio, 16000, subtype='PCM_16')
            audio_path = tmp_wav

        try:
            samples = _load_audio_wav(audio_path)
        finally:
            if tmp_wav and os.path.exists(tmp_wav):
                os.remove(tmp_wav)
        print(f"[Audio2Face] ⏱ SDK audio load: {_time.time() - _t_load_start:.2f}s")

        print(f"[Audio2Face SDK] Audio: {len(samples)} samples ({len(samples)/16000:.2f}s)")
        _t_ctx_start = _time.time()
        with A2FContext(_SDK_MODEL_PATH) as ctx:
            _t_ctx_init = _time.time() - _t_ctx_start
            print(f"[Audio2Face] ⏱ SDK A2FContext init: {_t_ctx_init:.2f}s")

            _t_infer_start = _time.time()
            frames_raw = ctx.process_audio(
                samples,
                emotion_vectors=None,
                input_strength=props.input_strength,
                upper_face_strength=props.upper_face_strength,
                lower_face_strength=props.lower_face_strength,
                upper_face_smoothing=props.upper_face_smoothing,
                lower_face_smoothing=props.lower_face_smoothing,
                skin_strength=props.skin_strength,
                blink_strength=props.blink_strength,
                lip_open_offset=props.lip_open_offset,
                tongue_strength=props.tongue_strength,
            )
            print(f"[Audio2Face] ⏱ SDK process_audio: {_time.time() - _t_infer_start:.2f}s")

        _t_build_start = _time.time()
        import a2f_engine as _native
        multipliers = _build_weight_multipliers(props)

        sdk_fps = 60.0
        step_s = 1.0 / sdk_fps
        result = []
        for i, raw_weights in enumerate(frames_raw):
            named = _native.map_sdk_output(
                [float(w) for w in raw_weights], multipliers
            )
            bf = BlendshapeFrame(time=i * step_s, weights=named)
            result.append(bf)
        print(f"[Audio2Face] ⏱ SDK build frames: {_time.time() - _t_build_start:.2f}s")

        if fps != 60:
            _t_resample_start = _time.time()
            result = self._resample_frames(result, fps)
            print(f"[Audio2Face] ⏱ SDK resample: {_time.time() - _t_resample_start:.2f}s")

        _t_adv_start = _time.time()
        result = _apply_advanced_controls(result, props, utterances=utterances)
        print(f"[Audio2Face] ⏱ SDK advanced controls: {_time.time() - _t_adv_start:.2f}s")

        print(f"[Audio2Face SDK] Output: {len(result)} frames at {fps}fps")
        return result

    def _resample_frames(self, frames: list, target_fps: float) -> list:
        from ..core.blendshape import BlendshapeFrame
        if not frames:
            return frames
        source_fps = 60.0
        if abs(target_fps - source_fps) < 0.01:
            return frames

        # Use integer frame index to avoid floating-point accumulation drift.
        # Repeated `t += step_dst` accumulates error (e.g. after 60 steps of
        # 1/30, t = 1.9999999999999998 instead of 2.0), which can produce
        # one extra or one missing frame at the end and shift the reported
        # seg_end off by one.
        result = []
        step_dst = 1.0 / target_fps
        max_time = frames[-1].time
        # Number of destination frames that fit within [0, max_time].
        # The +0.5 tolerance accounts for the source data ending exactly
        # on a frame boundary.
        n_dst = int(max_time * target_fps + 0.5) + 1
        for i in range(n_dst):
            t = i * step_dst
            named = _sample_frame_weights(frames, t)
            result.append(BlendshapeFrame(time=t, weights=named))
        return result

"""Emotion segmentation templates (ARKit blendshape weight presets).

Pure data + blending helpers for the manual emotion segmentation feature.

Design:
  - ASR splits the audio into utterances (each is one emotion segment).
  - The user manually assigns an emotion type + intensity to each segment.
  - Each emotion maps to an ARKit blendshape weight preset (the "template").
  - The final animation blends these templates across segments with a
    cross-fade so transitions between emotions are natural.

Template values are tuned to produce visible emotion expression on both A2F_RIG
and DAZ rigs. Values CAN exceed 1.0 because:
  1. The emotion fusion applies deltas additively on top of SDK output, so
     a delta of 1.2 on a 0.0 baseline produces a final weight of 1.2 (not
     capped — the write paths handle over-driving gracefully).
  2. DAZ G8.1 _div2 properties halve the input, so scale=2.0 compensation
     is applied in daz_mapping.py to restore full strength.

Per project requirement, emotion blending should primarily affect non-mouth
areas (brows, eyes, cheeks) to preserve lip-sync. Mouth-channel values are
kept moderate here; they can be tuned per emotion later.
"""

from typing import Dict

# ---------------------------------------------------------------------------
# Emotion identifiers (ASCII, safe for Blender EnumProperty)
# ---------------------------------------------------------------------------
EMOTION_NEUTRAL = "NEUTRAL"
EMOTION_ANGRY = "ANGRY"
EMOTION_SMILE = "SMILE"
EMOTION_SMILE_OPEN = "SMILE_OPEN"
EMOTION_LAUGH = "LAUGH"
EMOTION_SAD = "SAD"
EMOTION_SURPRISED = "SURPRISED"
EMOTION_DISGUST = "DISGUST"
EMOTION_FEAR = "FEAR"
EMOTION_CONTEMPT = "CONTEMPT"
EMOTION_THINKING = "THINKING"
EMOTION_COQUETRY = "COQUETRY"
EMOTION_MALICIOUS = "MALICIOUS"

# Ordered list of all emotion identifiers (drives the UI dropdown order).
EMOTION_IDS = [
    EMOTION_NEUTRAL,
    EMOTION_ANGRY,
    EMOTION_SMILE,
    EMOTION_SMILE_OPEN,
    EMOTION_LAUGH,
    EMOTION_SAD,
    EMOTION_SURPRISED,
    EMOTION_DISGUST,
    EMOTION_FEAR,
    EMOTION_CONTEMPT,
    EMOTION_THINKING,
    EMOTION_COQUETRY,
    EMOTION_MALICIOUS,
]

# English display labels (used as i18n keys). The UI translates via t().
EMOTION_LABELS = {
    EMOTION_NEUTRAL: "Neutral",
    EMOTION_ANGRY: "Angry",
    EMOTION_SMILE: "Smile (No Teeth)",
    EMOTION_SMILE_OPEN: "Smile Open",
    EMOTION_LAUGH: "Laugh",
    EMOTION_SAD: "Sad",
    EMOTION_SURPRISED: "Surprised",
    EMOTION_DISGUST: "Disgust",
    EMOTION_FEAR: "Fear",
    EMOTION_CONTEMPT: "Contempt",
    EMOTION_THINKING: "Thinking",
    EMOTION_COQUETRY: "Coquetry",
    EMOTION_MALICIOUS: "Malicious",
}

# ---------------------------------------------------------------------------
# Emotion templates (ARKit blendshape weight presets)
#
# The template weight data lives in the compiled C++ engine
# (a2f_engine.pyd) to protect the IP. Python only exposes the engine call
# via get_emotion_template() below.
# ---------------------------------------------------------------------------


def get_emotion_template(emotion_id: str) -> Dict[str, float]:
    """Return the ARKit weight preset for an emotion id (empty dict if unknown).

    The template weight data lives in the compiled C++ engine
    (a2f_engine.pyd) to protect the IP. This wrapper delegates the lookup
    there and returns an empty dict if the engine is unavailable.
    """
    try:
        import a2f_engine as _native
        return _native.get_emotion_template(emotion_id) or {}
    except Exception:
        return {}


def get_emotion_label(emotion_id: str) -> str:
    """Return the English display label for an emotion id (i18n key)."""
    return EMOTION_LABELS.get(emotion_id, emotion_id)
"""Timeline marker helpers for character-level timestamp visualization and editing.

Markers created by forced alignment / apply-edited-text are named:
  Start marker: "A2F_{index}_{char}"     e.g. "A2F_0_liu", "A2F_1_xia"
  End marker:   "A2F_{index}_{char}_end" e.g. "A2F_5_a_end"

To avoid encoding issues with CJK characters in marker names, we store the
character in the marker name using a safe scheme: the index is the primary
key, and the character is appended for user readability. When reading back,
we sort by index to reconstruct the character sequence from the ASR text.

The start marker marks the character's onset frame; the end marker (optional)
marks the character's offset frame. Characters without an end marker use the
next character's start as their end (natural transition). Characters with an
end marker create a silence gap between end and next start (mouth relaxes to
neutral).

All marker operations are scoped to the timeline frame range
(scene.frame_start .. scene.frame_end) and only affect markers with the
"A2F_" prefix, leaving user-created markers untouched.
"""

import bpy
from typing import List, Dict, Optional

A2F_PREFIX = "A2F_"
END_SUFFIX = "_end"


def _is_a2f_marker(marker) -> bool:
    """True if marker name starts with A2F_PREFIX."""
    return marker.name.startswith(A2F_PREFIX)


def _is_end_marker(marker) -> bool:
    """True if marker is an A2F end marker (name ends with _end)."""
    return _is_a2f_marker(marker) and marker.name.endswith(END_SUFFIX)


def _is_start_marker(marker) -> bool:
    """True if marker is an A2F start marker (not an end marker)."""
    return _is_a2f_marker(marker) and not marker.name.endswith(END_SUFFIX)


def _parse_marker_index(marker) -> int:
    """Extract the integer index from an A2F marker name.

    Name format: "A2F_{index}_{char}" or "A2F_{index}_{char}_end"
    Returns -1 if parsing fails.
    """
    name = marker.name
    if name.startswith(A2F_PREFIX):
        name = name[len(A2F_PREFIX):]
    if name.endswith(END_SUFFIX):
        name = name[:-len(END_SUFFIX)]
    # name is now "{index}_{char}"
    parts = name.split("_", 1)
    if parts and parts[0].lstrip("-").isdigit():
        try:
            return int(parts[0])
        except ValueError:
            return -1
    return -1


def clear_a2f_markers(scene) -> int:
    """Remove all A2F markers within the scene's frame range.

    Returns the number of markers removed.
    """
    frame_start = scene.frame_start
    frame_end = scene.frame_end
    removed = 0
    # Iterate over a copy since we modify the collection
    for marker in list(scene.timeline_markers):
        if not _is_a2f_marker(marker):
            continue
        if frame_start <= marker.frame <= frame_end:
            scene.timeline_markers.remove(marker)
            removed += 1
    return removed


def create_char_markers(
    scene,
    chars_data: List[Dict],
    fps: float,
    frame_offset: int,
) -> int:
    """Create start markers for each character in chars_data.

    Clears existing A2F markers in the frame range first, then creates one
    start marker per character at the character's onset frame.

    Args:
        scene: bpy.context.scene
        chars_data: list of {'char': str, 'start': float, 'end': float}
                    (start/end in seconds)
        fps: scene FPS for time->frame conversion
        frame_offset: frame offset (audio may not start at frame 1)

    Returns the number of markers created.
    """
    # Clear existing A2F markers in range
    clear_a2f_markers(scene)

    count = 0
    for i, char_info in enumerate(chars_data):
        start_time = char_info['start']
        # Convert seconds -> frame number
        frame = int(round(start_time * fps)) + frame_offset
        char = char_info.get('char', '?')
        # Build safe marker name: A2F_{index}_{char}
        name = f"{A2F_PREFIX}{i}_{char}"
        # Avoid name collisions (shouldn't happen after clear, but be safe)
        if name in scene.timeline_markers:
            scene.timeline_markers.remove(scene.timeline_markers[name])
        scene.timeline_markers.new(name=name, frame=frame)
        count += 1

    return count


def add_end_marker(
    scene,
    selected_marker_name: str,
    current_frame: int,
) -> bool:
    """Add an end marker for the given start marker at current_frame.

    Args:
        scene: bpy.context.scene
        selected_marker_name: name of the start marker to add end for
        current_frame: frame number for the end marker position

    Returns True on success, False on failure.
    """
    if not selected_marker_name:
        return False
    start_marker = scene.timeline_markers.get(selected_marker_name)
    if start_marker is None:
        return False
    if not _is_start_marker(start_marker):
        return False

    end_name = selected_marker_name + END_SUFFIX
    # Remove existing end marker if present
    if end_name in scene.timeline_markers:
        scene.timeline_markers.remove(scene.timeline_markers[end_name])
    scene.timeline_markers.new(name=end_name, frame=current_frame)
    return True


def read_char_markers(
    scene,
    fps: float,
    frame_offset: int,
) -> List[Dict]:
    """Read A2F markers and reconstruct char-level timestamp data.

    Reads all A2F start and end markers within the scene frame range, sorts
    by index, and builds a list of {'char', 'start', 'end'} dicts where
    start/end are in seconds.

    For characters without an explicit end marker, end = next character's
    start. For characters with an end marker, end = end marker's time.
    The last character's end defaults to its start + a reasonable duration
    (or the scene end frame if no end marker).

    Args:
        scene: bpy.context.scene
        fps: scene FPS for frame->time conversion
        frame_offset: frame offset

    Returns:
        List of {'char': str, 'start': float, 'end': float} sorted by index.
        Empty list if no A2F markers found.
    """
    frame_start = scene.frame_start
    frame_end = scene.frame_end

    # Collect start markers and end markers separately
    start_markers = {}  # index -> (marker, char)
    end_markers = {}    # index -> frame

    for marker in scene.timeline_markers:
        if not _is_a2f_marker(marker):
            continue
        if not (frame_start <= marker.frame <= frame_end):
            continue

        idx = _parse_marker_index(marker)
        if idx < 0:
            continue

        if _is_end_marker(marker):
            end_markers[idx] = marker.frame
        elif _is_start_marker(marker):
            # Extract char from name: "A2F_{index}_{char}"
            name = marker.name[len(A2F_PREFIX):]
            parts = name.split("_", 1)
            char = parts[1] if len(parts) > 1 else "?"
            start_markers[idx] = (marker, char)

    if not start_markers:
        return []

    # Sort by index
    sorted_indices = sorted(start_markers.keys())

    # Build char data
    result = []
    scene_end_time = (frame_end - frame_offset) / float(fps)
    for i, idx in enumerate(sorted_indices):
        marker, char = start_markers[idx]
        start_time = (marker.frame - frame_offset) / float(fps)

        # Determine end time
        if idx in end_markers:
            # Explicit end marker
            end_time = (end_markers[idx] - frame_offset) / float(fps)
        elif i + 1 < len(sorted_indices):
            # No end marker: use next char's start
            next_idx = sorted_indices[i + 1]
            next_marker, _ = start_markers[next_idx]
            end_time = (next_marker.frame - frame_offset) / float(fps)
        else:
            # Last char without end marker: use scene end
            end_time = scene_end_time

        # Ensure end > start (fallback: +0.3s)
        if end_time <= start_time:
            end_time = start_time + 0.3

        result.append({
            'char': char,
            'start': start_time,
            'end': end_time,
        })

    return result


def get_selected_a2f_start_marker(scene) -> Optional[str]:
    """Return the name of the selected A2F start marker, if any.

    Blender's timeline markers can be selected. This returns the name of
    the first selected A2F start marker, or None.
    """
    for marker in scene.timeline_markers:
        if not marker.select:
            continue
        if not _is_start_marker(marker):
            continue
        return marker.name
    return None

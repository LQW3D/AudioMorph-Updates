"""ARKit 52 -> Faceit ControlRig bone transform mapping.

The Faceit ControlRig drives mesh shape keys through bone transforms
(location/rotation) + driver expressions. The driver chain is:

    pose_bone.location[axis]  (or rotation_euler[axis])
        |  driver variable "var"  (transform_type, LOCAL_SPACE)
        v
    driver expression: (var / divisor) * amp
        |  amp = rig["<shapeKeyName>"]  (Object-level custom property)
        v
    mesh shape_key["<name>"].value  (final mesh deformation)

We write keyframes to the pose bone's location/rotation. The driver
automatically applies the divisor and amp, so:
    bone_value = arkit_weight * divisor
    driver output = bone_value / divisor * amp = arkit_weight * amp

When amp = 1.0 (default), the final shape key value equals the ARKit
weight, matching the A2F rig behavior.

Mapping table entry: (bone_name, transform_type, axis_index, divisor)
  - transform_type: 'LOCATION' or 'ROTATION'
  - axis_index: 0=X, 1=Y, 2=Z
  - divisor: the divisor in the (var/divisor) expression; sign encodes
    direction (negative divisor means the bone moves in the negative
    axis direction for a positive ARKit weight).

Eye look is special: in 3D mode (c_SwitchLookAt_slider at Y=4.0),
eye direction is controlled by c_lookat_mch.L/R bone rotation, not by
the 2D slider. The driver expressions use min/max to split a single
rotation axis into two opposite ARKit directions (Up/Down on ROT_X,
In/Out on ROT_Z). Eye look is handled separately in the write function,
not via the mapping table.
"""

from typing import Dict, List, Tuple

def detect_faceit_rig(rig) -> bool:
    """Return True if the given armature looks like a Faceit ControlRig.

    Detection checks for the presence of c_* controller bones that are
    used by Faceit's driver system (e.g. c_jaw_target, c_lips_corner.L).
    We also verify that at least one mesh in the scene has shape key
    drivers referencing this rig's bones.
    """
    if rig is None or rig.type != 'ARMATURE':
        return False

    # Check for signature c_* controller bones
    bone_names = {b.name for b in rig.data.bones}
    signature_bones = {
        'c_jaw_target', 'c_lips_corner.L', 'c_lips_corner.R',
        'c_eyelid_upper.L', 'c_eyelid_upper.R',
    }
    if not signature_bones.issubset(bone_names):
        return False

    # Check that at least one mesh has shape key drivers referencing
    # this rig's bones (confirms the driver network is set up).
    import bpy
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or not obj.data.shape_keys:
            continue
        if not obj.data.shape_keys.animation_data:
            continue
        for fcu in obj.data.shape_keys.animation_data.drivers:
            for v in fcu.driver.variables:
                for t in v.targets:
                    if t.bone_target in bone_names:
                        return True
    return False


def get_faceit_mapping(rig) -> Dict[str, List[Tuple[str, str, int, float]]]:
    """Return ARKit -> [(bone, transform_type, axis, divisor)] mapping.

    Only bones that actually exist on the rig are included, so the write
    path never references a missing bone. Eye look channels are returned
    as empty lists (handled separately in the write function).

    The mapping table lives in the compiled C++ engine (a2f_engine.pyd)
    to protect the IP. This function extracts bone names in Python
    (Blender-specific), then delegates the table lookup and filtering
    to the native engine.

    Args:
        rig: Blender Object of type ARMATURE (the Faceit ControlRig).

    Returns:
        Dict mapping ARKit expression name -> list of mapping entries.
        Empty dict if the rig is not a Faceit ControlRig.
    """
    if rig is None or rig.type != 'ARMATURE':
        return {}

    bone_names = {b.name for b in rig.data.bones}
    if not bone_names:
        return {}

    try:
        import a2f_engine as _native
        bones_list = sorted(bone_names)
        return _native.build_faceit_mapping(bones_list)
    except Exception:
        return {}

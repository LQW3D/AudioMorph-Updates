"""Audio2Face UI panel.

The closed-source refactor removed the Binding and Animation pages; only
the DAZ page remains. The DAZ page drives a DAZ FACS rig from audio: bind
DAZ rig -> import audio -> generate -> phoneme correction -> emotion
segmentation -> post processing.
"""

import bpy
from bpy.props import EnumProperty

from ..utils.i18n import t


def _draw_emotion_segmentation_ui(layout, props):
    """Draw the manual emotion segmentation UI block.

    ASR splits the audio into utterances; each row is one emotion segment.
    The user assigns an emotion type + intensity per row, corrects the start
    frame by moving the playhead and clicking "Correct", and can add/remove
    rows with the +/- buttons. The text under each row helps the user identify
    which segment they are editing.
    """
    box = layout.box()
    header = box.row()
    header.label(text=t("Emotion Segmentation"), icon='SEQ_STRIP_META')

    row = box.row()
    row.prop(props, "emotion_segments_enabled", text=t("Enable Emotion Segmentation"))

    if not props.emotion_segments_enabled:
        return

    # Add + clear buttons (manual segmentation only — ASR-based segmentation
    # was removed because the manual "+ / correct" workflow is faster and
    # gives the user precise frame control via the timeline playhead.)
    row = box.row(align=True)
    row.scale_y = 1.2
    row.operator("audio2face.emotion_segment_add", text=t("Add Segment"), icon='ADD')
    row.operator("audio2face.emotion_segment_clear", text="", icon='TRASH')

    if not props.emotion_segments:
        row = box.row()
        row.label(text=t("No segments yet. Click Add above to create one."), icon='INFO')
        return

    # Header row: segment count
    row = box.row()
    row.label(text=t("Segments"), icon='OUTLINER_OB_FORCE_FIELD')

    # Each segment row
    for idx, seg in enumerate(props.emotion_segments):
        sub = box.box()
        # Row 1: frame + correct button + remove button
        r = sub.row(align=True)
        r.label(text=f"#{idx + 1}", icon='DOT')
        r.prop(seg, "frame", text=t("Frame"))
        op = r.operator("audio2face.emotion_segment_correct_frame",
                        text=t("Correct"), icon='SNAP_ON')
        op.segment_index = idx
        op2 = r.operator("audio2face.emotion_segment_remove",
                         text="", icon='X')
        op2.segment_index = idx

        # Row 2: emotion dropdown (alone on its own row)
        r = sub.row(align=True)
        r.prop(seg, "emotion", text="")

        # Row 3: non-mouth intensity + non-mouth min ratio
        r = sub.row(align=True)
        r.prop(seg, "intensity", text=t("Non-Mouth"))
        r.prop(seg, "non_mouth_min_ratio", text=t("Non-Mouth Min"))

        # Row 4: mouth intensity + mouth min ratio
        r = sub.row(align=True)
        r.prop(seg, "mouth_intensity", text=t("Mouth"))
        r.prop(seg, "mouth_min_ratio", text=t("Mouth Min"))

        # Row 5: recognized text (helps the user identify the segment)
        if seg.text:
            lbl = sub.row()
            lbl.scale_y = 0.9
            lbl.label(text=seg.text, icon='GREASEPENCIL')


# ============================================================
# Navigation Operators
# ============================================================

class AUDIO2FACE_OT_set_page(bpy.types.Operator):
    """Switch the Audio2Face main page"""
    bl_idname = "audio2face.set_page"
    bl_label = t("Set Page")
    bl_description = t("Switch Audio2Face main page")
    bl_options = {'INTERNAL'}

    # Only the DAZ page remains after the closed-source refactor. The
    # operator is kept (and registered) for backward compatibility with
    # saved .blend files that may store page-switch UI state, but it only
    # offers the DAZ page now.
    page: EnumProperty(
        name=t("Page"),
        items=[
            ('DAZ', t("DAZ"), t("Drive DAZ FACS rig from audio")),
        ],
        default='DAZ',
    )

    def execute(self, context):
        context.scene.audio2face_props.active_page = self.page
        return {'FINISHED'}


# ============================================================
# Main Panel
# ============================================================

class AUDIO2FACE_PT_main_panel(bpy.types.Panel):
    bl_label = t("Audio2Face Audio-Driven Facial Animation")
    bl_idname = "AUDIO2FACE_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Audio2Face'

    def draw(self, context):
        self.bl_label = t("Audio2Face Audio-Driven Facial Animation")
        layout = self.layout

        # --- Update banner at the very top of the panel. Grey when up to
        # date, red when an update is available; clicking opens the addon
        # preferences page where the per-part update buttons live. ---
        self._draw_update_banner(layout)

        # --- Engine self-check: show a visible banner if the native engine
        # cannot be used, instead of silently producing degraded animation. ---
        from ..core.license_manager import get_engine_status
        _ok, _msg = get_engine_status()
        if not _ok:
            box = layout.box()
            box.alert = True
            box.label(text=t("Engine Error"), icon='ERROR')
            box.label(text=t("The core engine failed to load. Animation will be unavailable or incorrect."),
                      icon='INFO')
            box.label(text=_msg, icon='NONE')
            # Still draw the activation page below so licensing is not blocked.
        else:
            from ..core.license_manager import is_activated, get_device_id
            if not is_activated():
                self._draw_activation_page(context, layout)
                return

            props = context.scene.audio2face_props
            self._draw_daz_page(context, layout, props)

    # ---------- Update Banner ----------

    def _draw_update_banner(self, layout):
        """Draw the top update button (grey when up to date, red when not)."""
        try:
            from ..operators.update import get_update_parts
            updates = get_update_parts()
        except Exception:
            updates = []
        row = layout.row()
        if updates:
            row.alert = True
            row.operator("audio2face.open_preferences",
                         text=t("Update Available"), icon='FILE_REFRESH')
        else:
            row.enabled = False
            row.operator("audio2face.open_preferences",
                         text=t("Up to Date"), icon='CHECKMARK')

    # ---------- Activation Page ----------

    def _draw_activation_page(self, context, layout):
        """Show the activation page when the software is not yet activated."""
        from ..core.license_manager import get_device_id

        box = layout.box()
        box.label(text=t("Activation Required"), icon='LOCKED')

        col = box.column(align=True)
        col.label(text=t("This plugin requires activation."), icon='INFO')
        col.label(text=t("Please contact the developer to purchase."), icon='NONE')

        # Device ID display (read-only)
        box.separator()
        dev_id = get_device_id()
        row = box.row()
        row.label(text=t("Your Device ID:"), icon='USER')
        row = box.row()
        row.label(text=dev_id if dev_id else t("(unavailable)"),
                  icon='NONE')

        # Copy button
        row = box.row()
        row.operator("audio2face.copy_device_id", text=t("Copy Device ID"),
                     icon='COPY_ID')

        # Activation key input
        box.separator()
        box.label(text=t("Enter Activation Key:"), icon='KEYINGSET')

        row = box.row()
        row.prop(context.scene, "audio2face_activation_key", text="",
                 slider=False)

        row = box.row()
        row.operator("audio2face.activate", text=t("Activate"),
                     icon='CHECKMARK')

        # Status message
        status = getattr(context.scene, "audio2face_activation_status", "")
        if status:
            row = box.row()
            row.label(text=status, icon='ERROR')

    # ---------- DAZ Page ----------

    def _draw_daz_page(self, context, layout, props):
        """Rig mode: bind rig -> import audio -> generate.

        The page keeps its own audio_file and rig pointer state in
        scene.audio2face_daz_props, but reuses the SDK/animator settings and
        phoneme-correction controls from the main audio2face_props so the
        user only configures them once.

        Supports two rig controller types:
        - DAZ FACS: drives Object-level facs_* custom properties
        - Faceit ControlRig: drives c_* bone transforms (location/rotation)
        """
        daz_props = context.scene.audio2face_daz_props

        # ============================================================
        # 1. Rig selection + controller type + auto-detection status
        # ============================================================
        box = layout.box()
        box.label(text=t("DAZ Model Binding"), icon='OUTLINER_OB_ARMATURE')

        # Controller type dropdown — determines which mapping table and
        # write path is used. Placed above the rig selector so the user
        # picks the type first, then selects the matching armature.
        row = box.row()
        row.prop(daz_props, "rig_type", text=t("Rig Controller Type"))

        row = box.row(align=True)
        row.prop_search(daz_props, "daz_rig_object", bpy.data, "objects",
                        text=t("Armature"), icon='ARMATURE_DATA')
        row.operator("audio2face.pick_daz_rig", text="", icon='EYEDROPPER')

        # Show detection status for the selected rig based on controller type
        rig = bpy.data.objects.get(daz_props.daz_rig_object) if daz_props.daz_rig_object else None
        if rig:
            if rig.type == 'ARMATURE':
                if daz_props.rig_type == 'DAZ':
                    from ..daz.daz_mapping import detect_daz_rig, count_daz_facs_props, get_daz_mapping
                    if detect_daz_rig(rig):
                        facs_count = count_daz_facs_props(rig)
                        mapping = get_daz_mapping(rig)
                        box.label(text=f"{t('FACS Properties')}: {facs_count}  |  "
                                       f"{t('Mapped ARKit')}: {len(mapping)}",
                                  icon='CHECKMARK')
                    else:
                        box.label(text=t("Not a DAZ FACS rig (no facs_*(fin) properties)"),
                                  icon='ERROR')
                else:  # FACEIT
                    from ..daz.faceit_mapping import detect_faceit_rig, get_faceit_mapping
                    if detect_faceit_rig(rig):
                        mapping = get_faceit_mapping(rig)
                        box.label(text=f"{t('Faceit Controller Bones')}: {len(mapping)}  |  "
                                       f"{t('Faceit Mapped ARKit')}: {len(mapping)}",
                                  icon='CHECKMARK')
                    else:
                        box.label(text=t("Not a Faceit ControlRig (no c_* controller bones or shape key drivers)"),
                                  icon='ERROR')
            else:
                box.label(text=t("Selected object is not an armature"), icon='ERROR')
        else:
            box.label(text=t("Select an armature with rig controllers"), icon='INFO')

        # ============================================================
        # 2. Audio input
        # ============================================================
        box = layout.box()
        box.label(text=t("Audio Input"), icon='SPEAKER')
        row = box.row()
        row.prop(daz_props, "audio_file", text=t("Audio File"))

        # Frame rate: placed between audio file selection and import button
        row = box.row()
        row.prop(context.scene.render, "fps", text=t("Frame Rate"))

        row = box.row()
        row.operator("audio2face.daz_import_audio",
                     text=t("Import Audio to Timeline"), icon='IMPORT')

        # ============================================================
        # 3. Phoneme correction (DAZ page keeps its own copy now)
        # ============================================================
        box = layout.box()
        header = box.row()
        header.label(text=t("Phoneme Correction"), icon='SHAPEKEY_DATA')

        row = box.row()
        row.prop(daz_props, "enable_phoneme_correction", text=t("Enable Phoneme Correction"))

        if daz_props.enable_phoneme_correction:
            row = box.row()
            row.prop(daz_props, "phoneme_correction_strength", text=t("Correction Strength"))
            if not daz_props.has_animation_data:
                row = box.row()
                row.label(text=t("Generate animation first to apply strength"), icon='INFO')

            # Editable ASR text box: user can fix misrecognitions (e.g. song
            # lyrics) and click Apply to regenerate phonemes without re-running
            # ASR or SDK.
            if daz_props.has_animation_data and daz_props.asr_recognized_text:
                col = box.column()
                col.label(text=t("ASR Text (editable)"), icon='TEXT')
                # Row: single-line text field + "Edit" button that opens a
                # multi-line resizable editor with auto-wrap.
                row = col.row(align=True)
                row.prop(daz_props, "asr_recognized_text", text="")
                row.operator("audio2face.daz_open_text_editor", text="", icon='TEXT')
                row = col.row()
                row.scale_y = 1.2
                row.operator("audio2face.daz_apply_edited_text", text=t("Apply Edited Text"), icon='FILE_REFRESH')
                # Force Align button: for fixing dropped characters (fast songs)
                row = col.row()
                row.scale_y = 1.2
                row.operator("audio2face.daz_forced_align_text", text=t("Force Align Text"), icon='ALIGN_CENTER')
                # Timeline marker tools: add end marker (shared) + fix timestamps (DAZ)
                row = col.row()
                row.scale_y = 1.2
                row.operator("audio2face.add_char_end_marker", text=t("Add End Marker"), icon='MARKER_HLT')
                row = col.row()
                row.scale_y = 1.2
                row.operator("audio2face.daz_fix_timestamps_from_markers", text=t("Fix Timestamps from Markers"), icon='PREVIEW_RANGE')

        # ============================================================
        # 4. Emotion segmentation UI (shared with Animation page)
        # ============================================================
        _draw_emotion_segmentation_ui(layout, daz_props)

        # ============================================================
        # 5. Generate animation (after emotion, before settings)
        # ============================================================
        row = layout.row()
        row.scale_y = 1.5
        row.operator("audio2face.daz_generate", text=t("Generate Animation"), icon='PLAY')

        # Status message
        if daz_props.status_message and daz_props.status_message != "Ready":
            box = layout.box()
            box.label(text=daz_props.status_message, icon='INFO')


# ============================================================
# Sub-panels (settings and post-processing for the DAZ page)
# ============================================================

class AUDIO2FACE_PT_settings_panel(bpy.types.Panel):
    bl_label = t("Settings")
    bl_idname = "AUDIO2FACE_PT_settings_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Audio2Face'
    bl_parent_id = "AUDIO2FACE_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        # Only show when activated.
        from ..core.license_manager import is_activated
        if not is_activated():
            return False
        return bool(getattr(context.scene, "audio2face_daz_props", None))

    def draw(self, context):
        self.bl_label = t("Settings")
        layout = self.layout
        # Only the DAZ page remains; always read from audio2face_daz_props.
        props = context.scene.audio2face_daz_props

        box = layout.box()
        box.label(text=t("Basic Settings"), icon='ANIM')
        # Note: Frame rate is no longer in this panel. It lives between the
        # generate button and phoneme correction on each page so users don't
        # confuse it with tunable parameters that get saved into presets.
        row = box.row()
        row.prop(props, "upper_face_strength", text=t("Upper Face"))
        row.prop(props, "lower_face_strength", text=t("Lower Face"))

        box = layout.box()
        row = box.row()
        row.prop(props, "show_advanced_settings",
                 text=t("Advanced Settings"),
                 icon='TRIA_DOWN' if props.show_advanced_settings else 'TRIA_RIGHT',
                 emboss=False)

        if props.show_advanced_settings:
            col = box.column()
            col.label(text=t("Global Adjustment"), icon='WORLD')
            row = col.row()
            row.prop(props, "input_strength", text=t("Input Strength"))
            row.prop(props, "skin_strength", text=t("Skin Strength"))

            col.separator()
            col.label(text=t("Smoothing"), icon='MODIFIER')
            row = col.row()
            row.prop(props, "upper_face_smoothing", text=t("Upper Face"))
            row.prop(props, "lower_face_smoothing", text=t("Lower Face"))

            col.separator()
            col.label(text=t("Mouth Adjustment"), icon='SHAPEKEY_DATA')
            row = col.row()
            row.prop(props, "jaw_open_multiplier", text=t("Jaw Open"))
            row.prop(props, "mouth_close_multiplier", text=t("Mouth Close"))
            row = col.row()
            row.prop(props, "prediction_delay", text=t("Lip Sync Delay"))
            row = col.row()
            row.prop(props, "jaw_left_right_multiplier", text=t("Left/Right"))
            row = col.row()
            row.prop(props, "lip_open_offset", text=t("Lip Offset"))
            row.prop(props, "tongue_strength", text=t("Tongue"))
            col.separator()
            col.label(text=t("Lower Lip Adjustment"), icon='ERROR')
            row = col.row()
            row.prop(props, "mouth_roll_lower_multiplier", text=t("Lower Lip Roll"))
            row.prop(props, "mouth_shrug_lower_multiplier", text=t("Lower Lip Shrug"))
            row = col.row()
            row.prop(props, "mouth_lower_down_multiplier", text=t("Lower Lip Down"))

            col.separator()
            col.label(text=t("Upper Lip Adjustment"), icon='ERROR')
            row = col.row()
            row.prop(props, "mouth_roll_upper_multiplier", text=t("Upper Lip Roll"))
            row.prop(props, "mouth_shrug_upper_multiplier", text=t("Upper Lip Shrug"))
            row = col.row()
            row.prop(props, "mouth_upper_up_multiplier", text=t("Upper Lip Up"))

            col.separator()
            col.label(text=t("Eye Adjustment"), icon='HIDE_OFF')
            row = col.row()
            row.prop(props, "blink_strength", text=t("Blink"))
            row.prop(props, "blink_interval", text=t("Blink Interval"))
            row = col.row()
            row.prop(props, "eyeballs_strength", text=t("Eye Movement"))
            row.prop(props, "saccade_strength", text=t("Saccade"))

        # ---- Preset template management ----
        # Dropdown + 3 small buttons (load / save as / delete). Templates
        # are stored in config/presets/ and apply to the DAZ page.
        box = layout.box()
        box.label(text=t("Parameter Preset"), icon='PRESET')
        row = box.row(align=True)
        row.prop(props, "preset_selection", text=t("Preset"))
        row.operator("audio2face.load_preset", text="", icon='IMPORT')
        row.operator("audio2face.save_as_preset", text="", icon='ADD')
        row.operator("audio2face.delete_preset", text="", icon='REMOVE')

        layout.operator("audio2face.save_defaults", text=t("Save as Default"), icon='FILE_TICK')


class AUDIO2FACE_PT_post_adjust_panel(bpy.types.Panel):
    bl_label = t("Post Processing")
    bl_idname = "AUDIO2FACE_PT_post_adjust_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Audio2Face'
    bl_parent_id = "AUDIO2FACE_PT_main_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        # Only show when activated.
        from ..core.license_manager import is_activated
        if not is_activated():
            return False
        return bool(getattr(context.scene, "audio2face_daz_props", None))

    def draw(self, context):
        self.bl_label = t("Post Processing")
        layout = self.layout
        # Only the DAZ page remains; always read from audio2face_daz_props
        # and dispatch to the daz_* post-process operators.
        props = context.scene.audio2face_daz_props

        if not props.has_animation_data:
            layout.label(text=t("Please generate animation first"), icon='INFO')
            return

        box = layout.box()
        box.label(text=t("Animation Info"), icon='ANIM')
        box.label(text=f"{t('Total Frames')}: {props.animation_frame_count}")

        box = layout.box()
        box.label(text=t("Frame Range"), icon='RECORD_ON')
        row = box.row()
        row.prop(props, "frame_start", text=t("Start"))
        row.prop(props, "frame_end", text=t("End"))
        row.operator("audio2face.daz_set_frame_range", text="", icon='SNAP_ON')

        box = layout.box()
        box.label(text=t("Post-process Parameters"), icon='MODIFIER')
        row = box.row()
        row.prop(props, "post_smoothing", text=t("Post Smoothing"))
        row.prop(props, "post_strength", text=t("Post Strength"))

        # Mouth amplitude scale: uniformly scales JawOpen + MouthLowerDown +
        # MouthUpperUp. Only scales peak amplitude (no offset), so mouth
        # shapes stay crisp. <1.0=subdued for calm dialogue, >1.0=exaggerated
        # for excited dialogue. Applied in post-process, no re-generation needed.
        row = box.row()
        row.prop(props, "mouth_scale", text=t("Mouth Scale"))

        # Pucker scale + mouth stretch scale: peak-only amplitude knobs for
        # forward lip protrusion (o/u vowels) and horizontal mouth width.
        # Same post-process semantics as mouth_scale.
        row = box.row()
        row.prop(props, "pucker_scale", text=t("Pucker Scale"))
        row.prop(props, "mouth_stretch_scale", text=t("Stretch Scale"))

        # Lip closure fine-tuning: only effective within selected frame range, for clipping refinement
        col = box.column()
        col.label(text=t("Lip Closure Fine-tuning (frame range only)"), icon='MODIFIER')
        # Three-in-one linked slider (master)
        col.prop(props, "lip_closure_combined", text=t("Lip Closure (linked)"))

        # Advanced options collapsed: 3 independent parameters
        advanced_col = box.column()
        if props.show_advanced_lip_params:
            advanced_col.prop(props, "show_advanced_lip_params",
                              text=t("Hide Advanced"), icon='TRIA_DOWN', emboss=False)
            sub = advanced_col.column(align=True)
            sub.prop(props, "mouth_close_adjust", text=t("Mouth Close"))
            sub.prop(props, "jaw_open_adjust", text=t("Jaw Open"))
            sub.prop(props, "mouth_lower_down_adjust", text=t("Lower Lip"))
        else:
            advanced_col.prop(props, "show_advanced_lip_params",
                              text=t("Show Advanced"), icon='TRIA_RIGHT', emboss=False)

        box = layout.box()
        box.label(text=t("Adjust parameters and click Apply"), icon='MODIFIER')

        row = layout.row()
        row.scale_y = 1.5
        row.operator("audio2face.daz_apply_adjustments", text=t("Apply Adjustments"), icon='CHECKMARK')

        # Mouth shape repair: one-click auto-fix for closed-sound (b/p/m) closure issues
        row = layout.row()
        row.scale_y = 1.5
        row.operator("audio2face.daz_repair_lip_closure", text=t("Repair Lip Closure"), icon='MODIFIER')

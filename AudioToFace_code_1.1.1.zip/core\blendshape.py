from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class BlendshapeFrame:
    time: float
    weights: Dict[str, float]
    emotions: Optional[Dict[str, float]] = None

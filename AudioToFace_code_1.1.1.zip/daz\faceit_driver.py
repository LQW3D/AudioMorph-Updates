"""Faceit ControlRig driver: write ARKit weights to bone transforms as keyframes.

The Faceit ControlRig drives mesh shape keys through bone transforms +
driver expressions. We write keyframes to pose bone location/rotation,
and the drivers automatically apply the divisor and amp to produce the
final shape key values.

Write formula for location-driven channels:
    bone.location[axis] = arkit_weight * divisor
    driver: shape_key = (bone_value / divisor) * amp = arkit_weight * amp

Write formula for eye look (rotation-driven, 3D mode):
    left.ROT_X  = EyeLookUpLeft  - EyeLookDownLeft   (radians)
    right.ROT_X = EyeLookUpRight - EyeLookDownRight  (radians)
    left.ROT_Z  = EyeLookOutLeft - EyeLookInLeft     (radians)
    right.ROT_Z = EyeLookInRight - EyeLookOutRight   (radians)

Action / slot handling reuses the same logic as daz_driver.py: we
ensure an Action + OBJECT slot is bound before writing, so keyframes
are evaluated on Blender 5.x layered animation.
"""

import bpy
from typing import Dict, List, Tuple

# Faceit weight-domain adaptation (bilabial closure guard, lip-inversion
# disable, mouth-corner stretch scale, per-channel caps, MouthClose
# compensation, and the downward-moving channel set) is a protected recipe
# that lives in the compiled C++ engine (a2f_engine.pyd). Python only keeps
# the Blender driver/bone-write interaction and delegates all weight math to
# a2f_engine.adapt_faceit_weights() / a2f_engine.is_faceit_down_direction().


def _find_driven_meshes(rig):
    """Find ALL mesh objects whose shape keys are driven by this rig.

    A Faceit rig typically drives multiple meshes: the face mesh, upper
    teeth (牙齿上), lower teeth (牙齿下), tongue, etc. Each mesh has its
    own shape key drivers. When we flip a driver divisor sign, we MUST
    update the driver on EVERY mesh that references the bone — otherwise
    the un-updated meshes will compute negative shape key values (because
    bone.location sign flipped but their divisor did not), causing the
    mesh to deform in the opposite direction (e.g. lower lip tucking
    upward).
    """
    bone_names = {b.name for b in rig.data.bones}
    meshes = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or not obj.data.shape_keys:
            continue
        if not obj.data.shape_keys.animation_data:
            continue
        for fcu in obj.data.shape_keys.animation_data.drivers:
            for var in fcu.driver.variables:
                for target in var.targets:
                    if target.bone_target in bone_names or target.id == rig:
                        if obj not in meshes:
                            meshes.append(obj)
                        break
                else:
                    continue
                break
            else:
                continue
            break
    return meshes


def _restore_faceit_y_axis_directions(rig, mapping):
    """Restore downward-moving channels to NEGATIVE divisor.

    Blender evaluates LOC_Y in LOCAL_SPACE relative to the bone's parent.
    Experimentally verified on the user's Faceit rig: location.y = +1.0
    moves the bone UP (+Z world), location.y = -1.0 moves it DOWN.

    Therefore, for channels that must move DOWN (JawOpen / MouthLowerDown /
    MouthFrown), the driver expression must use a NEGATIVE divisor:
        (var/-3.0) * amp
    and the write divisor must be negative, so:
        bone_value = weight * (-3.0) = negative LOC_Y -> bone moves DOWN
        shape_key = LOC_Y / (-3.0) * amp = positive (correct)

    A previous faulty fix used the bone's rest-matrix Y column to guess
    direction and flipped these channels to POSITIVE divisor, which moved
    the jaw UP and caused lower-lip penetration. This function reverses
    that: it forces every downward channel back to a negative divisor in
    BOTH the driver expression and the returned write override. Idempotent.
    """
    overrides = {}

    import a2f_engine as _native

    for arkit_name, entries in mapping.items():
        if not _native.is_faceit_down_direction(arkit_name):
            continue
        for bone_name, transform_type, axis, divisor in entries:
            if transform_type == 'LOCATION' and axis == 1 and divisor < 0:
                neg_div = float(divisor)
                abs_div = abs(neg_div)
                sk_name = arkit_name[0].lower() + arkit_name[1:]

                # Restore driver expressions on ALL driven meshes from
                # a positive divisor (var/3.0) back to negative (var/-3.0).
                for mesh_obj in _find_driven_meshes(rig):
                    if not mesh_obj.data.shape_keys or not mesh_obj.data.shape_keys.animation_data:
                        continue
                    for fcu in mesh_obj.data.shape_keys.animation_data.drivers:
                        dp = fcu.data_path
                        if sk_name not in dp or '.value' not in dp:
                            continue
                        expr = fcu.driver.expression
                        pos = f"/{abs_div}"
                        neg = f"/-{abs_div}"
                        if pos in expr and neg not in expr:
                            fcu.driver.expression = expr.replace(pos, neg)

                overrides[arkit_name] = neg_div
                print(f"[Audio2Face Faceit] Y-axis restore: {arkit_name} bone "
                      f"'{bone_name}' set to negative divisor {neg_div} "
                      f"(LOC_Y negative = bone moves DOWN)")

    return overrides


def _ensure_action_slot(rig: bpy.types.Object):
    """Ensure rig.animation_data has an Action and a bound OBJECT slot.

    Same logic as daz_driver._ensure_action_slot. Reimplemented here
    to avoid a cross-module dependency on a private function.
    """
    if not rig.animation_data:
        rig.animation_data_create()
    anim_data = rig.animation_data

    if anim_data.action is None:
        action = bpy.data.actions.new(name=f"{rig.name}_Faceit_Anim")
        anim_data.action = action
    else:
        action = anim_data.action

    if hasattr(action, 'is_action_layered') and action.is_action_layered:
        slot = anim_data.action_slot
        if slot is None:
            if action.slots:
                try:
                    suitable = list(anim_data.action_suitable_slots)
                    if suitable:
                        slot = suitable[0]
                except Exception:
                    pass
                if slot is None:
                    slot = action.slots[0]
            else:
                slot = action.slots.new(id_type='OBJECT', name=rig.name)
            anim_data.action_slot = slot

        if not action.layers:
            action.layers.new("Layer")
        layer = action.layers[0]
        if not layer.strips:
            layer.strips.new(type='KEYFRAME')


def _ensure_writable_mode(rig: bpy.types.Object):
    """Ensure the rig is in a mode where pose bone keyframe_insert works.

    pose_bone.location assignment and keyframe_insert() work in both
    OBJECT and POSE modes — only EDIT mode blocks them. So we never
    force-enter POSE mode; if the user is in EDIT we switch to OBJECT
    (keeping the user in their current mode otherwise). This ensures
    the viewport stays in OBJECT mode after generation instead of
    jumping into POSE mode on the Faceit ControlRig.
    """
    if rig.mode == 'EDIT':
        try:
            bpy.context.view_layer.objects.active = rig
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    with bpy.context.temp_override(active_object=rig,
                                                    object=rig,
                                                    selected_objects=[rig],
                                                    area=area):
                        bpy.ops.object.mode_set(mode='OBJECT')
                    return
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            print(f"[Audio2Face Faceit] mode_set warning: {e}")
    # Ensure the rig is the active object so keyframe_insert context resolves.
    if bpy.context.view_layer.objects.active is not rig:
        bpy.context.view_layer.objects.active = rig


def apply_blendshapes_to_faceit_rig(
    rig: bpy.types.Object,
    frames: List,
    mapping: Dict[str, List],
    fps: int = 30,
    frame_offset: int = 0,
) -> bool:
    """Write ARKit weight frames to Faceit pose bone transforms as keyframes.

    Uses pose_bone.keyframe_insert() for location and rotation_euler.
    Multiple ARKit channels sharing the same bone+axis are summed before
    writing. Eye look channels are handled via rotation on c_lookat_mch
    bones.

    Args:
        rig: Faceit ControlRig armature Object.
        frames: list of BlendshapeFrame (time, weights dict).
        mapping: ARKit name -> list of (bone, transform_type, axis, divisor)
            from faceit_mapping.get_faceit_mapping().
        fps: target frame rate.
        frame_offset: frame number offset (playhead-based segment start).

    Returns:
        True if any keyframes were written.
    """
    import a2f_engine as _native

    _ensure_action_slot(rig)
    _ensure_writable_mode(rig)

    # Blender LOC_Y is evaluated in LOCAL_SPACE: location.y = +1.0 moves
    # the bone UP, -1.0 moves it DOWN (verified experimentally). Downward
    # channels (JawOpen/MouthLowerDown/MouthFrown) must therefore use a
    # NEGATIVE divisor so the bone moves DOWN. This restores any driver
    # expressions previously (incorrectly) flipped to positive. Idempotent.
    divisor_overrides = _restore_faceit_y_axis_directions(rig, mapping)

    # Precompute frame_num -> {bone_key: value} for all frames.
    # bone_key = (bone_name, transform_type, axis_index)
    # For location: value is the summed bone location
    # For rotation: value is the rotation in radians (eye look only)
    bone_frame_values: Dict[Tuple[str, str, int], List] = {}

    for frame_data in frames:
        frame_num = int(round(frame_data.time * fps)) + 1 + frame_offset

        # Adapt + aggregate the location-driven channels in the native engine
        # (a2f_engine.faceit_write_values): bilabial closure safety guard,
        # lip-inversion disable, mouth-corner stretch scale, per-channel caps,
        # MouthClose compensation, then (bone, axis) summing with the Y-axis
        # divisor overrides applied.
        try:
            loc_values = _native.faceit_write_values(
                frame_data.weights, mapping, divisor_overrides)
        except Exception as e:
            print(f"[Audio2Face Faceit] C++ engine unavailable ({e}); skipping frame {frame_num}")
            continue

        # Write location values to bone_frame_values
        for key, value in loc_values.items():
            bone_name, axis_str = key.split("|")
            bkey = (bone_name, 'LOCATION', int(axis_str))
            if bkey not in bone_frame_values:
                bone_frame_values[bkey] = []
            bone_frame_values[bkey].append((frame_num, value))

        # --- Eye look channels ---
        # Eye look in Faceit uses a DAMPED_TRACK constraint chain:
        #   c_eye_lookat.L (location) -> c_eye_lookat_target.L ->
        #   DAMPED_TRACK on c_lookat_mch.L -> ROT_X/ROT_Z -> driver
        #
        # The location-to-rotation mapping is non-linear and rig-dependent.
        # Audio2Face model output typically has very small EyeLook* values,
        # so eye look is skipped for now. The 48 non-eye-look channels
        # (brows, eyes blink/squint/wide, cheeks, nose, jaw, mouth, tongue)
        # provide the core facial animation.
        # TODO: Implement eye look via c_eye_lookat.L/R location with
        # calibrated scale factor if needed.

    if not bone_frame_values:
        print("[Audio2Face Faceit] No mappable ARKit weights -> bone transforms")
        return False

    # Write keyframes
    total_keyframes = 0
    total_bones = len(bone_frame_values)

    wm = bpy.context.window_manager
    wm.progress_begin(0, total_bones)

    for idx, ((bone_name, transform_type, axis), values) in enumerate(bone_frame_values.items()):
        n = len(values)
        if n == 0:
            wm.progress_update(idx + 1)
            continue

        pose_bone = rig.pose.bones.get(bone_name)
        if not pose_bone:
            wm.progress_update(idx + 1)
            continue

        if transform_type == 'LOCATION':
            data_path = 'location'
            for frame_num, value in values:
                pose_bone.location[axis] = value
                pose_bone.keyframe_insert(data_path=data_path, index=axis, frame=frame_num)
                total_keyframes += 1

        wm.progress_update(idx + 1)

    wm.progress_end()

    print(f"[Audio2Face Faceit] Wrote {total_keyframes} keyframes to "
          f"{total_bones} bone transforms on {rig.name}")
    return True

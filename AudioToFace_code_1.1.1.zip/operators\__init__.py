# Operators are imported directly by the addon root __init__.py
# (from .operators.generate import ..., etc.), so this file only
# needs to mark the directory as a Python package.

"""AudioToFace auto-update manager.

Checks the remote manifest for new versions of three independent parts:
    - code   : the addon's own functional Python modules (+ a2f_engine.dll)
    - model  : the AI model files (models/...)
    - deps   : the bundled Python dependencies (pylibs/...)

Each part is versioned separately and downloaded independently, so a small
code fix can be pushed without re-shipping the huge model or dependency sets.

Download uses only the Python standard library (urllib) so an update can
always run, even if the bundled third-party deps are broken.

Apply strategy:
    - model update : replaced in place (data files, not locked by a running
                     module). Safe to do while Blender is running.
    - code/deps update : must replace files that are loaded into the running
                     Blender process (Python modules, .pyd/.dll). This requires
                     a detach-and-relay pattern: we stage the new files, write
                     a short PowerShell script, launch it detached, then ask
                     Blender to quit. The script waits for Blender to exit,
                     backs up the old files, overwrites them, and restarts
                     Blender.

All user-facing strings are English keys resolved via i18n.t()/tr() by the
callers (UI/operators). This module keeps messages machine-readable.
"""

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
import urllib.request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# Remote manifest location. Replace OWNER/REPO with the actual GitHub repo.
# The manifest is committed to the repo so it gets a stable raw URL.
# Format of update_manifest.json at that URL:
#   {
#     "code":  {"version": "1.1.1", "url": "<zip>", "sha256": "<hex>"},
#     "model": {"version": "3.0",   "url": "<zip>", "sha256": "<hex>"},
#     "deps":  {"version": "1.19.2","url": "<zip>", "sha256": "<hex>"}
#   }
DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/yishengmoli/"
    "AudioToFace-Updates/main/update_manifest.json"
)

# HTTP timeout for all network operations (seconds).
_NET_TIMEOUT = 8

# Version of the currently shipped model (models/james_v3.0). Keep in sync
# with what the model folder actually contains. Used to detect local version.
_MODEL_VERSION = "3.0"

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------
_ADDON_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _user_config_dir():
    """Return the per-user config dir used for persistent update state.

    Lives outside the addon folder so it survives code updates (which replace
    the addon folder). Falls back to temp if Blender is unavailable.
    """
    try:
        import bpy
        cfg = bpy.utils.user_resource('CONFIG')
        if cfg:
            return cfg
    except Exception:
        pass
    return os.path.join(tempfile.gettempdir(), "AudioToFace")


def _state_path():
    return os.path.join(_user_config_dir(), "audio2face_update_state.json")


# ---------------------------------------------------------------------------
# Local state (what versions are currently installed)
# ---------------------------------------------------------------------------
def get_local_versions():
    """Return the currently installed versions of each part.

    Returns a dict with keys code/model/deps. Values are strings (version
    numbers) or "0" when a part is not installed locally.
    """
    # code version comes from bl_info (the addon's own version).
    code_ver = "0"
    try:
        import bpy
        code_ver = ".".join(str(v) for v in bpy.context.preferences.addons[
            __package__ if "__package__" in globals() else "AudioToFace"
        ].bl_info.get("version", (0, 0, 0)))
    except Exception:
        pass

    # model installed?
    model_ver = "0"
    model_dir = os.path.join(_ADDON_DIR, "models", "james_v3.0")
    if os.path.isdir(model_dir):
        model_ver = _MODEL_VERSION

    # deps installed? detect via onnxruntime if importable, else via folder.
    deps_ver = "0"
    try:
        import onnxruntime as ort
        deps_ver = getattr(ort, "__version__", "0")
    except Exception:
        # fall back to checking that a pylibs folder exists
        for d in ("pylibs", "pylibs_cp313"):
            if os.path.isdir(os.path.join(_ADDON_DIR, d)):
                deps_ver = "installed"
                break

    return {"code": code_ver, "model": model_ver, "deps": deps_ver}


# ---------------------------------------------------------------------------
# Remote manifest
# ---------------------------------------------------------------------------
def _fetch_url(url, timeout=_NET_TIMEOUT):
    """Fetch a URL and return its raw bytes. Raises on any failure."""
    req = urllib.request.Request(
        url, headers={"User-Agent": "AudioToFace-Updater/1.0"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def get_manifest():
    """Fetch and parse the remote update manifest.

    Returns a dict on success, or None if the manifest cannot be fetched or
    is malformed. Never raises.
    """
    url = _manifest_url()
    if not url:
        return None
    try:
        raw = _fetch_url(url)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            return None
        return data
    except Exception:
        return None


def _manifest_url():
    """Return the manifest URL from config, or the default."""
    cfg_path = os.path.join(_ADDON_DIR, "config", "updater_config.json")
    try:
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            u = (cfg or {}).get("manifest_url")
            if u:
                return u
    except Exception:
        pass
    return DEFAULT_MANIFEST_URL


# ---------------------------------------------------------------------------
# Update detection
# ---------------------------------------------------------------------------
def _version_gt(a, b):
    """Numeric dotted-version compare. '3.0' > '2.9'. Handles non-numeric too."""
    try:
        pa = [int(x) for x in str(a).split(".")]
        pb = [int(x) for x in str(b).split(".")]
    except ValueError:
        return str(a) != str(b)
    pa += [0] * (len(pb) - len(pa))
    pb += [0] * (len(pa) - len(pb))
    return pa > pb


def check_updates(manifest=None):
    """Return which parts have a newer version available.

    Args:
        manifest: optional pre-fetched manifest dict (to avoid double fetch).

    Returns:
        list of part names that have an update: subset of ['code','model','deps'].
    """
    if manifest is None:
        manifest = get_manifest()
    if not manifest:
        return []
    local = get_local_versions()
    updates = []
    for part in ("code", "model", "deps"):
        entry = manifest.get(part)
        if not entry or not isinstance(entry, dict):
            continue
        remote_ver = entry.get("version")
        if not remote_ver:
            continue
        if _version_gt(remote_ver, local.get(part, "0")):
            updates.append(part)
    return updates


# ---------------------------------------------------------------------------
# Download + verify
# ---------------------------------------------------------------------------
def _sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def download_part(part, entry, progress_cb=None):
    """Download one part's zip, verify its SHA256, return the local temp path.

    Args:
        part: 'code' | 'model' | 'deps' (for message/dest naming).
        entry: manifest entry dict with 'url' and 'sha256'.
        progress_cb: optional callable(downloaded_bytes, total_bytes).

    Returns:
        absolute path to the downloaded zip in a temp dir, or None on failure.
    """
    url = (entry or {}).get("url")
    if not url:
        return None
    try:
        tmpdir = tempfile.mkdtemp(prefix="a2f_upd_")
        tmp_path = os.path.join(tmpdir, f"{part}.zip")
        req = urllib.request.Request(
            url, headers={"User-Agent": "AudioToFace-Updater/1.0"}
        )
        with urllib.request.urlopen(req, timeout=_NET_TIMEOUT) as resp:
            total = int(resp.headers.get("Content-Length", 0) or 0)
            downloaded = 0
            with open(tmp_path, "wb") as f:
                while True:
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_cb:
                        progress_cb(downloaded, total)
        # verify checksum
        expected = (entry or {}).get("sha256")
        if expected:
            actual = _sha256_hex(open(tmp_path, "rb").read())
            if actual.lower() != str(expected).lower():
                shutil.rmtree(tmpdir, ignore_errors=True)
                return None
        return tmp_path
    except Exception:
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass
        return None


# ---------------------------------------------------------------------------
# Model update (in-place, safe while Blender is running)
# ---------------------------------------------------------------------------
def apply_model_update(zip_path):
    """Replace models/ with the contents of the model zip.

    Model data files are not locked by running modules, so this can complete
    while Blender is running. Returns (ok, message).
    """
    try:
        models_dir = os.path.join(_ADDON_DIR, "models")
        staging = os.path.join(tempfile.mkdtemp(prefix="a2f_model_"), "m")
        shutil.unpack_archive(zip_path, staging, "zip")

        # The zip root may be a single folder (e.g. james_v3.0/) or flat.
        # Walk to find the top-level content.
        items = os.listdir(staging)
        src = staging
        if len(items) == 1 and os.path.isdir(os.path.join(staging, items[0])):
            src = os.path.join(staging, items[0])

        # Backup + replace models dir.
        backups = os.path.join(
            _user_config_dir(), "audio2face_backup_models")
        if os.path.isdir(models_dir):
            shutil.rmtree(backups, ignore_errors=True)
            shutil.move(models_dir, backups)
        shutil.move(src, models_dir)
        shutil.rmtree(staging, ignore_errors=True)
        return True, "OK"
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Code / deps update (detach-and-relay via PowerShell)
# ---------------------------------------------------------------------------
# The PowerShell script does the actual swap. It:
#   1. shows a centered progress window ("Updating, please wait...")
#   2. waits for the Blender process to exit (so files are unlocked)
#   3. backs up the current addon folder
#   4. replaces it with the staged new files (advancing the progress bar)
#   5. closes the window and restarts Blender
#
# User-facing strings are placeholders ({TITLE}, {WAIT_TEXT}, ...) filled at
# launch time by _launch_relay() using i18n.t(), so the Python source stays
# pure English while the user sees localized text.
_PS_RELAY = r"""
param(
    [string]$BlenderExe,
    [string]$AddonDir,
    [string]$StagingDir,
    [string]$Pid
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = '{TITLE}'
$form.ClientSize = New-Object System.Drawing.Size(440, 120)
$form.FormBorderStyle = 'FixedDialog'
$form.ControlBox = $false
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = '{WAIT_TEXT}'
$label.Left = 20; $label.Top = 18; $label.Width = 400; $label.Height = 25
$form.Controls.Add($label)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Left = 20; $bar.Top = 55; $bar.Width = 400; $bar.Height = 25
$bar.Minimum = 0; $bar.Maximum = 100; $bar.Value = 5
$form.Controls.Add($bar)

$form.Show()
$form.Update()

$backup = ''
try {
    # 1/4 - wait for Blender to fully exit (unlocks loaded files).
    $bar.Value = 10; $label.Text = '{WAIT_TEXT}'; $form.Update()
    if ($Pid -and $Pid -ne '0') {
        $proc = Get-Process -Id $Pid -ErrorAction SilentlyContinue
        if ($proc) { $proc.WaitForExit(120000) | Out-Null }
    }
    Start-Sleep -Milliseconds 1500

    # 2/4 - backup only the files that will be overwritten.
    $bar.Value = 35; $label.Text = '{BACKUP_TEXT}'; $form.Update()
    $backup = Join-Path $env:TEMP ("a2f_backup_" + [guid]::NewGuid().ToString('N'))
    foreach ($item in Get-ChildItem -Path $StagingDir -Recurse -File) {
        $rel = $item.FullName.Substring($StagingDir.Length).TrimStart('\','/')
        $dest = Join-Path $AddonDir $rel
        if (Test-Path $dest) {
            $bpath = Join-Path $backup $rel
            $bdir = Split-Path $bpath
            if (-not (Test-Path $bdir)) { New-Item -ItemType Directory -Path $bdir -Force | Out-Null }
            Copy-Item -Path $dest -Destination $bpath -Force
        }
    }

    # 3/4 - merge the staged files into the addon folder (never wipes models/pylibs).
    $bar.Value = 65; $label.Text = '{INSTALL_TEXT}'; $form.Update()
    foreach ($item in Get-ChildItem -Path $StagingDir) {
        Copy-Item -Path $item.FullName -Destination $AddonDir -Recurse -Force
    }

    # 4/4 - done.
    $bar.Value = 100; $label.Text = '{DONE_TEXT}'; $form.Update()
    Start-Sleep -Milliseconds 900
}
catch {
    if ($backup -and (Test-Path $backup)) {
        foreach ($item in Get-ChildItem -Path $backup -Recurse -File) {
            $rel = $item.FullName.Substring($backup.Length).TrimStart('\','/')
            $dest = Join-Path $AddonDir $rel
            $ddir = Split-Path $dest
            if (-not (Test-Path $ddir)) { New-Item -ItemType Directory -Path $ddir -Force | Out-Null }
            Copy-Item -Path $item.FullName -Destination $dest -Force
        }
    }
    $label.Text = '{FAIL_TEXT}'
    $form.Update()
    Start-Sleep -Seconds 3
}
finally {
    $form.Close()
}

# Restart Blender.
if ($BlenderExe -and (Test-Path $BlenderExe)) {
    Start-Process -FilePath $BlenderExe
}
"""


def apply_code_or_deps_update(zip_path, part):
    """Stage new files and launch the detached relay that swaps + restarts.

    Returns (ok, message). On ok, Blender is about to quit and restart.
    """
    try:
        # Stage the new addon full content.
        staging = os.path.join(tempfile.mkdtemp(prefix="a2f_stage_"), "a2f")
        shutil.unpack_archive(zip_path, staging, "zip")
        items = os.listdir(staging)
        src = staging
        if len(items) == 1 and os.path.isdir(os.path.join(staging, items[0])):
            src = os.path.join(staging, items[0])

        # For a code/deps update the zip contains only the files that changed,
        # mirroring their paths under the addon root. The relay merges them over
        # the existing addon folder (so models/pylibs are never wiped) and then
        # restarts Blender.
        blender_exe = ""
        pid = "0"
        try:
            import bpy
            blender_exe = bpy.app.binary_path
            pid = str(os.getpid())
        except Exception:
            pass

        # Launch the detached relay: waits for Blender to exit, shows the
        # progress window, swaps the folder, then restarts Blender.
        return _launch_relay(blender_exe, _ADDON_DIR, src, pid)
    except Exception as e:
        return False, str(e)


def _launch_relay(blender_exe, addon_dir, staged_dir, pid):
    """Launch the PowerShell relay detached and ask Blender to quit.

    Writes the relay body to a temp .ps1 (filled with localized user-facing
    text via i18n.t, saved as UTF-8 with BOM so Windows PowerShell reads the
    CJK correctly), then spawns it detached so it survives Blender quitting.
    Returns (ok, message).
    """
    try:
        from ..utils.i18n import t as _t
        texts = {
            "TITLE": _t("AudioToFace Updater"),
            "WAIT_TEXT": _t("Waiting for Blender to close..."),
            "BACKUP_TEXT": _t("Backing up old files..."),
            "INSTALL_TEXT": _t("Installing new files..."),
            "DONE_TEXT": _t("Update complete, restarting Blender..."),
            "FAIL_TEXT": _t("Update failed. Please try again."),
        }
        relay_body = _PS_RELAY.format(**texts)

        relay_file = os.path.join(
            tempfile.gettempdir(), f"a2f_relay_{time.time_ns()}.ps1")
        # utf-8-sig writes a BOM so Windows PowerShell 5.1 decodes CJK text.
        with open(relay_file, "w", encoding="utf-8-sig") as f:
            f.write(relay_body)

        command = (
            "powershell.exe -NoProfile -ExecutionPolicy Bypass -File "
            f'"{relay_file}" -BlenderExe "{blender_exe}" '
            f'-AddonDir "{addon_dir}" -StagingDir "{staged_dir}" -Pid "{pid}"'
        )
        subprocess.Popen(
            command,
            shell=True,
            creationflags=(
                subprocess.CREATE_NEW_PROCESS_GROUP
                | subprocess.DETACHED_PROCESS
            ),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        return True, "OK"
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# High-level entry point used by the operator
# ---------------------------------------------------------------------------
def apply_update(part, entry):
    """Download + apply one part's update.

    Returns (ok, message, needs_restart).
    """
    zip_path = download_part(part, entry)
    if not zip_path:
        return False, "download_failed", False

    if part == "model":
        ok, msg = apply_model_update(zip_path)
        return ok, msg, False

    # code / deps -> detach-and-relay -> restart
    return apply_code_or_deps_update(zip_path, part)
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class BlendshapeFrameData:
    time: float
    weights: Dict[str, float]


@dataclass
class AnimationSegment:
    """Represents a single animation segment."""
    frames: List[BlendshapeFrameData]
    fps: int
    frame_offset: int  # Timeline offset of this animation segment


class AnimationCache:
    _instance = None
    _segments: List[AnimationSegment] = []  # Supports multiple animation segments
    _fps: int = 30
    _target_object: str = ""
    _target_type: str = ""
    _mapping: Dict[str, str] = {}
    # Phoneme-correction-related cache (for real-time toggling/strength
    # adjustment without re-running inference)
    _original_frames: List[Any] = []  # Raw inference results (before phoneme correction)
    _phoneme_data: Any = None          # Phoneme data (list of PhonemeSegment)
    _phoneme_frame_offset: int = 0     # frame_offset used during phoneme correction

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def store_frames(cls, frames: List[Any], fps: int, target_object: str, target_type: str, mapping: Dict[str, str], frame_offset: int = 0):
        """Store an animation segment, supporting multi-segment append."""
        # Convert new frame data to BlendshapeFrameData
        frame_data_list = []
        for frame in frames:
            frame_data = BlendshapeFrameData(
                time=frame.time,
                weights=dict(frame.weights)
            )
            frame_data_list.append(frame_data)

        # Create a new animation segment
        segment = AnimationSegment(
            frames=frame_data_list,
            fps=fps,
            frame_offset=frame_offset
        )

        # Check whether a segment with the same offset already exists; if so, replace it
        existing_idx = None
        for i, seg in enumerate(cls._segments):
            if seg.frame_offset == frame_offset:
                existing_idx = i
                break

        if existing_idx is not None:
            cls._segments[existing_idx] = segment
        else:
            cls._segments.append(segment)

        cls._fps = fps
        cls._target_object = target_object
        cls._target_type = target_type
        cls._mapping = mapping

    @classmethod
    def get_frames(cls) -> List[BlendshapeFrameData]:
        """Get all frames from all segments (backward compatible)."""
        all_frames = []
        for segment in cls._segments:
            all_frames.extend(segment.frames)
        return all_frames

    @classmethod
    def get_segment_by_offset(cls, frame_offset: int) -> Optional[AnimationSegment]:
        """Get the animation segment with the given frame_offset (for per-segment post-correction frame reads)."""
        for segment in cls._segments:
            if segment.frame_offset == frame_offset:
                return segment
        return None

    @classmethod
    def get_frame_count(cls) -> int:
        return sum(len(seg.frames) for seg in cls._segments)

    @classmethod
    def get_fps(cls) -> int:
        return cls._fps

    @classmethod
    def get_target_object(cls) -> str:
        return cls._target_object

    @classmethod
    def get_target_type(cls) -> str:
        return cls._target_type

    @classmethod
    def get_mapping(cls) -> Dict[str, str]:
        return cls._mapping

    @classmethod
    def has_data(cls) -> bool:
        return len(cls._segments) > 0 and any(len(seg.frames) > 0 for seg in cls._segments)

    @classmethod
    def clear(cls):
        cls._segments = []
        cls._fps = 30
        cls._target_object = ""
        cls._target_type = ""
        cls._mapping = {}
        cls._original_frames = []
        cls._phoneme_data = None
        cls._phoneme_frame_offset = 0

    # ============================================================
    # Phoneme correction: pre-save original inference results and phoneme data
    # ============================================================

    @classmethod
    def store_original_frames(cls, frames: List[Any], phoneme_data: Any = None, frame_offset: int = 0):
        """Save the raw model inference results (before phoneme correction) and phoneme data.

        Used to support:
        1. One-click disable of phoneme correction (read original results and rewrite)
        2. Real-time correction strength adjustment (read original results + phonemes and re-blend)
        """
        # Deep copy to prevent subsequent modifications from affecting the cache
        cls._original_frames = [
            {'time': f.time, 'weights': dict(f.weights)} if hasattr(f, 'time') else dict(f)
            for f in frames
        ]
        cls._phoneme_data = phoneme_data
        cls._phoneme_frame_offset = frame_offset

    @classmethod
    def get_original_frames(cls) -> List[Any]:
        """Get the original inference results (before phoneme correction)."""
        return cls._original_frames

    @classmethod
    def get_phoneme_data(cls) -> Any:
        """Get the phoneme data."""
        return cls._phoneme_data

    @classmethod
    def get_phoneme_frame_offset(cls) -> int:
        """Get the frame_offset used during phoneme correction."""
        return cls._phoneme_frame_offset

    @classmethod
    def has_original_data(cls) -> bool:
        """Whether original inference data exists (used to determine whether real-time toggling is possible)."""
        return len(cls._original_frames) > 0

    @classmethod
    def has_phoneme_data(cls) -> bool:
        """Whether phoneme data exists."""
        return cls._phoneme_data is not None and len(cls._phoneme_data) > 0

    @classmethod
    def get_frame_range(cls) -> tuple:
        if not cls._segments:
            return (1, 1)

        # Return the total range across all segments
        min_frame = float('inf')
        max_frame = 0
        for segment in cls._segments:
            if segment.frames:
                seg_start = segment.frame_offset + 1
                seg_end = segment.frame_offset + round(segment.frames[-1].time * segment.fps) + 1
                min_frame = min(min_frame, seg_start)
                max_frame = max(max_frame, seg_end)

        return (int(min_frame), int(max_frame))

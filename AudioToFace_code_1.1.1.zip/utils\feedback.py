"""Unified user-facing error/warning reporting.

Every operator failure should funnel through these helpers so the user sees
the problem in the page status box (status_message) AND in the Blender info
area (report), instead of only in the console. This turns silent failures
into visible, actionable messages.

The status box shows the localized (t) text; the info-area report uses the
English key (tr) to avoid garbled Chinese in Blender's GBK console.
"""

from ..utils.i18n import t, tr


def _compose_text(key, detail):
    text = t(key)
    if detail:
        text += f": {detail}"
    return text


def fail(self, props, key, detail="", level='ERROR'):
    """Report a failure and return an operator result.

    Args:
        self: the operator (or any object exposing .report()).
        props: the page PropertyGroup with a status_message field (may be None).
        key: English i18n key for the message.
        detail: optional free-form detail appended after the key.
        level: 'ERROR' or 'WARNING'.

    Returns:
        {'CANCELLED'} so callers can `return fail(...)`.
    """
    if props is not None:
        props.status_message = _compose_text(key, detail)
    if self is not None:
        self.report({level}, tr(key) + (f": {detail}" if detail else ""))
    return {'CANCELLED'}


def warn(self, props, key, detail=""):
    """Report a non-fatal warning (caller continues).

    Sets the status box and reports a WARNING in the info area, but does not
    change the operator's return value.
    """
    if props is not None:
        props.status_message = _compose_text(key, detail)
    if self is not None:
        self.report({'WARNING'}, tr(key) + (f": {detail}" if detail else ""))


def success(self, props, key, detail=""):
    """Set the status box to a success message (no info-area report)."""
    if props is not None:
        props.status_message = _compose_text(key, detail)
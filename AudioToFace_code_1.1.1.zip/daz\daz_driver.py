"""DAZ FACS driver: write ARKit weights to Object-level FACS properties as keyframes.

The DAZ FACS driver chain (set up by the import_daz addon) is:

    rig["<prop>"]                    (Object-level custom property, the slider input)
        ↓  driver on rig.data
    rig.data["<prop>(fin)"]          (Armature data property, the driven output)
        ↓  driver on mesh shape keys
    mesh shape_key["<prop>"].value   (final mesh deformation)

We write keyframes to the Object-level property (the slider input) using
rig.keyframe_insert('["<prop>"]'), which is exactly what the DAZ UI panel
does when the user moves a slider and presses the key button.

Action / slot handling (Blender 5.x layered animation):
On Blender 5.x an Action must be bound to the Object via a slot before any
fcurve is evaluated. We reuse any existing action/slot, and only create a
new action + slot when none exists. We never replace an existing action,
because that would discard the slot binding the DAZ addon relies on.
"""

import bpy
from typing import Dict, List

# Same compensation constant as core/animation.py for MouthClose.
MOUTH_CLOSE_OPEN_COMPENSATION = 0.35


# On DAZ G8.1, three lip-related ARKit channels physically deform the lips
# inward along the X-axis, producing the visible "向里兜" (lip inversion)
# artifact the user reported on bilabial sounds like "妹妹" (mèi mei):
#   - MouthRollLower / MouthRollUpper (AU28 Lip Roll) — true X-axis rotation
#   - MouthPressLeft / MouthPressRight (AU24 Lip Press) — on G8.1 the
#     blendshape direction tucks the lips inward instead of just thinning them
#   - MouthShrugLower (AU17 Chin Raiser) — on G8.1 the lower lip pushes up
#     AND inward, manifesting as inversion rather than a clean "pout"
#
# The NVIDIA model outputs non-zero values for these channels during
# bilabial closure (b/p/m) even though no Chinese phoneme requires them —
# this is a model generalization error. On G8.1 these channels ALL produce
# visible X-axis inward rotation, so all three are DISABLED (clamped to 0).
#
# Emotion templates (ANGER/SAD) intentionally do NOT use these channels
# (verified in emotion_templates.py: ANGER uses mouthFrown/browDown, SAD uses
# mouthFrown/browOuterUp — neither uses MouthPress/MouthShrug/MouthRoll),
# so disabling them here does not affect emotion expression on DAZ.
# Lip closure for b/p/m sounds is driven by MouthClose + JawOpen +
# MouthLowerDown, which are NOT capped.
def clamp_daz_prop_value(arkit_name: str, prop_name: str, value: float,
                          weights: dict = None,
                          allow_negative: bool = False) -> float:
    """Clamp a DAZ Object property value to prevent rig deformation artifacts.

    The actual cap set (which channels are disabled/capped on G8.1) lives in
    the native C++ engine. This is a thin wrapper so that both the generation
    path (apply_blendshapes_to_daz_rig) and the post-process path
    (daz_postprocess._apply_daz_postprocess) apply the SAME caps.
    """
    import a2f_engine as _native
    return _native.clamp_daz_prop(
        arkit_name or '', prop_name, float(value), bool(allow_negative))


def _ensure_action_slot(rig: bpy.types.Object):
    """Ensure rig.animation_data has an Action and a bound OBJECT slot.

    On Blender 4.x an Action is assigned directly to anim_data.action and
    fcurves evaluate immediately. On Blender 5.x the layered-animation model
    also requires an OBJECT slot bound to anim_data.action_slot; without it,
    rig.keyframe_insert() silently succeeds but the fcurve is never evaluated
    ("no error but no animation generated"). Although Blender often auto-binds
    a slot on the first keyframe_insert of a custom property, this behavior
    is not guaranteed across all 5.x minor versions, so we bind explicitly
    as a safety net (idempotent if already bound).

    We reuse any existing action rather than creating a new one, because
    replacing the action would discard the slot binding and any user-authored
    keyframes on the same action.
    """
    if not rig.animation_data:
        rig.animation_data_create()
    anim_data = rig.animation_data

    # Create an Action if none exists
    if anim_data.action is None:
        action = bpy.data.actions.new(name=f"{rig.name}_DAZ_FACS")
        anim_data.action = action
    else:
        action = anim_data.action

    # For Blender 4.4+ layered actions, ensure an OBJECT slot is explicitly
    # bound to anim_data.action_slot. Mirrors the logic in
    # core/animation.py:_get_fcurves_collection but for an Object (rig),
    # so id_type is 'OBJECT' instead of 'KEY'.
    if hasattr(action, 'is_action_layered') and action.is_action_layered:
        slot = anim_data.action_slot
        if slot is None:
            if action.slots:
                # Prefer a suitable slot if one exists
                try:
                    suitable = list(anim_data.action_suitable_slots)
                    if suitable:
                        slot = suitable[0]
                except Exception:
                    pass
                if slot is None:
                    slot = action.slots[0]
            else:
                # Create a new OBJECT slot named after the rig
                slot = action.slots.new(id_type='OBJECT', name=rig.name)
            anim_data.action_slot = slot

        # Ensure at least one layer + strip exists so the channelbag can be
        # located/created when keyframes are inserted.
        if not action.layers:
            action.layers.new("Layer")
        layer = action.layers[0]
        if not layer.strips:
            layer.strips.new(type='KEYFRAME')


def _get_action_fcurves(action) -> List:
    """Return the fcurves of an Action, handling both legacy and layered modes.

    Blender < 4.4: action.fcurves is the fcurve collection directly.
    Blender >= 4.4 (layered animation): fcurves live inside
        action.layers[0].strips[0].channelbag(slot).fcurves
    and action.fcurves exists but is empty (does not raise), so we must
    check is_action_layered explicitly rather than relying on a try/except
    on action.fcurves.
    """
    if action is None:
        return []
    # Layered mode (Blender >= 4.4) — check this FIRST because layered
    # actions also expose an (empty) action.fcurves attribute.
    if hasattr(action, 'is_action_layered') and action.is_action_layered:
        fcurves = []
        layers = getattr(action, 'layers', None)
        if layers:
            for layer in layers:
                for strip in layer.strips:
                    channelbags = getattr(strip, 'channelbags', None)
                    if not channelbags:
                        continue
                    for cb in channelbags:
                        cb_fcurves = getattr(cb, 'fcurves', None)
                        if cb_fcurves:
                            fcurves.extend(cb_fcurves)
        return fcurves
    # Legacy mode (Blender < 4.4, or a non-layered Action on 4.4+)
    try:
        return list(action.fcurves)
    except Exception:
        return []


def apply_blendshapes_to_daz_rig(
    rig: bpy.types.Object,
    frames: List,
    mapping: Dict[str, List],
    fps: int = 30,
    frame_offset: int = 0,
) -> bool:
    """Write ARKit weight frames to rig Object-level properties as keyframes.

    Uses rig.keyframe_insert() — the same mechanism the DAZ UI panel uses.
    Reuses the existing action on rig.animation_data to preserve the DAZ
    driver chain.

    Args:
        rig: DAZ armature Object.
        frames: list of BlendshapeFrame (time, weights dict).
        mapping: ARKit name -> list of (prop_name, scale) from
            daz_mapping.get_daz_mapping().
        fps: target frame rate.
        frame_offset: frame number offset (playhead-based segment start).

    Returns:
        True if any keyframes were written.
    """
    import a2f_engine as _native

    # Log mapping coverage for diagnostics.
    _mapped_arkit = sorted(mapping.keys())
    _key_arkit = ['JawOpen', 'MouthClose', 'MouthSmileLeft', 'MouthSmileRight',
                  'EyeBlinkLeft', 'EyeBlinkRight', 'BrowInnerUp']
    _missing_key = [n for n in _key_arkit if n not in _mapped_arkit]
    if _missing_key:
        print(f"[Audio2Face DAZ] WARNING: key expressions not mapped: {_missing_key}")
    print(f"[Audio2Face DAZ] Mapping coverage: {len(_mapped_arkit)} expressions, "
          f"JawOpen={'YES' if 'JawOpen' in _mapped_arkit else 'NO'}")

    # CRITICAL: Reuse any existing action and slot. On Blender 5.x we also
    # ensure the OBJECT slot is bound, otherwise written keyframes are
    # stored but never evaluated (the rig would not move).
    _ensure_action_slot(rig)
    anim_data = rig.animation_data
    action = anim_data.action

    # Precompute frame_num -> {prop: value} for all frames.
    # Apply MouthClose compensation in the weight domain.
    #
    # Bidirectional DAZ controllers (e.g. facs_ctrl_EyeLookSide-SideLeft)
    # encode two opposite ARKit directions on a single property via sign
    # (look in = +, look out = -). Several ARKit channels can therefore
    # target the SAME property, so we SUM their contributions per property
    # per frame and write ONE keyframe. Without aggregation, the separated
    # channels wrote competing keyframes on the same frame and the zero-
    # valued one overwrote the real signal (eye saccades were lost).
    prop_frame_values: Dict[str, List] = {}  # prop -> [(frame_num, value), ...]

    for frame_data in frames:
        # Cast to native int: round(numpy.float32 * int) returns numpy.int64,
        # which keyframe_insert(frame=...) may not accept on all Blender versions.
        frame_num = int(round(frame_data.time * fps)) + 1 + frame_offset

        # MouthClose compensation, bidirectional aggregation and per-prop
        # clamping run in the compiled C++ engine (a2f_engine.daz_write_values).
        # The mapping iteration order is preserved so the representative
        # arkit_name for the cap set matches the Python write path exactly.
        try:
            prop_values = _native.daz_write_values(frame_data.weights, mapping)
        except Exception as e:
            print(f"[Audio2Face DAZ] C++ engine unavailable ({e}); skipping frame {frame_num}")
            continue

        for prop, value in prop_values.items():
            if prop not in prop_frame_values:
                prop_frame_values[prop] = []
            prop_frame_values[prop].append((frame_num, value))

    if not prop_frame_values:
        print("[Audio2Face DAZ] No mappable ARKit weights -> properties")
        return False

    # Write keyframes using rig.keyframe_insert() — the same mechanism
    # the DAZ UI panel uses. This ensures the ensureExists drivers
    # correctly propagate values from Object to rig.data.
    total_keyframes = 0
    total_props = len(prop_frame_values)

    wm = bpy.context.window_manager
    wm.progress_begin(0, total_props)

    for idx, (prop, values) in enumerate(prop_frame_values.items()):
        n = len(values)
        if n == 0:
            wm.progress_update(idx + 1)
            continue

        # Use rig.keyframe_insert() — same as DAZ UI panel
        for frame_num, value in values:
            rig[prop] = value
            rig.keyframe_insert('["%s"]' % prop, frame=frame_num)
            total_keyframes += 1

        wm.progress_update(idx + 1)

    wm.progress_end()

    print(f"[Audio2Face DAZ] Wrote {total_keyframes} keyframes to "
          f"{total_props} Object properties on {rig.name}")
    return True


def _get_rig_object_fcurves(rig: bpy.types.Object) -> List:
    """Return the Object-level fcurves that drive facs_* custom properties.

    Used by the post-process (Apply Adjustments / Lip Repair) operators to
    read the keyframed values back from the rig's animation action without
    re-running inference. Only fcurves whose data_path matches
    '["facs_<name>"]' are returned; bone pose fcurves and non-FACS custom
    properties are excluded.

    Works on both Blender 4.x (legacy action.fcurves) and 5.x (layered
    action.layers[].strips[].channelbag().fcurves) via _get_action_fcurves.
    """
    if rig is None or not rig.animation_data or not rig.animation_data.action:
        return []
    out = []
    for fcu in _get_action_fcurves(rig.animation_data.action):
        dp = fcu.data_path or ''
        # Match '["facs_..."]' custom property paths (Object-level inputs).
        if dp.startswith('["facs_') and dp.endswith('"]'):
            out.append(fcu)
    return out




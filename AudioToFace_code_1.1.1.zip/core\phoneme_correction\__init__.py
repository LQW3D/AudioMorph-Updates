"""Phoneme correction module

Corrects the lip sync of NVIDIA Audio2Face model inference results based on Chinese phonemes.
The module is independent and can be removed entirely without affecting other functionality.

Workflow:
1. local_asr: local offline ASR (Sherpa-ONNX + Paraformer-zh-small), gets text + char-level timestamps
2. speech_analyzer: Chinese chars -> pinyin -> initial/final -> phoneme timeline
3. corrector: model inference results + phoneme presets -> fused correction
   (viseme lookup and correction math run in the compiled C++ engine)
"""

from .corrector import PhonemeCorrector

__all__ = ['PhonemeCorrector']

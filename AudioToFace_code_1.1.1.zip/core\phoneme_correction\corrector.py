"""Phoneme correction fusion algorithm

Fuses NVIDIA model inference results with phoneme presets, only correcting
mouth-related shape keys.

The core algorithm (viseme lookup, context-aware adjustment, time-based
interpolation, intelligent fusion, closed-lip reinforcement, delta smoothing)
runs entirely in the compiled C++ engine (a2f_engine.pyd) to protect the IP.
Python keeps only the scheduling/calling logic below.
"""

from typing import List, Dict

from .speech_analyzer import PhonemeSegment


class PhonemeCorrector:
    """Phoneme corrector"""

    def __init__(self):
        pass

    def correct_frames(
        self,
        model_frames: List[dict],
        fps: int,
        phonemes: List[PhonemeSegment],
        correction_strength: float = 0.4,
        frame_offset: int = 0,
    ) -> List[dict]:
        """Apply phoneme correction to model inference results.

        The correction math (viseme lookup, context-aware adjustment,
        interpolation, intelligent fusion, closed-lip reinforcement, delta
        smoothing) runs entirely in the compiled C++ engine (a2f_engine.pyd)
        to protect the IP. If the native engine is unavailable, the frames
        are returned unchanged rather than re-implementing the algorithm in
        Python.

        Args:
            model_frames: list of model inference frames, each
                {'time': float, 'weights': {name: value}}; weights keys are
                PascalCase ARKit names
            fps: frame rate
            phonemes: list of phoneme segments
            correction_strength: correction strength 0~1, 0=pure model,
                1=pure phoneme
            frame_offset: frame offset of this animation segment on the timeline

        Returns:
            Corrected frame list (same structure as model_frames)
        """
        if not model_frames or correction_strength <= 0.0:
            return [dict(f) for f in model_frames]

        # Convert phonemes to C++ format: {phoneme, type, start, end}.
        cpp_phonemes = []
        for ph in phonemes:
            if hasattr(ph, 'phoneme'):
                cpp_phonemes.append({
                    "phoneme": ph.phoneme,
                    "type": ph.phoneme_type,
                    "start": float(ph.start),
                    "end": float(ph.end),
                })
            else:
                cpp_phonemes.append({
                    "phoneme": ph.get('phoneme', ''),
                    "type": ph.get('phoneme_type', ''),
                    "start": float(ph.get('start', 0.0)),
                    "end": float(ph.get('end', 0.0)),
                })

        # Delegate to the native engine.
        try:
            import a2f_engine as _native
            return _native.correct_phoneme_frames(
                model_frames, int(fps), cpp_phonemes,
                float(correction_strength), int(frame_offset),
            )
        except Exception as e:
            print(f"[PhonemeCorrector] C++ engine unavailable ({e}); "
                  f"returning frames unchanged")
            return [dict(f) for f in model_frames]
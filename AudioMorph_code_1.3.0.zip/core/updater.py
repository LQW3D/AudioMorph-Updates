"""AudioMorph auto-update manager.

Checks the remote manifest for new versions of the functional code part:
    - code   : the addon's own functional Python modules (+ a2f_engine.dll)

Only the "code" part is offered for online update. The model and dependency
sets are shipped manually (too large / rarely changed), so they are not part
of the online manifest. The manifest is fetched from Aliyun OSS (primary) with
a GitHub fallback, and the code zip is downloaded the same way (OSS first,
GitHub if OSS is unreachable).

Download uses only the Python standard library (urllib) so an update can
always run, even if the bundled third-party deps are broken.

Apply strategy:
    - model update : replaced in place (data files, not locked by a running
                     module). Safe to do while Blender is running.
    - code/deps update : must replace files that are loaded into the running
                     Blender process (Python modules, .pyd/.dll). This requires
                     a detach-and-relay pattern: we stage the new files, write
                     a short PowerShell script, launch it detached, then ask
                     Blender to quit. The script waits for Blender to exit,
                     backs up the old files, overwrites them, and restarts
                     Blender.

All user-facing strings are English keys resolved via i18n.t()/tr() by the
callers (UI/operators). This module keeps messages machine-readable.
"""

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
import urllib.request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# Remote manifest locations, tried in order (primary first, fallback second):
#   1. Aliyun OSS (primary, fast for domestic users)
#   2. GitHub raw (fallback, for users who cannot reach OSS)
# The manifest is deployed to both places so each offers a stable URL.
# Format of update_manifest.json at those URLs:
#   {
#     "code":  {"version": "1.1.1", "url": "<zip>", "sha256": "<hex>"},
#     "model": {"version": "3.0",   "url": "<zip>", "sha256": "<hex>"},
#     "deps":  {"version": "1.19.2","url": "<zip>", "sha256": "<hex>"}
#   }
# NOTE: only "code" is offered for online update. Model and deps are shipped
# manually (too large / rarely changed), so their update buttons are hidden.
# Replace the OSS bucket host with the real one once the bucket is created.
DEFAULT_MANIFEST_URLS = [
    "https://atf-updates.oss-cn-beijing.aliyuncs.com/update_manifest.json",
    "https://raw.githubusercontent.com/LQW3D/"
    "AudioMorph-Updates/main/update_manifest.json",
]

# HTTP timeout for all network operations (seconds).
# Generous enough for large update zips on slow/volatile connections so a
# download is not aborted mid-transfer. The one-shot launch-time manifest
# fetch uses a shorter inline timeout to avoid blocking startup.
_NET_TIMEOUT = 30

# Short timeout for the (background) manifest fetch so an unreachable network
# fails fast and the "checking for updates" state resolves quickly instead of
# hanging for the full download timeout.
_MANIFEST_TIMEOUT = 8

# Version of the currently shipped model (models/james_v3.0). Keep in sync
# with what the model folder actually contains. Used to detect local version.
_MODEL_VERSION = "3.0"

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------
_ADDON_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _user_config_dir():
    """Return the per-user config dir used for persistent update state.

    Lives outside the addon folder so it survives code updates (which replace
    the addon folder). Falls back to temp if Blender is unavailable.
    """
    try:
        import bpy
        cfg = bpy.utils.user_resource('CONFIG')
        if cfg:
            return cfg
    except Exception:
        pass
    return os.path.join(tempfile.gettempdir(), "AudioMorph")


def _state_path():
    return os.path.join(_user_config_dir(), "audiomorph_update_state.json")


# ---------------------------------------------------------------------------
# Local state (what versions are currently installed)
# ---------------------------------------------------------------------------
def get_local_versions():
    """Return the currently installed versions of each part.

    Returns a dict with keys code/model/deps. Values are strings (version
    numbers) or "0" when a part is not installed locally.
    """
    # code version comes from bl_info (the addon's own version).
    #
    # NOTE: read bl_info from the loaded MODULE (sys.modules), not from
    # bpy.context.preferences.addons[...].bl_info. In Blender >= 4.2 the
    # Addon wrapper has no bl_info attribute, and __package__ in this module
    # is "AudioMorph.core" which is NOT the addons registry key ("AudioMorph"),
    # so the lookup always fails and code_ver silently falls back to "0",
    # making the updater think an update is always available.
    code_ver = "0"
    try:
        import sys
        mod = sys.modules.get("AudioMorph")
        if mod is None and __package__:
            mod = sys.modules.get(__package__.split(".")[0])
        if mod is not None:
            code_ver = ".".join(
                str(v) for v in mod.bl_info.get("version", (0, 0, 0)))
    except Exception:
        pass

    # model installed?
    model_ver = "0"
    model_dir = os.path.join(_ADDON_DIR, "models", "james_v3.0")
    if os.path.isdir(model_dir):
        model_ver = _MODEL_VERSION

    # deps installed? detect via onnxruntime if importable, else via folder.
    deps_ver = "0"
    try:
        import onnxruntime as ort
        deps_ver = getattr(ort, "__version__", "0")
    except Exception:
        # onnxruntime may be bundled in a pylibs dir that is not yet on
        # sys.path (e.g. not imported yet). Fall back to checking that a
        # pylibs folder exists. Return "0" (not a non-numeric string) so
        # _version_gt() never emits a spurious "always available" update:
        # a non-numeric local version like "installed" would make the
        # comparison fall through to str(a) != str(b) and always be True.
        for d in ("pylibs", "pylibs_cp313"):
            if os.path.isdir(os.path.join(_ADDON_DIR, d)):
                deps_ver = "0"
                break

    return {"code": code_ver, "model": model_ver, "deps": deps_ver}


# ---------------------------------------------------------------------------
# Remote manifest
# ---------------------------------------------------------------------------
def _fetch_url(url, timeout=_NET_TIMEOUT):
    """Fetch a URL and return its raw bytes. Raises on any failure."""
    req = urllib.request.Request(
        url, headers={"User-Agent": "AudioMorph-Updater/1.0"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def get_manifest():
    """Fetch and parse the remote update manifest.

    Tries each candidate manifest URL in order (primary -> fallback) until one
    returns a valid manifest. Returns a dict on success, or None if no source
    can be fetched or every source is malformed. Never raises.
    """
    for url in _manifest_urls():
        try:
            raw = _fetch_url(url, timeout=_MANIFEST_TIMEOUT)
            data = json.loads(raw.decode("utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return None


def _manifest_urls():
    """Return the ordered list of candidate manifest URLs.

    Prefers a value from config/updater_config.json if present (a single
    string is wrapped in a list), otherwise falls back to DEFAULT_MANIFEST_URLS.
    """
    cfg_path = os.path.join(_ADDON_DIR, "config", "updater_config.json")
    try:
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            u = (cfg or {}).get("manifest_urls")
            if isinstance(u, list) and u:
                return u
            one = (cfg or {}).get("manifest_url")
            if one:
                return [one]
    except Exception:
        pass
    return list(DEFAULT_MANIFEST_URLS)


# ---------------------------------------------------------------------------
# Update detection
# ---------------------------------------------------------------------------
def _version_gt(a, b):
    """Numeric dotted-version compare. '3.0' > '2.9'. Handles non-numeric too."""
    try:
        pa = [int(x) for x in str(a).split(".")]
        pb = [int(x) for x in str(b).split(".")]
    except ValueError:
        return str(a) != str(b)
    pa += [0] * (len(pb) - len(pa))
    pb += [0] * (len(pa) - len(pb))
    return pa > pb


def check_updates(manifest=None):
    """Return which parts have a newer version available.

    Args:
        manifest: optional pre-fetched manifest dict (to avoid double fetch).

    Returns:
        list of part names that have an update: subset of ['code','model','deps'].
    """
    if manifest is None:
        manifest = get_manifest()
    if not manifest:
        return []
    local = get_local_versions()
    updates = []
    for part in ("code", "model", "deps"):
        entry = manifest.get(part)
        if not entry or not isinstance(entry, dict):
            continue
        remote_ver = entry.get("version")
        if not remote_ver:
            continue
        if _version_gt(remote_ver, local.get(part, "0")):
            updates.append(part)
    return updates


# ---------------------------------------------------------------------------
# Download + verify
# ---------------------------------------------------------------------------
def _sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def download_part(part, entry, progress_cb=None):
    """Download one part's zip, verify its SHA256, return the local temp path.

    Args:
        part: 'code' | 'model' | 'deps' (for message/dest naming).
        entry: manifest entry dict. 'url' may be a single string or an
               ordered list (primary -> fallback); 'sha256' is the expected
               checksum, verified once the download succeeds.
        progress_cb: optional callable(downloaded_bytes, total_bytes).

    Returns:
        absolute path to the downloaded zip in a temp dir, or None on failure.
    """
    raw_urls = (entry or {}).get("url")
    if isinstance(raw_urls, str):
        urls = [raw_urls]
    elif isinstance(raw_urls, list) and raw_urls:
        urls = raw_urls
    else:
        return None
    expected = (entry or {}).get("sha256")
    for url in urls:
        tmpdir = tempfile.mkdtemp(prefix="a2f_upd_")
        tmp_path = os.path.join(tmpdir, f"{part}.zip")
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "AudioMorph-Updater/1.0"}
            )
            with urllib.request.urlopen(req, timeout=_NET_TIMEOUT) as resp:
                total = int(resp.headers.get("Content-Length", 0) or 0)
                downloaded = 0
                with open(tmp_path, "wb") as f:
                    while True:
                        chunk = resp.read(1 << 20)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_cb:
                            progress_cb(downloaded, total)
            # verify checksum
            if expected:
                actual = _sha256_hex(open(tmp_path, "rb").read())
                if actual.lower() != str(expected).lower():
                    shutil.rmtree(tmpdir, ignore_errors=True)
                    continue
            return tmp_path
        except Exception:
            shutil.rmtree(tmpdir, ignore_errors=True)
            continue
    return None


# ---------------------------------------------------------------------------
# Model update (in-place, safe while Blender is running)
# ---------------------------------------------------------------------------
def apply_model_update(zip_path):
    """Replace models/ with the contents of the model zip.

    Model data files are not locked by running modules, so this can complete
    while Blender is running. Returns (ok, message).
    """
    try:
        models_dir = os.path.join(_ADDON_DIR, "models")
        staging = os.path.join(tempfile.mkdtemp(prefix="a2f_model_"), "m")
        shutil.unpack_archive(zip_path, staging, "zip")

        # The zip root may be a single folder (e.g. james_v3.0/) or flat.
        # Walk to find the top-level content.
        items = os.listdir(staging)
        src = staging
        if len(items) == 1 and os.path.isdir(os.path.join(staging, items[0])):
            src = os.path.join(staging, items[0])

        # Backup + replace models dir.
        backups = os.path.join(
            _user_config_dir(), "audiomorph_backup_models")
        if os.path.isdir(models_dir):
            shutil.rmtree(backups, ignore_errors=True)
            shutil.move(models_dir, backups)
        shutil.move(src, models_dir)
        shutil.rmtree(staging, ignore_errors=True)
        return True, "OK"
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Code / deps update (detach-and-relay via PowerShell)
# ---------------------------------------------------------------------------
# The PowerShell script does the actual swap. It:
#   1. shows a centered dark progress window (localized text)
#   2. waits for the Blender process to exit (so files are unlocked)
#   3. backs up the current addon folder
#   4. replaces it with the staged new files (advancing the progress bar)
#   5. deletes the temporary download/staging folders
#   6. closes the window and restarts Blender
#
# User-facing strings are placeholders ({TITLE}, {WAIT_TEXT}, ...) filled at
# launch time by _launch_relay() using i18n.t() and .replace() (NOT .format(),
# because the script body is full of PowerShell { } braces). The Python source
# stays pure English while the user sees localized text.
_PS_RELAY = r"""
param(
    [string]$BlenderExe,
    [string]$AddonDir,
    [string]$StagingDir,
    [string]$BlenderPid,
    [string]$StagingBase,
    [string]$CleanDir
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Dark theme colors (match Blender's dark UI).
$bgColor = [System.Drawing.Color]::FromArgb(43, 43, 43)
$textColor = [System.Drawing.Color]::FromArgb(220, 220, 220)
$accentColor = [System.Drawing.Color]::FromArgb(0, 122, 204)

$form = New-Object System.Windows.Forms.Form
$form.Text = '{TITLE}'
$form.ClientSize = New-Object System.Drawing.Size(460, 140)
$form.FormBorderStyle = 'FixedDialog'
$form.ControlBox = $false
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true
$form.BackColor = $bgColor
$form.ForeColor = $textColor

$label = New-Object System.Windows.Forms.Label
$label.Text = '{WAIT_TEXT}'
$label.Left = 20; $label.Top = 22; $label.Width = 420; $label.Height = 26
$label.ForeColor = $textColor
$label.BackColor = $bgColor
$form.Controls.Add($label)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Left = 20; $bar.Top = 62; $bar.Width = 420; $bar.Height = 28
$bar.Minimum = 0; $bar.Maximum = 100; $bar.Value = 5
$bar.Style = 'Continuous'
$bar.ForeColor = $accentColor
$form.Controls.Add($bar)

$form.Show()
$form.Update()

$backup = ''
try {
    # 1/4 - wait for Blender to fully exit (unlocks loaded files).
    $bar.Value = 10; $label.Text = '{WAIT_TEXT}'; $form.Update()
    if ($BlenderPid -and $BlenderPid -ne '0') {
        $proc = Get-Process -Id $BlenderPid -ErrorAction SilentlyContinue
        if ($proc) { $proc.WaitForExit(120000) | Out-Null }
    }
    Start-Sleep -Milliseconds 1500

    # 2/4 - backup only the files that will be overwritten.
    $bar.Value = 35; $label.Text = '{BACKUP_TEXT}'; $form.Update()
    $backup = Join-Path $env:TEMP ("a2f_backup_" + [guid]::NewGuid().ToString('N'))
    foreach ($item in Get-ChildItem -Path $StagingDir -Recurse -File) {
        $rel = $item.FullName.Substring($StagingDir.Length).TrimStart('\','/')
        $dest = Join-Path $AddonDir $rel
        if (Test-Path $dest) {
            $bpath = Join-Path $backup $rel
            $bdir = Split-Path $bpath
            if (-not (Test-Path $bdir)) { New-Item -ItemType Directory -Path $bdir -Force | Out-Null }
            Copy-Item -Path $dest -Destination $bpath -Force
        }
    }

    # 3/4 - merge the staged files into the addon folder (never wipes models/pylibs).
    $bar.Value = 65; $label.Text = '{INSTALL_TEXT}'; $form.Update()
    foreach ($item in Get-ChildItem -Path $StagingDir) {
        Copy-Item -Path $item.FullName -Destination $AddonDir -Recurse -Force
    }

    # 4/4 - done, then clean up the temporary download/staging folders.
    $bar.Value = 100; $label.Text = '{DONE_TEXT}'; $form.Update()
    Start-Sleep -Milliseconds 900
    if ($CleanDir -and (Test-Path $CleanDir)) {
        Remove-Item -Path $CleanDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($StagingBase -and (Test-Path $StagingBase)) {
        Remove-Item -Path $StagingBase -Recurse -Force -ErrorAction SilentlyContinue
    }
}
catch {
    if ($backup -and (Test-Path $backup)) {
        foreach ($item in Get-ChildItem -Path $backup -Recurse -File) {
            $rel = $item.FullName.Substring($backup.Length).TrimStart('\','/')
            $dest = Join-Path $AddonDir $rel
            $ddir = Split-Path $dest
            if (-not (Test-Path $ddir)) { New-Item -ItemType Directory -Path $ddir -Force | Out-Null }
            Copy-Item -Path $item.FullName -Destination $dest -Force
        }
    }
    $label.Text = '{FAIL_TEXT}'
    $form.Update()
    Start-Sleep -Seconds 3
}
finally {
    $form.Close()
}

# Restart Blender.
if ($BlenderExe -and (Test-Path $BlenderExe)) {
    Start-Process -FilePath $BlenderExe
}
"""


def apply_code_or_deps_update(zip_path, part):
    """Stage new files and launch the detached relay that swaps + restarts.

    Returns (ok, message). On ok, Blender is about to quit and restart.
    """
    try:
        # Stage the new addon full content.
        staging = os.path.join(tempfile.mkdtemp(prefix="a2f_stage_"), "a2f")
        shutil.unpack_archive(zip_path, staging, "zip")
        items = os.listdir(staging)
        src = staging
        if len(items) == 1 and os.path.isdir(os.path.join(staging, items[0])):
            src = os.path.join(staging, items[0])

        # For a code/deps update the zip contains only the files that changed,
        # mirroring their paths under the addon root. The relay merges them over
        # the existing addon folder (so models/pylibs are never wiped) and then
        # restarts Blender.
        blender_exe = ""
        pid = "0"
        try:
            import bpy
            blender_exe = bpy.app.binary_path
            pid = str(os.getpid())
        except Exception:
            pass

        # Launch the detached relay: waits for Blender to exit, shows the
        # progress window, swaps the folder, then restarts Blender.
        # StagingBase/CleanDir let the relay delete the temporary download
        # folder and the unpacked staging folder once the install succeeds.
        return _launch_relay(
            blender_exe, _ADDON_DIR, src, pid,
            staging_base=os.path.dirname(staging),
            clean_dir=os.path.dirname(zip_path))
    except Exception as e:
        return False, str(e)


def _launch_relay(blender_exe, addon_dir, staged_dir, pid,
                  staging_base="", clean_dir=""):
    """Launch the PowerShell relay detached and ask Blender to quit.

    Writes the relay body to a temp .ps1 (filled with localized user-facing
    text via i18n.t, saved as UTF-8 with BOM so Windows PowerShell reads the
    CJK correctly), then spawns it detached so it survives Blender quitting.
    Returns (ok, message).
    """
    try:
        from ..utils.i18n import t as _t
        texts = {
            "TITLE": _t("AudioMorph Updater"),
            "WAIT_TEXT": _t("Waiting for Blender to close..."),
            "BACKUP_TEXT": _t("Backing up old files..."),
            "INSTALL_TEXT": _t("Installing new files..."),
            "DONE_TEXT": _t("Update complete, restarting Blender..."),
            "FAIL_TEXT": _t("Update failed. Please try again."),
        }
        # Use .replace() (NOT .format()) for placeholder substitution: the
        # relay body is full of PowerShell's own { } block braces, which would
        # make str.format() raise "unexpected '{'". .replace() is safe.
        relay_body = _PS_RELAY
        for key, val in texts.items():
            relay_body = relay_body.replace("{" + key + "}", val)

        relay_file = os.path.join(
            tempfile.gettempdir(), f"a2f_relay_{time.time_ns()}.ps1")
        # utf-8-sig writes a BOM so Windows PowerShell 5.1 decodes CJK text.
        with open(relay_file, "w", encoding="utf-8-sig") as f:
            f.write(relay_body)

        command = (
            "powershell.exe -NoProfile -ExecutionPolicy Bypass -File "
            f'"{relay_file}" -BlenderExe "{blender_exe}" '
            f'-AddonDir "{addon_dir}" -StagingDir "{staged_dir}" '
            f'-BlenderPid "{pid}" '
            f'-StagingBase "{staging_base}" -CleanDir "{clean_dir}"'
        )
        subprocess.Popen(
            command,
            shell=True,
            creationflags=(
                subprocess.CREATE_NEW_PROCESS_GROUP
                | subprocess.CREATE_NO_WINDOW
            ),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        return True, "OK"
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# High-level entry point used by the operator
# ---------------------------------------------------------------------------
def apply_update(part, entry):
    """Download + apply one part's update.

    Returns (ok, message, needs_restart).
    """
    zip_path = download_part(part, entry)
    if not zip_path:
        return False, "download_failed", False

    if part == "model":
        ok, msg = apply_model_update(zip_path)
        return ok, msg, False

    # code / deps -> detach-and-relay -> restart
    return apply_code_or_deps_update(zip_path, part)
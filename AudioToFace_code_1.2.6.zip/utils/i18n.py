"""Internationalization support for Audio2Face plugin.

The plugin follows Blender's UI language (bpy.app.translations.locale).
No separate language setting is needed; switching Blender's language
automatically updates all plugin UI text.

Usage:
    from .i18n import t
    label = t("Audio Input")            # auto-detect from Blender's UI language
    label = t("Audio Input", "zh_CN")   # explicit language override

Adding a new language:
    1. Add an entry to TRANSLATIONS with the language code as key
    2. Translate each English key into the target language
    3. Keys not translated will fall back to English (the key itself)
"""

import bpy

# Module-level cache of Blender's UI language at import time.
# Used as a fallback for class-level t() calls if the dynamic lookup
# in current_lang() fails (e.g. bpy.app.translations not yet initialized).
# The plugin follows Blender's UI language; no separate language setting.


# Map Blender's locale codes to our translation table keys.
# Blender uses 'zh_HANS' for Simplified Chinese, but our TRANSLATIONS
# table uses 'zh_CN'. Normalize so lookups succeed.
_LOCALE_NORMALIZE = {
    'zh_HANS': 'zh_CN',   # Blender Simplified Chinese
    'zh_HANT': 'zh_TW',   # Blender Traditional Chinese (reserved)
    'zh': 'zh_CN',
}


# During a language-switch reload, this is set to the target language
# detected by the timer. It forces current_lang() to return the correct
# language even if bpy.app.translations.locale hasn't fully updated yet
# (race condition between Blender's locale refresh and module reload).
# Set by __init__.reload_and_re_register(); cleared after reload completes.
_RELOAD_LANG_OVERRIDE = None


def _detect_blender_lang():
    """Detect Blender's effective UI language.

    Uses bpy.app.translations.locale which respects the user's language
    preference including the 'Automatic' (system default) setting.
    Returns None if detection fails.

    The returned code is normalized to match TRANSLATIONS keys
    (e.g. Blender's 'zh_HANS' -> 'zh_CN').
    """
    raw = None
    try:
        raw = bpy.app.translations.locale
    except Exception:
        pass
    if not raw:
        try:
            bl_lang = bpy.context.preferences.view.language
            if bl_lang and bl_lang != 'DEFAULT':
                raw = bl_lang
        except Exception:
            pass
    if not raw:
        return None
    # Normalize: try exact map first, then prefix match (e.g. 'zh_HANS.UTF-8')
    if raw in _LOCALE_NORMALIZE:
        return _LOCALE_NORMALIZE[raw]
    lower = raw.split('.')[0].split('_')[0].lower()
    if lower == 'zh':
        # Default any Chinese variant to Simplified for our table
        return 'zh_CN'
    return raw


# Cache language at import time for class-level t() calls (bl_label,
# bl_description, name=, description=, EnumProperty items) which are
# evaluated once at class definition time and cannot call current_lang()
# dynamically. Updated via module reload when Blender's language changes.
# Default to 'en_US' (English) when detection fails, since English is
# Blender's default language and the key strings themselves are English.
_CURRENT_LANG = _detect_blender_lang() or 'en_US'


TRANSLATIONS = {
    'zh_CN': {
        # --- Author / Maintainer ---

        # --- Activation Page ---
        "Activation Required": "需要激活",
        "This plugin requires activation.": "本插件需要激活后使用。",
        "Please contact the developer to purchase.": "请联系开发者购买。",
        "Your Device ID:": "你的设备码：",
        "Copy Device ID": "复制设备码",
        "Enter Activation Key:": "输入激活码：",
        "Activate": "激活",

        # --- Main Panel ---
        "Audio2Face Audio-Driven Facial Animation": "Audio2Face 音频驱动面部动画",
        "Engine Error": "核心引擎错误",
        "The core engine failed to load. Animation will be unavailable or incorrect.": "核心引擎加载失败，动画将无法正常生成或结果不正确。",
        "Audio Input": "音频输入",
        "Import Audio to Timeline": "导入音频到时间轴",
        "Audio File": "音频文件",
        "Generate facial animation from audio": "从音频生成面部动画",
        "Generate Animation": "生成动画",

        # --- Binding Panel ---
        "Tongue": "舌头",
        "Set Page": "设置页面",

        # --- Binding Page Extension ---

        # --- Settings Panel ---
        "Settings": "设置",
        "Basic Settings": "基础设置",
        "Frame Rate": "帧率",
        "Upper Face": "上脸部",
        "Lower Face": "下脸部",
        "Advanced Settings": "高级设置",
        "Global Adjustment": "整体调整",
        "Input Strength": "输入强度",
        "Skin Strength": "皮肤强度",
        "Smoothing": "平滑度",
        "Mouth Adjustment": "口型调整",
        "Jaw Open": "张嘴",
        "Mouth Close": "闭嘴",
        "Lip Sync Delay": "口型延迟",
        "Left/Right": "左右",
        "Lip Offset": "唇偏移",
        "Tongue": "舌头",
        "Lower Lip Adjustment": "下嘴唇调整（兜嘴问题）",
        "Lower Lip Roll": "下唇卷起",
        "Lower Lip Shrug": "下唇耸起",
        "Lower Lip Down": "下唇下压",
        "Upper Lip Adjustment": "上嘴唇调整（咬唇问题）",
        "Upper Lip Roll": "上唇卷起",
        "Upper Lip Shrug": "上唇耸起",
        "Eye Adjustment": "眼睛调整",
        "Blink": "眨眼",
        "Blink Interval": "眨眼间隔",
        "Eye Movement": "眼球运动",
        "Saccade": "眼跳微动",
        "Save as Default": "设为默认参数",
        "Save current page parameters as defaults (Animation or DAZ)": "将当前页面参数保存为默认（动画或 DAZ）",
        "DAZ defaults saved, restart Blender to apply": "DAZ 页面默认参数已保存，重启 Blender 后生效",
        "Failed to save defaults": "保存默认参数失败",

        # --- Preset template management ---
        "Parameter Preset": "参数模板",
        "Preset": "模板",
        "(No Preset)": "（无模板）",
        "No preset template selected": "未选择参数模板",
        "Select a parameter preset template to load": "选择要加载的参数模板",
        "Load preset": "加载模板",
        "Save as Preset": "另存为模板",
        "Save current parameters as a named preset template": "将当前参数另存为命名的模板",
        "Preset Name": "模板名称",
        "Name for the new preset template (used as the filename)": "新模板的名称（用作文件名）",
        "Preset name is empty or invalid": "模板名称为空或无效",
        "Failed to save preset": "保存模板失败",
        "Preset saved": "模板已保存",
        "Load Preset": "加载模板",
        "Apply the selected preset template to the current page": "将选中的模板应用到当前页面",
        "No preset selected": "未选择模板",
        "Preset file not found": "模板文件未找到",
        "Failed to load preset": "加载模板失败",
        "Preset loaded": "模板已加载",
        "Delete Preset": "删除模板",
        "Delete the selected preset template file": "删除选中的模板文件",
        "Failed to delete preset": "删除模板失败",
        "Preset deleted": "模板已删除",

        # --- Post-process Panel ---
        "Post Processing": "后期处理调整",
        "Please generate animation first": "请先生成动画",
        "Animation Info": "动画信息",
        "Total Frames": "总帧数",
        "Frame Range": "帧范围选择",
        "Start": "起始",
        "End": "结束",
        "Post-process Parameters": "后处理参数",
        "Post Smoothing": "平滑度",
        "Post Strength": "力度",
        "Mouth Scale": "口型幅度",
        "Pucker Scale": "撅嘴幅度",
        "Mouth Stretch Scale": "嘴角拉伸幅度",
        "Stretch Scale": "拉伸幅度",
        "Mouth amplitude scale (post-process). 1.0=original, <1.0=subdued for calm dialogue, >1.0=exaggerated for excited dialogue. Unlike smoothing, this only scales peak amplitude and preserves articulation crispness.": "口型幅度缩放（后处理）。1.0=原始，<1.0=适合平缓对白（降低张嘴幅度），>1.0=适合激动对白（增大张嘴幅度）。与平滑不同，此参数只缩放峰值幅度，不模糊口型特征。",
        "Pucker amplitude scale (post-process). Scales MouthPucker + MouthFunnel. 1.0=original, <1.0=reduces forward lip protrusion on rounded vowels (o/u), >1.0=more pucker. Only scales peak amplitude, preserves articulation crispness.": "撅嘴幅度缩放（后处理）。缩放 MouthPucker + MouthFunnel。1.0=原始，<1.0=减弱圆唇音（o/u）的嘴唇前突感，>1.0=更撅。只缩放峰值幅度，不模糊口型特征。",
        "Mouth stretch scale (post-process). Scales MouthStretch Left/Right (horizontal mouth width) and MouthSmile Left/Right (corner lift). 1.0=original, <1.0=narrower mouth, >1.0=wider mouth. Only scales peak amplitude, preserves articulation crispness.": "嘴角拉伸幅度缩放（后处理）。缩放 MouthStretch 左/右（嘴部横向宽度）与 MouthSmile 左/右（嘴角上提）。1.0=原始，<1.0=嘴变窄，>1.0=嘴变宽。只缩放峰值幅度，不模糊口型特征。",
        "Lip Closure Fine-tuning (frame range only)": "闭嘴动作微调（仅作用于帧范围）",
        "Lip Closure (linked)": "闭嘴联动",
        "Show Advanced": "展开高级选项",
        "Hide Advanced": "收起高级选项",
        "Mouth Close": "闭嘴强度",
        "Jaw Open": "下巴开合",
        "Lower Lip": "下唇开合",
        "Repair Lip Closure": "口型修复",
        "Auto-detect and fix bilabial closure issues (b/p/m sounds)": "一键自动检测并修复闭口音（b/p/m）闭合问题",
        "No animation data, please generate first": "没有动画数据，请先生成动画",
        "No phoneme data, enable phoneme correction and regenerate": "没有音素数据，请开启音素修正后重新生成动画",
        "No bilabial sounds (b/p/m) detected, nothing to repair": "未检测到闭口音（b/p/m），无需修复",
        "No closure peaks detected, nothing to repair": "未检测到闭口峰值，无需修复",
        "Repaired bilabial closure peaks": "已修复闭口音峰值数量",
        "Adjust parameters and click Apply": "调整参数后点击应用",
        "Apply Adjustments": "应用调整",

        # --- Operator Labels ---
        "Import Audio": "导入音频",
        "Import selected audio file to VSE timeline at the current playhead position": "将已选择的音频文件按时间轴指针位置导入到视频序列编辑器",
        "Apply Adjustments to Animation Curves": "应用调整",
        "Set Frame Range": "设置帧范围",
        "Set the frame range to the full animation range": "将帧范围设置为整个动画范围",
        "Save Defaults": "设为默认参数",

        # --- Operator Messages ---
        "Please select an audio file first": "请先选择音频文件",
        "Audio file does not exist": "音频文件不存在",
        "Imported audio to VSE at frame": "音频已导入到VSE第",
        "Audio import failed": "导入音频失败",
        "Sequence editor API not available": "序列编辑器 API 不可用",
        "Sequence editor returned empty strip": "序列编辑器返回空的音频条",

        "No animation data, please generate first": "没有动画数据，请先生成动画",
        "Start frame cannot be greater than end frame": "起始帧不能大于结束帧",
        "Applied adjustments to frames": "已应用调整到帧",

        "No animation data": "没有动画数据",
        "Frame range set to": "帧范围已设置为",

        # --- Missing keys ---

        # --- Operator bl_label ---

        # --- Property names ---

        # --- Property descriptions ---

        # --- Operator messages ---
        "Selected:": "已选择：",
        "No object selected": "未选择对象",
        "No audio file loaded": "未加载音频文件",
        "Audio file not found:": "音频文件未找到：",
        "Generating animation...": "正在生成动画...",
        "Failed to generate animation": "生成动画失败",
        "License required": "需要激活许可",
        "Animation generated successfully": "动画生成成功",
        "starts at frame": "起始帧为",

        # --- Target object / mode-aware UI ---
        "Armature": "骨架",
        "Selected object is not an armature": "选中对象不是骨架",

        # --- Additional UI labels ---

        "Preset Name": "预设名称",

        # --- panel.py EnumProperty items 补充 ---

        # --- properties.py property names and descriptions ---
        "Frame": "帧",
        "Neutral": "中性",
        "Page": "页面",
        "Audio2Face workflow page": "Audio2Face 工作流页面",
        "Audio file to process": "待处理的音频文件",
        "Upper Face Strength": "上脸部强度",
        "Strength for upper-face motion": "上脸部动作的强度",
        "Lower Face Strength": "下脸部强度",
        "Strength for mouth and lower-face motion": "嘴部和下脸部动作的强度",
        "Upper Face Smoothing": "上脸部平滑度",
        "Temporal smoothing for upper-face motion": "上脸部动作的时间平滑",
        "Lower Face Smoothing": "下脸部平滑度",
        "Temporal smoothing for lower-face motion": "下脸部动作的时间平滑",
        "Shift generated mouth motion in time. Positive values delay the animation.": "在时间上偏移生成的嘴部动作。正值会延迟动画。",
        "Strength for skin deformation output": "皮肤变形输出的强度",
        "Jaw Open Multiplier": "张嘴倍数",
        "Multiplier for jaw-open motion": "张嘴动作的倍数",
        "Mouth Close Multiplier": "闭嘴倍数",
        "Multiplier for mouth-close motion": "闭嘴动作的倍数",
        "Jaw Left/Right Multiplier": "下颌左右倍数",
        "Multiplier for jaw and mouth left-right motion": "下颌和嘴部左右动作的倍数",
        "Lower Lip Roll Multiplier": "下唇卷起倍数",
        "Multiplier for lower-lip roll motion": "下唇卷起动作的倍数",
        "Upper Lip Roll Multiplier": "上唇卷起倍数",
        "Multiplier for upper-lip roll motion": "上唇卷起动作的倍数",
        "Lower Lip Shrug Multiplier": "下唇耸起倍数",
        "Multiplier for lower-lip shrug motion": "下唇耸起动作的倍数",
        "Upper Lip Shrug Multiplier": "上唇耸起倍数",
        "Multiplier for upper-lip shrug motion": "上唇耸起动作的倍数",
        "Upper Lip Up Multiplier": "上唇上抬倍数",
        "Multiplier for upper-lip raise motion (MouthUpperUpLeft/Right). Negative values push the upper lip down to counteract excessive lift during speech.": "上唇上抬动作的倍数（控制 MouthUpperUpLeft/Right）。负值可向下压上唇，用于抵消说话时上唇过度上抬的问题。",
        "Upper Lip Up": "上唇上抬",
        "Lower Lip Down Multiplier": "下唇下压倍数",
        "Multiplier for lower-lip down motion": "下唇下压动作的倍数",
        "Blink Strength": "眨眼强度",
        "Strength for blink output generated by the SDK": "SDK 生成的眨眼输出强度",
        "Eye Movement Strength": "眼球运动强度",
        "Strength for generated eye movement": "生成眼球运动的强度",
        "Saccade Strength": "眼跳微动强度",
        "Strength for small natural eye movements": "微小自然眼动的强度",
        "Target interval between automatic blinks, in seconds": "自动眨眼的目标间隔，单位秒",
        "Lip Open Offset": "唇部张开偏移",
        "Global offset for mouth opening": "嘴部张开的全局偏移",
        "Global input animation strength": "全局输入动画强度",
        "Tongue Strength": "舌头强度",
        "Strength for tongue motion": "舌头动作的强度",
        "Show Advanced Settings": "显示高级设置",
        "Show advanced controls": "显示高级控制",
        "Status Message": "状态信息",
        "Current operation status": "当前操作状态",
        "Processing": "处理中",
        "Has Animation Data": "有动画数据",
        "Animation Frame Count": "动画帧数",
        "Start Frame": "起始帧",
        "Animation start frame": "动画起始帧",
        "End Frame": "结束帧",
        "Animation end frame": "动画结束帧",
        "Post-process smoothing amount": "后处理平滑量",
        "Post-process strength multiplier": "后处理强度倍数",

        # --- Phoneme Correction ---
        "Phoneme Correction": "音素修正",
        "Use Chinese phoneme analysis to correct mouth shapes from model inference": "用中文音素分析修正模型推理的口型",
        "Enable Phoneme Correction": "启用音素修正",
        "Correction Strength": "修正强度",
        "Phoneme Correction Active": "音素修正已应用",
        "Whether phoneme correction is currently applied (toggleable without re-generating)": "音素修正当前是否已应用（可切换而无需重新生成）",
        "Toggle Phoneme Correction": "切换音素修正",
        "Turn phoneme correction on/off without re-generating animation": "无需重新生成动画即可开关音素修正",
        "Apply Correction Strength": "应用修正强度",
        "Re-fuse model inference with phonemes using new strength": "用新强度重新融合模型推理结果与音素",
        "Phoneme correction skipped: ASR failed": "音素修正已跳过：ASR识别失败",
        "Phoneme correction applied": "音素修正已应用",
        "Phoneme correction failed": "音素修正失败",
        "Phoneme correction turned off": "音素修正已关闭",
        "Phoneme correction turned on": "音素修正已开启",
        "ASR returned no results": "ASR未返回任何结果",
        "ASR failed": "ASR识别失败",
        "ASR Recognized Text": "ASR识别文本",
        "ASR Text (editable)": "ASR文本（可编辑）",
        "Edit ASR Text": "编辑ASR文本",
        "Open multi-line editor for ASR recognized text. Supports auto-wrap and resizing.": "打开ASR识别文本的多行编辑器。支持自动换行和调整大小。",
        "ASR text updated. Click Apply Edited Text to regenerate phonemes.": "ASR文本已更新。点击应用编辑文本以重新生成音素。",
        "Apply Edited Text": "应用编辑文本",
        "Regenerate phonemes from edited ASR text and re-fuse animation. No ASR/SDK re-run needed.": "从编辑后的ASR文本重新生成音素并重新融合动画。无需重跑ASR/SDK。",
        "Failed to regenerate phonemes from edited text. Make sure ASR text is not empty.": "从编辑文本重新生成音素失败。请确保ASR文本不为空。",
        "Phonemes regenerated from edited text": "已从编辑文本重新生成音素",
        "ASR recognized text. Edit to fix misrecognitions (e.g. song lyrics), then click Apply Edited Text to regenerate phonemes. No re-run of ASR/SDK needed.": "ASR识别的文本。编辑以修正识别错误（如歌词），然后点击\"应用编辑文本\"重新生成音素。无需重跑ASR/SDK。",
        # --- Force Align Text (for fixing dropped characters in fast songs) ---
        "Force Align Text": "强制对齐文本",
        "Align edited text to audio via CTC forced alignment. Use when ASR dropped characters (fast songs) and you added/removed chars to fix it.": "通过CTC强制对齐将编辑后的文本对齐到音频。适用于ASR丢字的情况（快歌），用户已增删字符修正文本时使用。",
        # --- Timeline Markers (character-level timestamp visualization/editing) ---
        "Add End Marker": "添加字尾标记",
        "Add an end marker for the selected start marker at the current frame. Creates a silence gap after this character.": "在当前帧为选中的字首标记添加字尾标记。该字之后将产生静音间隙（嘴部归于默认闭合状态）。",
        "No A2F start marker selected in timeline": "时间线中未选中A2F字首标记",
        "Selected marker not found": "未找到选中的标记",
        "Current frame must be after the start marker frame": "当前帧必须在字首标记帧之后",
        "Current frame must be within the timeline frame range": "当前帧必须在时间线帧范围内",
        "Failed to add end marker": "添加字尾标记失败",
        "End marker added at frame %d": "已在第%d帧添加字尾标记",
        "Fix Timestamps from Markers": "修正时间戳",
        "Read adjusted timeline markers, rebuild character timestamps, regenerate phonemes and re-fuse animation": "读取调整后的时间线标记，重建字符时间戳，重新生成音素并重新融合动画",
        "No A2F markers found in timeline frame range": "时间线帧范围内未找到A2F标记",
        "Failed to regenerate phonemes from markers": "从标记重新生成音素失败",
        "Timestamps fixed from markers, animation regenerated": "时间戳已根据标记修正，动画已重新生成",
        # --- Emotion Overlay ---
        "Emotion Segmentation": "情绪叠加",
        "Enable Emotion Segmentation": "启用情绪叠加",
        "Add Segment": "添加分段",
        "Remove Segment": "删除分段",
        "Clear Segments": "清空分段",
        "Correct": "修正",
        "Correct Frame": "修正帧",
        "Copy the current timeline playhead frame into the active segment": "将时间轴当前帧复制到此分段的起始帧",
        "Add a new emotion segment row": "添加一个新的情绪分段",
        "Remove the active emotion segment row": "删除当前选中的情绪分段",
        "Clear all emotion segment rows": "清空所有情绪分段",
        "Segments": "分段",
        "No segments yet. Click Add above to create one.": "暂无分段，点击上方添加按钮创建。",
        "Frame": "帧",
        "Non-Mouth": "非口型",
        "Non-Mouth Min": "非口型最低占比",
        "Mouth": "口型",
        "Mouth Min": "口型最低占比",
        "Emotion": "情绪",
        "Emotion type for this segment": "本分段的情绪类型",
        "Recognized text for this emotion segment": "本情绪分段识别到的文本",
        "Emotion intensity for non-mouth channels (brow, eye, cheek, nose). 0=none, 1=normal, 2=extreme": "非口型通道（眉毛、眼睛、脸颊、鼻子）的情绪强度。0=无情绪，1=正常，2=强烈",
        "Minimum emotion ratio for non-mouth channels during silence. 0=emotion fully drops at silence, 1=emotion stays at peak regardless of audio. Lower values give more dynamic range, higher values keep emotion stable during pauses": "静音时非口型通道的情绪保留比例。0=静音时情绪完全消失，1=无论音频如何情绪保持峰值。值越小动态范围越大，值越大静音时情绪越稳定",
        "Mouth emotion blend ratio (0=no mouth emotion, 1=full mouth emotion). Lower values keep lip-sync cleaner, higher values let the emotion affect the mouth more strongly": "口型情绪融合比例（0=不应用口型情绪，1=完全应用）。值越小口型越干净，值越大情绪对口型影响越强",
        "Minimum emotion ratio for mouth channels during silence. 0=mouth emotion fully drops at silence, 1=mouth emotion stays at peak regardless of audio. Lower values let the mouth relax during pauses, higher values keep mouth emotion persistent": "静音时口型通道的情绪保留比例。0=静音时口型情绪完全消失，1=无论音频如何口型情绪保持峰值。值越小静音时口型越放松，值越大口型情绪越持久",
        "Start frame of this emotion segment in the timeline": "本情绪分段在时间轴上的起始帧",
        "Start Time": "开始时间",
        "Start time of this segment in seconds (audio-relative)": "本分段的开始时间（秒，相对于音频）",
        "End Time": "结束时间",
        "End time of this segment in seconds (audio-relative)": "本分段的结束时间（秒，相对于音频）",
        "Text": "文本",
        "Smile (No Teeth)": "微笑不露齿",
        "Smile Open": "微笑露齿",
        "Laugh": "大笑",
        "Angry": "愤怒",
        "Sad": "悲伤",
        "Surprised": "惊讶",
        "Disgust": "厌恶",
        "Fear": "恐惧",
        "Contempt": "轻蔑",
        "Thinking": "思考",
        "Coquetry": "撒娇",
        "Malicious": "恶毒",
        "Neutral": "中性",

        "No original inference data cached, please regenerate animation": "未缓存原始推理数据，请重新生成动画",
        "No phoneme data cached, please regenerate animation": "未缓存音素数据，请重新生成动画",
        "Strength updated and animation re-applied": "强度已更新，动画已重新应用",
        "Toggle is only available when animation data exists": "存在动画数据时才可切换",
        "Generate animation first to apply strength": "请先生成动画，才能应用强度",

        # --- Operator bl_description tooltips (new) ---
        # panel.py operators
        "Switch Audio2Face main page": "切换 Audio2Face 主页面",

        # --- DAZ page UI labels and descriptions ---
        "DAZ": "DAZ",
        "Drive DAZ FACS rig from audio": "从音频驱动 DAZ FACS 骨架",
        "DAZ Model Binding": "模型绑定",
        "Rig Controller Type": "骨骼控制器类型",
        "Armature": "骨架",
        "Select an armature with rig controllers": "选择一个带控制器的骨架",
        "Not a Faceit ControlRig (no c_* controller bones or shape key drivers)": "不是 Faceit 控制骨骼（无 c_* 控制骨骼或形态键驱动器）",
        "Faceit Controller Bones": "Faceit 控制骨骼",
        "Faceit Mapped ARKit": "已映射 ARKit",
        "Audio file to process for DAZ mode": "DAZ 模式下待处理的音频文件",
        "Current DAZ operation status": "当前 DAZ 操作状态",
        "FACS Properties": "FACS 属性",
        "Mapped ARKit": "已映射 ARKit",
        "Not a DAZ FACS rig (no facs_*(fin) properties)": "不是 DAZ FACS 骨架（无 facs_*(fin) 属性）",
        "Selected object is not an armature": "选择的对象不是骨架",
        "Generate facial animation from audio and drive DAZ FACS rig": "从音频生成面部动画并驱动 DAZ FACS 骨架",
        "Apply parameter adjustments to DAZ FACS animation curves in the specified frame range": "将参数调整应用到指定帧范围的 DAZ FACS 动画曲线",

        # --- Lip closure adjustment properties ---
        "Lip Closure Combined": "闭嘴联动",
        "Linked lip closure adjustment. Negative=stronger closure, positive=weaker closure, 0=no change": "联动的闭嘴调整。负值=闭合更强，正值=闭合更弱，0=不变",
        "Show Advanced Lip Parameters": "显示高级口型参数",
        "Show individual MouthClose / JawOpen / MouthLowerDown adjustments": "显示独立的 MouthClose / JawOpen / MouthLowerDown 调整",
        "Mouth Close Adjust": "闭嘴调整",
        "Adjust mouth close intensity. 0=no change, positive=stronger closure, negative=weaker (fixes lip overlap)": "调整闭嘴强度。0=不变，正值=闭合更强，负值=闭合更弱（修复嘴唇穿插）",
        "Jaw Open Adjust": "张嘴调整",
        "Adjust jaw open during bilabial sounds. 0=no change, positive=more jaw drop, negative=less jaw drop (helps lip closure)": "闭口音时调整张嘴幅度。0=不变，正值=张嘴更大，负值=张嘴更小（有助于闭嘴）",
        "Mouth Lower Down Adjust": "下唇下压调整",
        "Adjust lower lip down during bilabial sounds. 0=no change, positive=lower lip drops more, negative=lower lip stays up (helps lip closure)": "闭口音时调整下唇下压。0=不变，正值=下唇更低，负值=下唇保持上抬（有助于闭嘴）",

        # --- Emotion properties ---

        # --- Missing translations (added by cleanup script) ---
        "DAZ rig not found": "未找到 DAZ 骨架",
        "Failed to write keyframes to DAZ rig": "写入关键帧到 DAZ 骨架失败",
        "No ARKit -> DAZ FACS mapping could be built from this rig": "无法从该骨架构建 ARKit 到 DAZ FACS 的映射",
        "No DAZ rig selected": "未选择 DAZ 骨架",
        "No animation segment found for this clip": "未找到此片段的动画段",
        "Selected rig is not a DAZ FACS rig (no facs_* Object properties found)": "所选骨架不是 DAZ FACS 骨架（未找到 facs_* 对象属性）",
        "Selected rig is not a Faceit ControlRig (no c_* controller bones or shape key drivers)": "所选骨架不是 Faceit 控制骨架（未找到 c_* 控制骨骼或形态键驱动器）",
        "Pick Rig": "拾取骨架",
        "Pick active armature as rig (must match selected controller type)": "拾取当前选中的骨架（必须与所选控制器类型匹配）",

        # --- Keys referenced by code but previously missing from the dict ---
        "0=pure model inference, 1=pure phoneme preset": "0=纯模型推理，1=纯音素预设",
        "Emotion Segment Index": "情绪叠加段索引",
        "Enable manual emotion segmentation (assign emotion per segment)": "启用手动情绪叠加（为每个分段分配情绪）",
        "Failed to write animation": "写入动画失败",
        "Forced alignment applied": "强制对齐已应用",
        "Forced alignment failed. Check console for details.": "强制对齐失败。详见控制台。",
        "No ARKit -> Faceit mapping could be built from this rig": "无法从该骨架构建 ARKit 到 Faceit 的映射",
        "No audio file selected": "未选择音频文件",
        "Select rig controller type": "选择骨骼控制器类型",
        "Selected rig is not a Faceit ControlRig": "所选骨架不是 Faceit 控制骨架",
        "rig not found": "未找到骨架",

        # --- Auto-update system ---
        "AudioToFace Updater": "AudioToFace 更新",
        "Waiting for Blender to close...": "正在等待 Blender 关闭...",
        "Backing up old files...": "正在备份旧文件...",
        "Installing new files...": "正在安装新文件...",
        "Update complete, restarting Blender...": "更新完成，正在重启 Blender...",
        "Update failed. Please try again.": "更新失败，请重试。",
        "Downloading update...": "正在下载更新...",
        "Update ready, restarting Blender...": "更新准备就绪，正在重启 Blender...",
        "Update complete.": "更新完成。",
        "Update failed. See console for details.": "更新失败。详见控制台。",
        "No update available for this part.": "该部分没有可用更新。",
        "An update is already in progress.": "已有更新正在进行中。",
        "Updates": "更新",
        "Functional Code": "功能代码",
        "AI Model": "AI 模型",
        "Dependencies": "程序依赖",
        "Update": "更新",
        "Up to date": "已是最新",
        "Progress": "进度",
        "Update Available": "有新版本",
        "Open Preferences": "打开偏好设置",
        "Download and install the update for this component": "下载并安装该组件的更新",
        "Open Blender preferences and show the AudioToFace addon": "打开 Blender 偏好设置并定位到 AudioToFace 插件",
        "Core plugin logic and engine": "插件核心功能与引擎",
        "The animation model files": "动画模型文件",
        "Bundled runtime libraries": "内置运行库",
        "Save Scene?": "保存场景？",
        "Ask whether to save the scene before updating": "更新前询问是否保存当前场景",
        "Save the current scene before updating?": "更新前保存当前场景吗？",
        "Save": "保存",
        "Don't Save": "不保存",
        "Cancel": "取消",
        "Save the scene before updating": "保存场景后再更新",
        "Update without saving": "不保存直接更新",
        "Abort the update": "取消更新",
        "Choose what to do before updating": "选择更新前的操作",
    },
}


def current_lang() -> str:
    """Determine the effective UI language.

    Dynamically checks Blender's UI language so that changes to Blender's
    language preference are reflected immediately for runtime t() calls
    (e.g. in draw() methods, operator execute(), report messages).

    Class-level t() calls (bl_label, bl_description, name=, description=,
    EnumProperty items) are evaluated once at class definition time and
    use the cached _CURRENT_LANG; they are updated via module reload when
    Blender's language changes (see __init__.py language-change timer).
    """
    # 0. During a language-switch reload, use the forced override to avoid
    #    race conditions where bpy.app.translations.locale hasn't updated yet.
    global _RELOAD_LANG_OVERRIDE
    if _RELOAD_LANG_OVERRIDE:
        return _RELOAD_LANG_OVERRIDE
    # 1. Dynamically check Blender's effective language
    bl_lang = _detect_blender_lang()
    if bl_lang:
        return bl_lang
    # 2. Fall back to import-time cache
    global _CURRENT_LANG
    if _CURRENT_LANG:
        return _CURRENT_LANG
    # 3. Final fallback: English (keys are English, so this is safe)
    return 'en_US'


def t(key: str, lang: str | None = None) -> str:
    """Translate a key to the current (or given) language.

    Args:
        key: English text key.
        lang: Target language code (e.g. 'zh_CN'). Auto-detect if None.

    Returns:
        Translated string, or the key itself if no translation found
        (English fallback).
    """
    if lang is None:
        lang = current_lang()
    return TRANSLATIONS.get(lang, {}).get(key, key)


def tr(key: str) -> str:
    """Translate a key to English, for console report messages.

    Blender's C++ report system on Windows uses GBK encoding, which conflicts
    with sys.stdout reconfigured to UTF-8. Using English for report messages
    avoids garbled characters in the console. UI text should still use t().
    """
    return TRANSLATIONS.get('en', {}).get(key, key)

"""DAZ/Faceit mode animation generation operator.

Reuses the SDK inference, ASR, and phoneme-correction logic from
operators/generate.py (shared weight-domain processing). The rig-specific
step is the final write:

  - DAZ FACS: writes Object-level facs_* property keyframes via
    daz_driver.apply_blendshapes_to_daz_rig. The DAZ addon's drivers
    propagate slider values through rig.data (fin) to mesh shape keys.

  - Faceit ControlRig: writes pose bone location/rotation keyframes via
    faceit_driver.apply_blendshapes_to_faceit_rig. Faceit's shape key
    drivers apply the divisor and amp to produce final mesh deformation.

The settings on the page (upper/lower face strength, smoothing,
multipliers, etc.) are reused as-is because they all operate in the weight
domain before any write happens.
"""

import bpy
import os
import time

from ..utils.i18n import t, tr
from ..core import license_manager
from .daz_mapping import get_daz_mapping, detect_daz_rig
from .daz_driver import apply_blendshapes_to_daz_rig
from .faceit_mapping import get_faceit_mapping, detect_faceit_rig
from .faceit_driver import apply_blendshapes_to_faceit_rig


class AUDIO2FACE_OT_daz_generate(bpy.types.Operator):
    bl_idname = "audio2face.daz_generate"
    bl_label = t("Generate Animation")
    bl_description = t("Generate facial animation from audio and drive DAZ FACS rig")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        daz_props = getattr(context.scene, "audio2face_daz_props", None)
        if not daz_props or not daz_props.daz_rig_object:
            return False
        rig = bpy.data.objects.get(daz_props.daz_rig_object)
        if rig is None or rig.type != 'ARMATURE':
            return False
        if daz_props.rig_type == 'FACEIT':
            return detect_faceit_rig(rig)
        return detect_daz_rig(rig)

    def execute(self, context):
        from ..utils.feedback import fail, success
        daz_props = context.scene.audio2face_daz_props

        ok, lic_msg = license_manager.require_license()
        if not ok:
            return fail(self, daz_props, "License required", lic_msg)

        # Engine gate: if the native engine is unusable, block generation up
        # front instead of silently producing degraded output. All core
        # algorithms (mapping, emotion, phoneme, post-processing) run in C++,
        # so a broken engine means the result would be wrong without any
        # visible sign. Fail fast with a clear, actionable message.
        from ..core.license_manager import get_engine_status
        eng_ok, eng_msg = get_engine_status()
        if not eng_ok:
            return fail(self, daz_props, "Engine Error", eng_msg)

        # DAZ page keeps its own SDK/animator settings now (independent from
        # the Animation page). All SDK helpers below read from daz_props.
        props = daz_props

        audio_file = daz_props.audio_file
        if not audio_file:
            return fail(self, daz_props, "No audio file loaded")
        if not os.path.exists(audio_file):
            return fail(self, daz_props, "Audio file not found:", audio_file)

        rig = bpy.data.objects.get(daz_props.daz_rig_object) if daz_props.daz_rig_object else None
        if not rig:
            return fail(self, daz_props, "No DAZ rig selected")
        if rig.type != 'ARMATURE':
            return fail(self, daz_props, "Selected object is not an armature")

        # Detect rig type and build the appropriate mapping table.
        rig_type = daz_props.rig_type
        if rig_type == 'FACEIT':
            if not detect_faceit_rig(rig):
                return fail(self, daz_props, "Selected rig is not a Faceit ControlRig")
            mapping = get_faceit_mapping(rig)
            if not mapping:
                return fail(self, daz_props, "No ARKit -> Faceit mapping could be built from this rig")
            target_type = 'FACEIT_RIG'
            log_prefix = "[Audio2Face Faceit]"
        else:
            if not detect_daz_rig(rig):
                return fail(self, daz_props, "Selected rig is not a DAZ FACS rig (no facs_* Object properties found)")
            mapping = get_daz_mapping(rig)
            if not mapping:
                return fail(self, daz_props, "No ARKit -> DAZ FACS mapping could be built from this rig")
            target_type = 'DAZ_RIG'
            log_prefix = "[Audio2Face DAZ]"

        # Frame offset follows the same playhead-based formula as generate.py.
        frame_offset = max(0, int(context.scene.frame_current) - 1)
        print(f"[Audio2Face DAZ] Start frame: {frame_offset + 1} "
              f"(playhead={context.scene.frame_current})")

        daz_props.status_message = t("Generating animation...")
        daz_props.is_processing = True

        try:
            t0 = time.time()

            # ============================================================
            # 1. ASR pre-pass (shared with main pipeline).
            # ============================================================
            utterances = None
            task_resp = None
            need_asr = props.enable_phoneme_correction
            if need_asr:
                _t_asr = time.time()
                utterances, task_resp = self._run_asr(props, audio_file)
                print(f"[Audio2Face DAZ] ASR total: {time.time() - _t_asr:.2f}s")
                # Store recognized text for the editable ASR text box
                if utterances:
                    daz_props.asr_recognized_text = ''.join(u.text for u in utterances)

            # ============================================================
            # 2. ONNX inference (shared with main pipeline, emotion disabled).
            # ============================================================
            _t_sdk = time.time()
            blendshape_data = self._process_with_sdk(props, utterances=utterances, fps=context.scene.render.fps)
            print(f"[Audio2Face DAZ] SDK inference: {time.time() - _t_sdk:.2f}s")

            if not blendshape_data:
                return fail(self, daz_props, "Failed to generate animation")

            # ============================================================
            # Silence suppression (unified with Animation page).
            # Applied before emotion fusion so the emotion baseline is
            # also silence-cleaned.
            # ============================================================
            from ..operators.generate import _apply_silence_suppression
            _apply_silence_suppression(blendshape_data, audio_file,
                                       context.scene.render.fps, frame_offset)
            print(f"[Audio2Face DAZ] Silence suppression applied")

            # ============================================================
            # Emotion template fusion (weight-level, unified with Animation
            # page). Bakes emotion deltas into blendshape_data BEFORE cache
            # storage so the cache baseline = SDK + silence + emotion.
            # Phoneme correction is applied later as an external adjuster.
            # ============================================================
            if daz_props.emotion_segments_enabled and len(daz_props.emotion_segments) > 0:
                _t_emo = time.time()
                from ..core.emotion_fusion import apply_emotion_fusion_to_weights
                apply_emotion_fusion_to_weights(
                    blendshape_data,
                    segments=list(daz_props.emotion_segments),
                    audio_path=audio_file,
                    fps=context.scene.render.fps,
                    frame_offset=frame_offset,
                )
                print(f"[Audio2Face DAZ] Emotion fusion: {time.time() - _t_emo:.2f}s "
                      f"({len(daz_props.emotion_segments)} segments)")

            # ============================================================
            # Cache the emotion-fused baseline (data packet A).
            # original_frames = SDK + silence + emotion (NO phoneme).
            # This is the stable baseline for phoneme slider re-adjustment
            # and Apply Adjustments — emotion is baked in, phoneme is not.
            # ============================================================
            from ..core.blendshape import BlendshapeFrame
            from ..core.animation_cache import AnimationCache
            original_frames_copy = [
                BlendshapeFrame(time=f.time, weights=dict(f.weights))
                for f in blendshape_data
            ]

            # Phoneme correction (external adjuster, applied on a copy).
            phoneme_data = None
            write_frames = blendshape_data
            if props.enable_phoneme_correction:
                _t_ph = time.time()
                write_frames, phoneme_data = self._apply_phoneme_correction(
                    blendshape_data, props, audio_file,
                    utterances=utterances, task_resp=task_resp,
                    fps=context.scene.render.fps,
                )
                print(f"[Audio2Face DAZ] Phoneme correction: {time.time() - _t_ph:.2f}s")

            # Store baseline (SDK+silence+emotion) for real-time phoneme toggling.
            AnimationCache.store_original_frames(
                frames=original_frames_copy,
                phoneme_data=phoneme_data,
                frame_offset=frame_offset
            )
            # Store current frames (SDK+silence+emotion+phoneme) for display.
            AnimationCache.store_frames(
                frames=write_frames,
                fps=context.scene.render.fps,
                target_object=rig.name,
                target_type=target_type,
                mapping=mapping,
                frame_offset=frame_offset
            )

            # ============================================================
            # Write keyframes to the rig.
            # DAZ: Object-level facs_* custom properties.
            # Faceit: pose bone location/rotation transforms.
            # ============================================================
            _t_write = time.time()
            if rig_type == 'FACEIT':
                ok = apply_blendshapes_to_faceit_rig(
                    rig, write_frames, mapping,
                    fps=context.scene.render.fps, frame_offset=frame_offset,
                )
                print(f"{log_prefix} Write to bone transforms: {time.time() - _t_write:.2f}s")
            else:
                ok = apply_blendshapes_to_daz_rig(
                    rig, write_frames, mapping,
                    fps=context.scene.render.fps, frame_offset=frame_offset,
                )
                print(f"{log_prefix} Write to rig Object props: {time.time() - _t_write:.2f}s")

            if not ok:
                return fail(self, daz_props, "Failed to write keyframes to DAZ rig")

            # ============================================================
            # 7. Update frame-range state and UI status.
            # ============================================================
            seg_start = frame_offset + 1
            seg_end = frame_offset + round(blendshape_data[-1].time * context.scene.render.fps) + 1
            daz_props.frame_start = seg_start
            daz_props.frame_end = seg_end
            daz_props.has_animation_data = True
            daz_props.animation_frame_count = AnimationCache.get_frame_count()

            # Set the timeline playback range to match the generated animation.
            context.scene.frame_start = seg_start
            context.scene.frame_end = seg_end
            print(f"[Audio2Face DAZ] Set timeline range to: {seg_start}-{seg_end}")

            print(f"[Audio2Face DAZ] TOTAL execute: {time.time() - t0:.2f}s")

            # ============================================================
            # Create timeline markers for each character (scoped to frame
            # range). Allows user to fine-tune timestamps without editing
            # text, then click "Fix Timestamps from Markers" to regenerate.
            # ============================================================
            try:
                from ..core.phoneme_correction.local_asr import LocalASR
                chars_data = LocalASR._shared_chars
                if chars_data:
                    from ..core.timeline_markers import create_char_markers
                    n = create_char_markers(
                        context.scene, chars_data,
                        context.scene.render.fps, frame_offset,
                    )
                    print(f"[Audio2Face DAZ] Created {n} char markers")
            except Exception as _me:
                print(f"[Audio2Face DAZ] Marker creation skipped: {_me}")

            success(self, daz_props, "Animation generated successfully",
                    f"({t('starts at frame')} {seg_start})")
            self.report({'INFO'}, tr("Animation generated successfully") + f" (" + tr("starts at frame") + f" {seg_start})")
            return {'FINISHED'}

        except Exception as e:
            import traceback
            fail(self, daz_props, "Failed to generate animation", str(e))
            print(f"[Audio2Face DAZ] {e}")
            traceback.print_exc()
            return {'CANCELLED'}
        finally:
            daz_props.is_processing = False

    # ------------------------------------------------------------------
    # Shared pipeline helpers (delegated to operators.generate.AUDIO2FACE_OT_generate)
    # ------------------------------------------------------------------
    # We instantiate the main generate operator's class and call its private
    # methods. This avoids duplicating ~400 lines of SDK/ASR/phoneme logic
    # while keeping DAZ mode's write path fully independent.

    def _get_shared_generator(self):
        """Lazily import and instantiate the main generate operator for its
        private SDK/ASR/phoneme methods."""
        from ..operators.generate import AUDIO2FACE_OT_generate
        return AUDIO2FACE_OT_generate

    def _run_asr(self, props, audio_path):
        gen_cls = self._get_shared_generator()
        dummy = _DummyOperator(gen_cls)
        return gen_cls._run_asr(dummy, props, audio_path)

    def _apply_phoneme_correction(self, frames, props, audio_path, utterances=None, task_resp=None, fps=None):
        gen_cls = self._get_shared_generator()
        dummy = _DummyOperator(gen_cls)
        return gen_cls._apply_phoneme_correction(dummy, frames, props, audio_path, utterances, task_resp, fps=fps)

    def _process_with_sdk(self, props, utterances=None, fps=None):
        gen_cls = self._get_shared_generator()
        dummy = _DummyOperator(gen_cls)
        return gen_cls._process_with_sdk(dummy, props, utterances=utterances, fps=fps)


class _DummyOperator:
    """Stand-in for bpy.types.Operator that delegates unknown attribute
    lookups to the main generate operator class. This lets us call the main
    generate operator's private methods (which may reference self.helper_xxx)
    without going through Blender's operator registration system.
    """
    def __init__(self, gen_cls=None):
        self._gen_cls = gen_cls

    def report(self, level, message):
        # Blender passes level as a set of flags, e.g. {'INFO'} or {'ERROR'}.
        # Normalize to a single string for prefix lookup.
        if isinstance(level, (set, frozenset)):
            level_str = next(iter(level)) if level else 'INFO'
        else:
            level_str = str(level)
        prefix = {'ERROR': '[Audio2Face DAZ] ERROR',
                  'WARNING': '[Audio2Face DAZ] WARNING',
                  'INFO': '[Audio2Face DAZ]'}.get(level_str, '[Audio2Face DAZ]')
        print(f"{prefix}: {message}")

        # Mirror the message to the UI status bar so the user can see it
        # without opening the console. Only mirror non-INFO levels so routine
        # info prints don't overwrite the status the user is watching.
        if level_str in ('WARNING', 'ERROR'):
            try:
                import bpy
                daz_props = getattr(
                    bpy.context.scene, "audio2face_daz_props", None)
                if daz_props is not None:
                    daz_props.status_message = str(message)
            except Exception:
                pass

    def __getattr__(self, name):
        # Delegate unknown attribute access (e.g. _resample_frames,
        # _apply_advanced_controls helpers) to the main generate operator
        # class, returning an unbound method bound to this dummy instance.
        if self._gen_cls is not None and hasattr(self._gen_cls, name):
            return getattr(self._gen_cls, name).__get__(self, self._gen_cls)
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'"
        )


classes = [AUDIO2FACE_OT_daz_generate]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

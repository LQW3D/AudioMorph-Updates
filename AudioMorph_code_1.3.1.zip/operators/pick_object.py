import bpy
from ..utils.i18n import t

class AUDIO2FACE_OT_pick_daz_rig(bpy.types.Operator):
    """Pick the active armature as the rig for the selected controller type."""
    bl_idname = "audiomorph.pick_daz_rig"
    bl_label = t("Pick Rig")
    bl_description = t("Pick active armature as rig (must match selected controller type)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        daz_props = context.scene.audiomorph_daz_props
        active_obj = context.active_object

        if not active_obj:
            self.report({'WARNING'}, t("No object selected"))
            return {'CANCELLED'}

        if active_obj.type != 'ARMATURE':
            self.report({'WARNING'}, t("Selected object is not an armature"))
            return {'CANCELLED'}

        # Validate the armature matches the selected controller type.
        # Mismatch = reject (CANCELLED) so the user gets immediate feedback
        # instead of a silent accept that only fails later at generate time.
        rig_type = daz_props.rig_type
        try:
            if rig_type == 'FACEIT':
                from ..daz.faceit_mapping import detect_faceit_rig
                if not detect_faceit_rig(active_obj):
                    self.report({'ERROR'}, t("Selected rig is not a Faceit ControlRig (no c_* controller bones or shape key drivers)"))
                    return {'CANCELLED'}
            else:  # DAZ
                from ..daz.daz_mapping import detect_daz_rig
                if not detect_daz_rig(active_obj):
                    self.report({'ERROR'}, t("Selected rig is not a DAZ FACS rig (no facs_* Object properties found)"))
                    return {'CANCELLED'}
        except Exception:
            # If detection itself throws, don't block the user — the
            # generate operator will re-validate at run time.
            pass

        daz_props.daz_rig_object = active_obj.name
        self.report({'INFO'}, t("Selected:") + f" {active_obj.name}")
        return {'FINISHED'}


classes = [AUDIO2FACE_OT_pick_daz_rig]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

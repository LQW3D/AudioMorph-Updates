import bpy
import json
import os

from ..properties import _DEFAULT_KEYS, get_daz_defaults_path
from ..utils.i18n import t, tr


def _collect_defaults(props) -> dict:
    """Snapshot all SDK-related fields from a property group.

    Iterates _DEFAULT_KEYS so new fields added to the schema are picked up
    automatically (no more missing-key bugs like the previous
    mouth_upper_up_multiplier regression).
    """
    def _round(v, ndigits=6):
        return round(v, ndigits) if isinstance(v, float) else v

    data = {}
    for key in _DEFAULT_KEYS:
        if hasattr(props, key):
            try:
                data[key] = _round(getattr(props, key))
            except Exception:
                pass
    return data


class AUDIO2FACE_OT_save_defaults(bpy.types.Operator):
    """Save the current page's parameters as the page default.

    On the Animation page this writes config/user_defaults.json; on the
    DAZ page it writes config/user_defaults_daz.json. The two files are
    fully independent so tuning one page never affects the other.
    """
    bl_idname = "audiomorph.save_defaults"
    bl_label = t("Save Defaults")
    bl_description = t("Save current page parameters as defaults (Animation or DAZ)")
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        # Only the DAZ page remains; always use audiomorph_daz_props.
        source_props = context.scene.audiomorph_daz_props
        defaults_path = get_daz_defaults_path()
        page_label = "DAZ"

        os.makedirs(os.path.dirname(defaults_path), exist_ok=True)

        defaults = _collect_defaults(source_props)

        try:
            with open(defaults_path, 'w', encoding='utf-8') as f:
                json.dump(defaults, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.report({'ERROR'}, tr("Failed to save defaults") + f": {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, tr(f"{page_label} defaults saved, restart Blender to apply"))
        print(f"[AudioMorph] {page_label} defaults saved: {defaults_path}")
        return {'FINISHED'}

"""Manual emotion segmentation operators.

ASR splits the audio into utterances (each is one emotion segment row). The
user assigns an emotion type + intensity per row, and can correct the start
frame by moving the timeline playhead and clicking the correct button.

Only the DAZ page remains after the closed-source refactor, so all operators
route to scene.audiomorph_daz_props unconditionally.
"""

import bpy

from ..utils.i18n import t


def _get_emotion_props(context):
    """Return the property group that owns emotion_segments.

    Only the DAZ page remains; always return scene.audiomorph_daz_props.
    """
    return context.scene.audiomorph_daz_props


class AUDIO2FACE_OT_emotion_segment_correct_frame(bpy.types.Operator):
    """Copy the current timeline playhead frame into the active segment"""
    bl_idname = "audiomorph.emotion_segment_correct_frame"
    bl_label = t("Correct Frame")
    bl_description = t("Copy the current timeline playhead frame into the active segment")
    bl_options = {'INTERNAL'}

    segment_index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        props = _get_emotion_props(context)
        idx = self.segment_index if self.segment_index >= 0 else props.emotion_segments_index
        if idx < 0 or idx >= len(props.emotion_segments):
            return {'CANCELLED'}
        props.emotion_segments[idx].frame = max(1, int(context.scene.frame_current))
        props.emotion_segments_index = idx
        return {'FINISHED'}


class AUDIO2FACE_OT_emotion_segment_add(bpy.types.Operator):
    """Add a new emotion segment row"""
    bl_idname = "audiomorph.emotion_segment_add"
    bl_label = t("Add Segment")
    bl_description = t("Add a new emotion segment row")
    bl_options = {'INTERNAL'}

    def execute(self, context):
        props = _get_emotion_props(context)
        item = props.emotion_segments.add()
        item.text = ""
        item.emotion = 'NEUTRAL'
        item.intensity = 0.5
        item.frame = max(1, int(context.scene.frame_current))
        props.emotion_segments_index = len(props.emotion_segments) - 1
        return {'FINISHED'}


class AUDIO2FACE_OT_emotion_segment_remove(bpy.types.Operator):
    """Remove the active emotion segment row"""
    bl_idname = "audiomorph.emotion_segment_remove"
    bl_label = t("Remove Segment")
    bl_description = t("Remove the active emotion segment row")
    bl_options = {'INTERNAL'}

    segment_index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        props = _get_emotion_props(context)
        idx = self.segment_index if self.segment_index >= 0 else props.emotion_segments_index
        if idx < 0 or idx >= len(props.emotion_segments):
            return {'CANCELLED'}
        props.emotion_segments.remove(idx)
        props.emotion_segments_index = min(props.emotion_segments_index, max(0, len(props.emotion_segments) - 1))
        return {'FINISHED'}


class AUDIO2FACE_OT_emotion_segment_clear(bpy.types.Operator):
    """Clear all emotion segment rows"""
    bl_idname = "audiomorph.emotion_segment_clear"
    bl_label = t("Clear Segments")
    bl_description = t("Clear all emotion segment rows")
    bl_options = {'INTERNAL'}

    def execute(self, context):
        props = _get_emotion_props(context)
        props.emotion_segments.clear()
        props.emotion_segments_index = 0
        return {'FINISHED'}


classes = (
    AUDIO2FACE_OT_emotion_segment_correct_frame,
    AUDIO2FACE_OT_emotion_segment_add,
    AUDIO2FACE_OT_emotion_segment_remove,
    AUDIO2FACE_OT_emotion_segment_clear,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

"""Automatic update operators for AudioMorph.

Handles the three independent update parts (code / model / deps):
  - code/deps : download -> verify -> stage -> detach-and-relay -> restart Blender
  - model     : download -> verify -> replace in place (no restart)

Network work runs on a background thread; a Blender timer polls the shared
state so the UI progress bar updates without ever blocking the main thread.
"""

import threading
import time

import bpy
from bpy.props import EnumProperty, FloatProperty, StringProperty

from ..core import updater
from ..utils.i18n import t, tr


# Module name used as the addon key in bpy.context.preferences.addons.
_ADDON_KEY = "AudioMorph"


# Shared update state. Written by the worker thread, read by the UI timer.
_UPDATE_STATE = {
    "phase": "idle",   # idle|downloading|restart_pending|restarting|done|error
    "part": "",        # code|model|deps
    "progress": 0.0,   # 0..100
    "message": "",     # status key (English, translated for display)
}

# Manifest cache. The network fetch runs on a background thread so the UI
# thread never blocks. draw() reads this dict synchronously (pure in-memory,
# no I/O). A stale or empty cache triggers a background refresh that is picked
# up on later draws.
_manifest_cache = {"time": 0.0, "data": None, "fetching": False}

# Minimum interval between background manifest refreshes (seconds).
_MANIFEST_TTL = 300


def _fetch_manifest_bg():
    """Background task: fetch the manifest and store it in the cache."""
    _manifest_cache["fetching"] = True
    try:
        _manifest_cache["data"] = updater.get_manifest()
        _manifest_cache["time"] = time.time()
    except Exception:
        pass
    finally:
        _manifest_cache["fetching"] = False


def _ensure_manifest_async():
    """Start a background fetch if the cache is empty or stale. Never blocks."""
    now = time.time()
    if _manifest_cache["fetching"]:
        return
    if (_manifest_cache["data"] is None
            or now - _manifest_cache["time"] > _MANIFEST_TTL):
        threading.Thread(target=_fetch_manifest_bg, daemon=True).start()


def get_update_parts():
    """Return parts with a newer version, read from the cached manifest.

    Never performs network I/O on the calling (UI) thread. Kicks off an
    async refresh if needed; the result appears on subsequent draws.
    """
    _ensure_manifest_async()
    manifest = _manifest_cache["data"]
    if not manifest:
        return []
    return updater.check_updates(manifest)


def _prefs():
    try:
        return bpy.context.preferences.addons.get(_ADDON_KEY).preferences
    except Exception:
        return None


def _progress_cb(downloaded, total):
    if total:
        _UPDATE_STATE["progress"] = min(95.0, downloaded * 100.0 / total)
    else:
        _UPDATE_STATE["progress"] = min(95.0, _UPDATE_STATE["progress"] + 0.5)


def _worker(part, entry):
    try:
        _UPDATE_STATE.update(
            phase="downloading", part=part, progress=0.0, message="")
        zip_path = updater.download_part(part, entry, progress_cb=_progress_cb)
        if not zip_path:
            _UPDATE_STATE.update(phase="error", message="download_failed")
            return
        _UPDATE_STATE["progress"] = 100.0
        if part == "model":
            ok, msg = updater.apply_model_update(zip_path)
            if ok:
                _UPDATE_STATE.update(phase="done", message="update_success")
            else:
                _UPDATE_STATE.update(phase="error", message=msg or "apply_failed")
        else:
            # code/deps: stage + detach-and-relay already launched inside.
            ok, msg = updater.apply_code_or_deps_update(zip_path, part)
            if ok:
                _UPDATE_STATE.update(phase="restart_pending", message="restart_pending")
            else:
                _UPDATE_STATE.update(phase="error", message=msg or "apply_failed")
    except Exception as e:
        _UPDATE_STATE.update(phase="error", message=str(e))


def _finish_restart():
    """Relay is already waiting on our pid; ask Blender to quit now."""
    _UPDATE_STATE["phase"] = "restarting"
    try:
        bpy.ops.wm.quit_blender()
    except Exception:
        import sys
        sys.exit(0)


def _reset_state():
    _UPDATE_STATE.update(phase="idle", part="", progress=0.0, message="")


def _update_timer():
    prefs = _prefs()
    if prefs is None:
        return None
    state = _UPDATE_STATE
    phase = state["phase"]

    if phase == "idle":
        return None  # stop polling

    if phase == "downloading":
        prefs.download_progress = state["progress"]
        prefs.update_status = t("Downloading update...")
        return 0.1

    if phase == "restart_pending":
        prefs.update_status = t("Update ready, restarting Blender...")
        _finish_restart()
        return 0.1

    if phase == "restarting":
        # Blender is about to quit; keep the timer alive until exit.
        return 0.1

    if phase == "done":
        prefs.download_progress = 100.0
        prefs.update_status = t("Update complete.")
        _reset_state()
        return None

    if phase == "error":
        prefs.download_progress = 0.0
        prefs.update_status = t("Update failed. See console for details.")
        _reset_state()
        return None

    return None


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

# Set when the user picked "Save" but the scene has never been saved. The
# native Save As dialog is opened and _timer_wait_save polls until the scene
# gets a path (or the file browser is closed without saving, which aborts).
_pending_part_on_save = ""


def _start_update(part):
    """Start the background download+restart flow for *part*.

    Returns True if the update was started, False otherwise. Uses the cached
    manifest so it never touches the network on the calling (UI) thread.
    """
    _ensure_manifest_async()
    manifest = _manifest_cache["data"]
    entry = (manifest or {}).get(part) if manifest else None
    if not entry:
        return False
    if _UPDATE_STATE["phase"] in (
            "downloading", "restart_pending", "restarting"):
        return False

    _UPDATE_STATE.update(phase="downloading", part=part,
                         progress=0.0, message="")
    thread = threading.Thread(
        target=_worker, args=(part, entry), daemon=True)
    thread.start()
    if not bpy.app.timers.is_registered(_update_timer):
        bpy.app.timers.register(_update_timer, first_interval=0.1)
    return True


def _timer_wait_save():
    """Wait for the user to finish the native Save As dialog.

    Once the scene has a filepath the pending update starts automatically.
    If the file browser closes without saving, the pending update is dropped.
    """
    global _pending_part_on_save
    if not _pending_part_on_save:
        return None

    if bpy.data.filepath:
        part = _pending_part_on_save
        _pending_part_on_save = ""
        _start_update(part)
        return None

    # Still waiting: keep polling only while the native file browser is open.
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'FILE':
                return 0.5
    # File browser closed without saving -> user cancelled the save.
    _pending_part_on_save = ""
    return None


class AUDIO2FACE_OT_update_confirm(bpy.types.Operator):
    """Ask whether to save the scene before applying an update"""
    bl_idname = "audiomorph.update_confirm"
    bl_label = t("Save Scene?")
    bl_description = t("Ask whether to save the scene before updating")

    part: StringProperty(default="code", options={'HIDDEN', 'SKIP_SAVE'})

    choice: EnumProperty(
        items=[
            ('save', t("Save"), t("Save the scene before updating")),
            ('nosave', t("Don't Save"), t("Update without saving")),
            ('cancel', t("Cancel"), t("Abort the update")),
        ],
        default='save',
        description=t("Choose what to do before updating"),
    )

    def invoke(self, context, event):
        # Use invoke_props_dialog (standard Blender dialog with built-in
        # OK / Cancel buttons) instead of invoke_popup. invoke_popup + modal
        # handler crashes Blender 5.2 on popup teardown
        # (wm_operator_ui_popup_cancel access violation).
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.scale_y = 1.2
        col.label(text=t("Save the current scene before updating?"))
        col.prop(self, "choice", expand=True)

    def execute(self, context):
        # Called when the user clicks OK in the dialog.
        choice = self.choice
        part = self.part

        if choice == "cancel":
            return {'CANCELLED'}

        if choice == "save":
            if bpy.data.filepath:
                # Already saved to a path -> save silently in place.
                try:
                    bpy.ops.wm.save_mainfile()
                except Exception:
                    pass
            else:
                # Never saved -> open the native "Save As" dialog and wait for
                # the user to finish before the update continues. This never
                # closes Blender early; the update only starts once the scene
                # has been saved (or the save is cancelled, which aborts).
                global _pending_part_on_save
                _pending_part_on_save = part
                try:
                    bpy.ops.wm.save_as_mainfile('INVOKE_DEFAULT')
                except Exception:
                    _pending_part_on_save = ""
                    self.report({'WARNING'},
                                tr("Unable to open the save dialog."))
                    return {'CANCELLED'}
                if not bpy.app.timers.is_registered(_timer_wait_save):
                    bpy.app.timers.register(
                        _timer_wait_save, first_interval=0.5)
                return {'FINISHED'}

        # save (saved in place) or nosave -> start the update right away.
        if not _start_update(part):
            self.report({'WARNING'},
                        tr("No update available for this part."))
            return {'CANCELLED'}
        return {'FINISHED'}


class AUDIO2FACE_OT_update_part(bpy.types.Operator):
    """Download and install the update for one part"""
    bl_idname = "audiomorph.update_part"
    bl_label = t("Update")
    bl_description = t("Download and install the update for this component")

    part: StringProperty(default="code")
    action: StringProperty(default="nosave")

    def execute(self, context):
        part = self.part

        #  - save   : save the current scene (native save dialog if unsaved),
        #             then proceed with the update.
        #  - nosave : skip saving and proceed directly.
        #  - cancel : abort the update entirely.
        if self.action == "cancel":
            return {'CANCELLED'}

        if self.action == "save":
            if bpy.data.filepath:
                # Already saved to a path -> save silently in place.
                try:
                    bpy.ops.wm.save_mainfile()
                except Exception:
                    pass
            else:
                # Never saved -> open the native "Save As" dialog and wait for
                # the user to finish before the update continues. This never
                # closes Blender early; the update only starts once the scene
                # has been saved (or the save is cancelled, which aborts).
                global _pending_part_on_save
                _pending_part_on_save = part
                try:
                    bpy.ops.wm.save_as_mainfile('INVOKE_DEFAULT')
                except Exception:
                    _pending_part_on_save = ""
                    self.report({'WARNING'},
                                tr("Unable to open the save dialog."))
                    return {'CANCELLED'}
                if not bpy.app.timers.is_registered(_timer_wait_save):
                    bpy.app.timers.register(
                        _timer_wait_save, first_interval=0.5)
                return {'FINISHED'}

        # save (saved in place) or nosave -> start the update right away.
        if not _start_update(part):
            self.report({'WARNING'},
                        tr("No update available for this part."))
            return {'CANCELLED'}
        return {'FINISHED'}


class AUDIO2FACE_OT_open_preferences(bpy.types.Operator):
    """Open Blender preferences and show the AudioMorph addon"""
    bl_idname = "audiomorph.open_preferences"
    bl_label = t("Open Preferences")
    bl_description = t("Open Blender preferences and show the AudioMorph addon")

    def execute(self, context):
        # In Blender >= 5.2, context.window_manager.preferences_type is
        # obsolete and raises, which used to abort the whole operator before
        # the preferences window could open. Open the window first, then switch
        # to the Add-ons section and show this addon.
        try:
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
            context.preferences.active_section = 'ADDONS'
            bpy.ops.preferences.addon_show(module="AudioMorph")
        except Exception:
            pass
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Addon preferences panel (three update buttons + descriptions + progress)
# ---------------------------------------------------------------------------

# (part, name_key, desc_key, icon)
# Only "code" is auto-updatable. Model and dependencies are distributed
# manually (too large for GitHub), so their update buttons are not shown.
_PART_SPECS = (
    ("code", "Functional Code", "Core plugin logic and engine", 'FILE_SCRIPT'),
)


class AudioMorphPreferences(bpy.types.AddonPreferences):
    bl_idname = "AudioMorph"

    download_progress: FloatProperty(
        name="Download Progress", default=0.0, min=0.0, max=100.0,
        subtype='PERCENTAGE')
    update_status: StringProperty(default="")

    def draw(self, context):
        layout = self.layout
        state = _UPDATE_STATE
        updates = get_update_parts()

        box = layout.box()
        box.label(text=t("Updates"), icon='FILE_REFRESH')

        for part, name_key, desc_key, icon in _PART_SPECS:
            has = part in updates
            sub = box.box()

            # Header row: name + availability badge.
            head = sub.row()
            head.label(text=t(name_key), icon=icon)
            if has:
                head.alert = True
                head.label(text=t("Update Available"), icon='INFO')

            # Update button (red/clickable when available, grey otherwise).
            # Opens a native "Save / Don't Save / Cancel" confirmation dialog
            # before starting the download+restart flow.
            row = sub.row()
            op = row.operator(
                "audiomorph.update_confirm",
                text=t("Update") if has else t("Up to date"))
            op.part = part
            if not has:
                row.enabled = False

            # Function intro text.
            sub.label(text=t(desc_key), icon='NONE')

            # Live progress for the part currently being downloaded.
            if state["phase"] == "downloading" and state["part"] == part:
                sub.prop(self, "download_progress",
                         text=t("Progress"), slider=True)
            elif state["phase"] == "done" and state["part"] == part:
                sub.label(text=t("Update complete."), icon='CHECKMARK')
            elif state["phase"] == "error" and state["part"] == part:
                sub.label(text=t("Update failed. See console for details."),
                          icon='ERROR')


classes = (
    AUDIO2FACE_OT_update_confirm,
    AUDIO2FACE_OT_update_part,
    AUDIO2FACE_OT_open_preferences,
    AudioMorphPreferences,
)
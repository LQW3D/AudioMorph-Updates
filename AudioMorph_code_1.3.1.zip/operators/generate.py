import bpy
import os
import wave
import tempfile
from typing import Dict, List, Any, Tuple
from ..utils.i18n import t, tr
from ..core.phoneme_correction import PhonemeCorrector
from ..core.phoneme_correction.speech_analyzer import SpeechAnalyzer

_SDK_MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                "deps", "models", "james_v3.0", "model.json")

# Worker output is 68 channels: the first 52 are the ARKit blendshape order used by
# the expression preset, followed by 16 tongue-solver poses from bs_tongue.npz.
# The 68-channel naming table and the multiplier mapping live in the compiled
# C++ engine (a2f_engine.map_sdk_output) to protect the mapping recipe.


# ---------------------------------------------------------------------------
# Silence suppression: dampen lip-sync noise during audio pauses.
# ---------------------------------------------------------------------------

# Channels suppressed to near-zero during silence. These are the lip-sync
# channels that the NVIDIA model may drive with small non-zero noise during
# pauses, causing the mouth to twitch. Eye/brow channels are preserved so
# natural blinks and eye darts continue during pauses.
# The channel set and the suppression algorithm live in the compiled C++
# engine (a2f_engine.apply_silence_suppression).


def _apply_silence_suppression(frames, audio_path: str, fps: float,
                                frame_offset: int = 0) -> None:
    """Suppress lip-sync noise during silent segments of the audio.

    Computes a per-frame amplitude envelope from the source audio, detects
    silence frames (amplitude below 5% of peak), and scales down the
    lip-sync channels on those frames in-place. Eye/brow channels are
    preserved so blinks and eye darts continue naturally during pauses.

    The function is a no-op if the audio file cannot be loaded or if every
    frame is above the silence threshold.

    Args:
        frames: list of BlendshapeFrame (modified in-place).
        audio_path: source audio file for amplitude analysis.
        fps: scene frame rate.
        frame_offset: frame number offset (segment start, unused here
            because the frames list is already segment-local).
    """
    if not frames or not audio_path or not os.path.isfile(audio_path):
        print(f"[AudioMorph] Silence suppression skipped: frames={len(frames) if frames else 0}, "
              f"audio={'missing' if not audio_path or not os.path.isfile(audio_path) else audio_path}")
        return

    try:
        import librosa
    except ImportError:
        print("[AudioMorph] Silence suppression skipped: librosa not available")
        return

    try:
        y, sr = librosa.load(audio_path, sr=None, mono=True)
    except Exception as e:
        print(f"[AudioMorph] Silence suppression skipped: audio load failed: {e}")
        return

    if len(y) == 0:
        print("[AudioMorph] Silence suppression skipped: empty audio")
        return

    # Compute RMS energy per ~30ms hop (matching human perception window).
    hop = 512
    rms = librosa.feature.rms(y=y, hop_length=hop, frame_length=hop * 2)[0]
    if len(rms) == 0:
        print("[AudioMorph] Silence suppression skipped: RMS empty")
        return

    # Silence detection (5% peak threshold), the suppressed channel set and
    # the smoothstep relaxation recipe run in the compiled C++ engine.
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_silence_suppression(
            frames_dicts, [float(v) for v in rms], float(sr), hop, float(fps)
        )
    except Exception as e:
        print(f"[AudioMorph] Silence suppression skipped: C++ engine unavailable ({e})")
        return

    for fd, rd in zip(frames, result):
        fd.weights = dict(rd["weights"])
    print(f"[AudioMorph] Silence suppression: applied to {len(frames)} frames "
          f"(threshold=5% of peak)")


def _load_audio_wav(wav_path: str) -> list[float]:
    """Read a 16kHz mono WAV and return float samples."""
    with wave.open(wav_path, 'rb') as wf:
        if wf.getnchannels() != 1:
            raise ValueError(f"Expected mono audio, got {wf.getnchannels()} channels")
        if wf.getframerate() != 16000:
            raise ValueError(f"Expected 16000 Hz sample rate, got {wf.getframerate()} Hz")
        n = wf.getnframes()
        raw = wf.readframes(n)
    import struct
    fmt = f"<{n}h"
    samples_i16 = struct.unpack(fmt, raw)
    return [s / 32768.0 for s in samples_i16]


def _ensure_wav_audio(audio_path: str) -> Tuple[str, bool]:
    """Ensure the audio file is a 16kHz mono WAV.

    Returns (wav_path, is_temp). If the input is already WAV, returns it
    as-is with is_temp=False. Otherwise converts to a temp WAV file.

    Tries multiple methods in order:
      1. librosa (fast, needs system ffmpeg for MP3)
      2. Blender aud module (uses bundled ffmpeg, no system ffmpeg needed)
      3. Blender VSE mixdown (most compatible, uses sequencer's decoder)
    """
    # Already a WAV file — return as-is
    if audio_path.lower().endswith('.wav'):
        return audio_path, False

    # Method 1: librosa (fast, but needs system ffmpeg for MP3 decoding)
    try:
        import librosa
        import soundfile as sf
        audio, _ = librosa.load(audio_path, sr=16000, mono=True)
        fd, wav_path = tempfile.mkstemp(suffix='.wav')
        os.close(fd)
        sf.write(wav_path, audio, 16000, subtype='PCM_16')
        print(f"[AudioMorph] Audio converted to WAV via librosa: {wav_path}")
        return wav_path, True
    except Exception as librosa_err:
        print(f"[AudioMorph] librosa audio decode failed: {librosa_err}")

    # Method 2: Blender aud module
    try:
        wav_path = _convert_via_blender_aud(audio_path)
        print(f"[AudioMorph] Audio converted to WAV via aud module: {wav_path}")
        return wav_path, True
    except Exception as aud_err:
        print(f"[AudioMorph] aud module decode failed: {aud_err}")

    # Method 3: Blender VSE mixdown (most compatible decoder path)
    print(f"[AudioMorph] Falling back to Blender VSE mixdown...")
    wav_path = _convert_via_vse_mixdown(audio_path)
    print(f"[AudioMorph] Audio converted to WAV via VSE mixdown: {wav_path}")
    return wav_path, True


def _convert_via_blender_aud(audio_path: str) -> str:
    """Convert audio to 16kHz mono WAV using Blender's built-in aud module."""
    import aud

    sound = aud.Sound.file(audio_path)

    fd, wav_path = tempfile.mkstemp(suffix='.wav')
    os.close(fd)

    try:
        channels = aud.CHANNELS_MONO
        fmt = aud.FORMAT_S16
        container = aud.CONTAINER_WAV
        codec = aud.CODEC_PCM
    except AttributeError:
        channels = aud.AUD_CHANNELS_MONO
        fmt = aud.AUD_FORMAT_S16
        container = aud.AUD_CONTAINER_WAV
        codec = aud.AUD_CODEC_PCM

    sound.write(wav_path, 16000, channels, fmt, container, codec)

    if not os.path.exists(wav_path) or os.path.getsize(wav_path) < 44:
        raise RuntimeError("aud.Sound.write produced an empty or invalid WAV file")

    # Verify and fix sample rate / channels
    with wave.open(wav_path, 'rb') as wf:
        sr = wf.getframerate()
        n_channels = wf.getnchannels()

    if sr != 16000 or n_channels != 1:
        import numpy as np
        import soundfile as sf
        from scipy.signal import resample as _scipy_resample

        audio, sr = sf.read(wav_path, dtype='float32')
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        if sr != 16000:
            new_len = int(len(audio) * 16000 / sr)
            audio = _scipy_resample(audio, new_len).astype(np.float32)
        sf.write(wav_path, audio, 16000, subtype='PCM_16')

    return wav_path


def _convert_via_vse_mixdown(audio_path: str) -> str:
    """Convert audio to 16kHz mono WAV using Blender's VSE mixdown.

    The VSE uses a different ffmpeg code path than the aud module, and can
    handle files with large ID3/junk headers that aud and librosa cannot.

    Requires a SEQUENCE_EDITOR area for the sound.mixdown operator.
    Temporarily converts an existing area if none is open.
    """
    window = bpy.context.window
    screen = window.screen

    # Find or temporarily create a sequencer area
    seq_area = None
    temp_area = None
    area_type_backup = None
    for area in screen.areas:
        if area.type == 'SEQUENCE_EDITOR':
            seq_area = area
            break
    if seq_area is None:
        for area in screen.areas:
            if area.type in ('VIEW_3D', 'CONSOLE', 'TEXT_EDITOR', 'OUTLINER'):
                temp_area = area
                area_type_backup = area.type
                area.type = 'SEQUENCE_EDITOR'
                seq_area = area
                break

    try:
        # Create a temporary scene so we don't touch the user's scene
        temp_scene = bpy.data.scenes.new(name="a2f_temp_audio")
        temp_scene.sequence_editor_create()

        strip = temp_scene.sequence_editor.sequences.new_sound(
            'a2f_temp', audio_path, channel=1, frame_start=1)

        strip_len = strip.frame_final_duration
        temp_scene.frame_start = 1
        temp_scene.frame_end = max(1, strip_len)

        # Configure output: WAV, mono, 48kHz (universally supported;
        # 16kHz may not be a valid enum value on all Blender versions)
        temp_scene.render.image_settings.file_format = 'WAV'
        temp_scene.render.audio_codec = 'PCM'
        temp_scene.render.audio_channels = 'MONO'
        temp_scene.render.audio_mixrate = 48000

        fd, raw_wav_path = tempfile.mkstemp(suffix='.wav')
        os.close(fd)
        temp_scene.render.filepath = raw_wav_path

        old_scene = window.scene
        window.scene = temp_scene
        try:
            # Find the WINDOW region of the sequencer area
            for region in seq_area.regions:
                if region.type == 'WINDOW':
                    with bpy.context.temp_override(
                        window=window,
                        scene=temp_scene,
                        area=seq_area,
                        region=region,
                    ):
                        bpy.ops.sound.mixdown()
                    break
            else:
                raise RuntimeError("No WINDOW region found in sequencer area")
        finally:
            window.scene = old_scene

        bpy.data.scenes.remove(temp_scene)

        # Verify the output file
        if not os.path.exists(raw_wav_path) or os.path.getsize(raw_wav_path) < 44:
            raise RuntimeError("VSE mixdown produced an empty or invalid WAV file")

        # Resample from 48kHz to 16kHz
        import numpy as np
        import soundfile as sf
        from scipy.signal import resample as _scipy_resample

        audio, sr = sf.read(raw_wav_path, dtype='float32')
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        if sr != 16000:
            new_len = int(len(audio) * 16000 / sr)
            audio = _scipy_resample(audio, new_len).astype(np.float32)
        sf.write(raw_wav_path, audio, 16000, subtype='PCM_16')

        return raw_wav_path
    finally:
        # Restore area type if we temporarily changed it
        if temp_area is not None:
            temp_area.type = area_type_backup


def _build_weight_multipliers(props) -> dict[str, float]:
    """Build per-blendshape weight multipliers from UI properties.

    The channel grouping and the damping/base recipe (0.7 / 0.8 / 0.15 / 0.4)
    live in the compiled C++ engine (a2f_engine.build_weight_multipliers) to
    protect the IP. This wrapper reads the UI props and delegates.
    """
    params = {
        "jaw_open_multiplier": float(getattr(props, "jaw_open_multiplier", 1.0)),
        "mouth_close_multiplier": float(getattr(props, "mouth_close_multiplier", 1.0)),
        "jaw_left_right_multiplier": float(getattr(props, "jaw_left_right_multiplier", 1.0)),
        "mouth_roll_lower_multiplier": float(getattr(props, "mouth_roll_lower_multiplier", 1.0)),
        "mouth_shrug_lower_multiplier": float(getattr(props, "mouth_shrug_lower_multiplier", 1.0)),
        "mouth_lower_down_multiplier": float(getattr(props, "mouth_lower_down_multiplier", 1.0)),
        "mouth_roll_upper_multiplier": float(getattr(props, "mouth_roll_upper_multiplier", 1.0)),
        "mouth_shrug_upper_multiplier": float(getattr(props, "mouth_shrug_upper_multiplier", 1.0)),
        "mouth_upper_up_multiplier": float(getattr(props, "mouth_upper_up_multiplier", 1.0)),
    }
    try:
        import a2f_engine as _native
        return _native.build_weight_multipliers(params)
    except Exception as e:
        print(f"[AudioMorph] C++ engine unavailable ({e}); using identity multipliers")
        return {}


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _copy_frame(frame, weights: Dict[str, float] | None = None, time: float | None = None):
    from ..core.blendshape import BlendshapeFrame
    return BlendshapeFrame(
        time=frame.time if time is None else time,
        weights=dict(frame.weights if weights is None else weights),
        emotions=getattr(frame, "emotions", None),
    )


def _lerp_weights(a: Dict[str, float], b: Dict[str, float], factor: float) -> Dict[str, float]:
    names = set(a.keys()) | set(b.keys())
    return {
        name: a.get(name, 0.0) * (1.0 - factor) + b.get(name, 0.0) * factor
        for name in names
    }


def _sample_frame_weights(frames: List[Any], source_time: float) -> Dict[str, float]:
    if not frames:
        return {}
    if source_time <= frames[0].time:
        return dict(frames[0].weights)
    if source_time >= frames[-1].time:
        return dict(frames[-1].weights)

    # Frames are uniformly generated, so a short linear scan is enough for the
    # clip sizes this operator handles and avoids assumptions after resampling.
    for i in range(1, len(frames)):
        prev_frame = frames[i - 1]
        next_frame = frames[i]
        if source_time <= next_frame.time:
            span = max(1e-6, next_frame.time - prev_frame.time)
            factor = (source_time - prev_frame.time) / span
            return _lerp_weights(prev_frame.weights, next_frame.weights, factor)
    return dict(frames[-1].weights)


def _apply_prediction_delay(frames: List[Any], delay_seconds: float) -> List[Any]:
    """Shift mouth-shape channels by a prediction delay.

    The mouth-shape channel set, lerp sampling and per-channel override run
    in the compiled C++ engine (a2f_engine.apply_prediction_delay). Emotions
    are preserved.
    """
    if not frames or abs(delay_seconds) < 1e-4:
        return frames
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_prediction_delay(frames_dicts, float(delay_seconds))
        return [
            _copy_frame(fr, weights=rd["weights"])
            for fr, rd in zip(frames, result)
        ]
    except Exception as e:
        print(f"[AudioMorph] Prediction delay skipped: C++ engine unavailable ({e})")
        return frames


def _apply_eye_controls(frames: List[Any], props, utterances=None) -> List[Any]:
    if not frames:
        return frames

    params = {
        "eyeballs_strength": float(getattr(props, "eyeballs_strength", 1.0)),
        "saccade_strength": float(getattr(props, "saccade_strength", 0.0)),
        "blink_interval": float(getattr(props, "blink_interval", 0.0)),
        "blink_strength": float(getattr(props, "blink_strength", 1.0)),
    }

    boundary_times: List[float] = []
    if utterances:
        try:
            for u in utterances:
                start_t = getattr(u, "start_time", None)
                if start_t is not None:
                    boundary_times.append(float(start_t))
        except Exception:
            boundary_times = []

    # The eye-channel sets, saccade generator (fixed-seed MT19937), drift
    # model and blink recipe run in the compiled C++ engine.
    try:
        import a2f_engine as _native
        frames_dicts = [
            {"time": float(f.time), "weights": dict(f.weights)}
            for f in frames
        ]
        result = _native.apply_eye_controls(frames_dicts, params, boundary_times)
        return [
            _copy_frame(fr, weights=rd["weights"])
            for fr, rd in zip(frames, result)
        ]
    except Exception as e:
        print(f"[AudioMorph] Eye controls skipped: C++ engine unavailable ({e})")
        return frames




def _apply_advanced_controls(frames: List[Any], props, utterances=None) -> List[Any]:
    frames = _apply_prediction_delay(frames, getattr(props, "prediction_delay", 0.0))
    frames = _apply_eye_controls(frames, props, utterances=utterances)
    # Emotion vectors are disabled (NVIDIA emotion inference produces poor
    # results). emotion_vectors is always None in _process_with_sdk.
    return frames


class AUDIO2FACE_OT_generate(bpy.types.Operator):
    bl_idname = "audiomorph.generate"
    bl_label = t("Generate Animation")
    bl_description = t("Generate facial animation from audio")
    bl_options = {'REGISTER', 'UNDO'}

    def _run_asr(self, props, audio_path):
        """Run ASR recognition (shared by emotion recognition and phoneme correction)

        Returns:
            (utterances, task_resp)
            Returns (None, None) if ASR fails
        """
        try:
            print("[AudioMorph] ASR: starting recognition...")
            import time as _time
            _t_init = _time.time()
            analyzer = SpeechAnalyzer()
            print(f"[AudioMorph] ⏱ ASR SpeechAnalyzer init: {_time.time() - _t_init:.2f}s")

            def _asr_callback(progress, message):
                print(f"[AudioMorph] ASR {progress}%: {message}")

            _t_recog = _time.time()
            utterances, task_resp = analyzer.recognize(audio_path, callback=_asr_callback)
            print(f"[AudioMorph] ⏱ ASR recognize: {_time.time() - _t_recog:.2f}s")

            if not utterances:
                print("[AudioMorph] ASR returned no results")
                self.report({'WARNING'}, tr("ASR returned no results"))
                return None, None

            text_preview = analyzer.asr.get_text(utterances)[:50]
            print(f"[AudioMorph] ASR done: {len(utterances)} utterances, text='{text_preview}'")
            return utterances, task_resp

        except Exception as e:
            import traceback
            print(f"[AudioMorph] ASR failed: {e}")
            traceback.print_exc()
            self.report({'WARNING'}, tr("ASR failed") + f": {e}")
            return None, None

    def _apply_phoneme_correction(self, frames, props, audio_path, utterances=None, task_resp=None, fps=None):
        """Perform phoneme correction

        Flow:
        1. ASR recognition -> character-level timestamps (reuse precomputed results or re-recognize)
        2. Text -> pinyin -> phoneme sequence
        3. Model inference results + phonemes -> fusion correction

        Returns:
            (corrected_frames, phoneme_data)
            Returns (original frames, None) if ASR fails
        """
        try:
            # 1. ASR recognition (reuse precomputed results)
            if utterances is not None and task_resp is not None:
                print("[AudioMorph] Phoneme correction: reusing ASR results")
                analyzer = SpeechAnalyzer()
            else:
                print("[AudioMorph] Phoneme correction: starting ASR recognition...")
                analyzer = SpeechAnalyzer()

                def _asr_callback(progress, message):
                    print(f"[AudioMorph] ASR {progress}%: {message}")

                utterances, task_resp = analyzer.recognize(audio_path, callback=_asr_callback)

                if utterances:
                    text_preview = analyzer.asr.get_text(utterances)[:50]
                    print(f"[AudioMorph] ASR done: {len(utterances)} utterances, text='{text_preview}'")

            if not utterances:
                print("[AudioMorph] Phoneme correction skipped: ASR returned no results")
                self.report({'WARNING'}, tr("Phoneme correction skipped: ASR failed"))
                return frames, None

            # 3. Extract phoneme sequence
            import time as _time
            _t_ph_start = _time.time()
            phonemes = analyzer.get_phonemes_from_chars(task_resp)
            if not phonemes:
                # Character-level timestamps unavailable, use utterance-level
                phonemes = analyzer.get_phonemes_from_text('', utterances)
            print(f"[AudioMorph] ⏱ Phoneme extraction: {_time.time() - _t_ph_start:.2f}s ({len(phonemes) if phonemes else 0} segments)")

            if not phonemes:
                print("[AudioMorph] Phoneme correction skipped: no phonemes extracted")
                return frames, None

            print(f"[AudioMorph] Phonemes extracted: {len(phonemes)} segments")

            # 4. Fusion correction
            _t_correct_start = _time.time()
            corrector = PhonemeCorrector()
            frames_list = [
                {'time': f.time, 'weights': f.weights}
                for f in frames
            ]

            corrected = corrector.correct_frames(
                model_frames=frames_list,
                fps=fps if fps is not None else 30,
                phonemes=phonemes,
                correction_strength=props.phoneme_correction_strength,
                frame_offset=0,  # Phoneme times are based on audio 0s, consistent with frames' time
            )
            print(f"[AudioMorph] ⏱ Corrector.correct_frames: {_time.time() - _t_correct_start:.2f}s")

            # Convert back to BlendshapeFrame
            _t_convert_start = _time.time()
            from ..core.blendshape import BlendshapeFrame
            result = [
                BlendshapeFrame(time=f['time'], weights=f['weights'])
                for f in corrected
            ]
            print(f"[AudioMorph] ⏱ Convert to BlendshapeFrame: {_time.time() - _t_convert_start:.2f}s")

            print(f"[AudioMorph] Phoneme correction applied: strength={props.phoneme_correction_strength:.2f}")
            self.report({'INFO'}, tr("Phoneme correction applied"))
            return result, phonemes

        except Exception as e:
            import traceback
            print(f"[AudioMorph] Phoneme correction failed: {e}")
            traceback.print_exc()
            self.report({'WARNING'}, tr("Phoneme correction failed") + f": {e}")
            return frames, None

    def _process_with_sdk(self, props, utterances=None, fps=None, audio_path=None):
        from ..core.a2f_sdk import A2FContext
        from ..core.blendshape import BlendshapeFrame
        import tempfile

        if not os.path.isfile(_SDK_MODEL_PATH):
            raise FileNotFoundError(
                f"Model file not found: {_SDK_MODEL_PATH}\n"
                "Please make sure the model files are properly installed."
            )

        print(f"[AudioMorph SDK] Using local SDK inference...")

        import time as _time
        _t_load_start = _time.time()
        # Use provided audio_path or fall back to props.audio_file
        if audio_path is None:
            audio_path = props.audio_file

        # Ensure we have a 16kHz mono WAV (handles MP3 without system ffmpeg)
        wav_path, is_temp = _ensure_wav_audio(audio_path)

        try:
            samples = _load_audio_wav(wav_path)
        finally:
            if is_temp and os.path.exists(wav_path):
                os.remove(wav_path)
        print(f"[AudioMorph] ⏱ SDK audio load: {_time.time() - _t_load_start:.2f}s")

        print(f"[AudioMorph SDK] Audio: {len(samples)} samples ({len(samples)/16000:.2f}s)")
        _t_ctx_start = _time.time()
        with A2FContext(_SDK_MODEL_PATH) as ctx:
            _t_ctx_init = _time.time() - _t_ctx_start
            print(f"[AudioMorph] ⏱ SDK A2FContext init: {_t_ctx_init:.2f}s")

            _t_infer_start = _time.time()
            frames_raw = ctx.process_audio(
                samples,
                emotion_vectors=None,
                input_strength=props.input_strength,
                upper_face_strength=props.upper_face_strength,
                lower_face_strength=props.lower_face_strength,
                upper_face_smoothing=props.upper_face_smoothing,
                lower_face_smoothing=props.lower_face_smoothing,
                skin_strength=props.skin_strength,
                blink_strength=props.blink_strength,
                lip_open_offset=props.lip_open_offset,
                tongue_strength=props.tongue_strength,
            )
            print(f"[AudioMorph] ⏱ SDK process_audio: {_time.time() - _t_infer_start:.2f}s")

        _t_build_start = _time.time()
        import a2f_engine as _native
        multipliers = _build_weight_multipliers(props)

        sdk_fps = 60.0
        step_s = 1.0 / sdk_fps
        result = []
        # Performance: convert the WHOLE clip in a single engine call instead
        # of one map_sdk_output JSON round trip per frame (3600 frames = 3600
        # ctypes calls + buffer allocs). The batch result is one named-weight
        # dict per frame, in the same order as frames_raw.
        _t_batch_start = _time.time()
        named_batch = _native.map_sdk_output_batch(frames_raw, multipliers)
        print(f"[AudioMorph] ⏱ SDK map batch: {_time.time() - _t_batch_start:.2f}s")
        for i, named in enumerate(named_batch):
            bf = BlendshapeFrame(time=i * step_s, weights=named)
            result.append(bf)
        print(f"[AudioMorph] ⏱ SDK build frames: {_time.time() - _t_build_start:.2f}s")

        if fps != 60:
            _t_resample_start = _time.time()
            result = self._resample_frames(result, fps)
            print(f"[AudioMorph] ⏱ SDK resample: {_time.time() - _t_resample_start:.2f}s")

        _t_adv_start = _time.time()
        result = _apply_advanced_controls(result, props, utterances=utterances)
        print(f"[AudioMorph] ⏱ SDK advanced controls: {_time.time() - _t_adv_start:.2f}s")

        print(f"[AudioMorph SDK] Output: {len(result)} frames at {fps}fps")
        return result

    def _resample_frames(self, frames: list, target_fps: float) -> list:
        from ..core.blendshape import BlendshapeFrame
        if not frames:
            return frames
        source_fps = 60.0
        if abs(target_fps - source_fps) < 0.01:
            return frames

        # Use integer frame index to avoid floating-point accumulation drift.
        # Repeated `t += step_dst` accumulates error (e.g. after 60 steps of
        # 1/30, t = 1.9999999999999998 instead of 2.0), which can produce
        # one extra or one missing frame at the end and shift the reported
        # seg_end off by one.
        result = []
        step_dst = 1.0 / target_fps
        max_time = frames[-1].time
        # Number of destination frames that fit within [0, max_time].
        # The +0.5 tolerance accounts for the source data ending exactly
        # on a frame boundary.
        n_dst = int(max_time * target_fps + 0.5) + 1
        for i in range(n_dst):
            t = i * step_dst
            named = _sample_frame_weights(frames, t)
            result.append(BlendshapeFrame(time=t, weights=named))
        return result

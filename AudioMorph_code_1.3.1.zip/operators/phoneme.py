"""Phoneme correction helpers shared with the DAZ page operators.

Provides module-level functions reused by daz/daz_phoneme.py:
- _regenerate_and_refuse_from_edited_text
- _forced_align_and_refuse_from_edited_text
- _refuse_from_chars_data

Plus the registered operator AUDIO2FACE_OT_add_char_end_marker.
"""

import os
import bpy

from ..utils.i18n import t, tr


def _rebuild_frames_from_cache():
    """Take the original inference results from AnimationCache and convert them back to a BlendshapeFrame list.

    Returns:
        (frames_list, fps, frame_offset) or (None, 0, 0)
    """
    from ..core.animation_cache import AnimationCache
    from ..core.blendshape import BlendshapeFrame

    if not AnimationCache.has_original_data():
        return None, 0, 0

    raw = AnimationCache.get_original_frames()
    if not raw:
        return None, 0, 0

    frames = []
    for item in raw:
        # store_original_frames stores a dict {'time':..,'weights':..}
        if isinstance(item, dict):
            frames.append(BlendshapeFrame(time=item['time'], weights=dict(item['weights'])))
        else:
            # Compatible with the case of directly passing BlendshapeFrame
            frames.append(BlendshapeFrame(time=item.time, weights=dict(item.weights)))

    fps = AnimationCache.get_fps()
    frame_offset = AnimationCache.get_phoneme_frame_offset()
    return frames, fps, frame_offset


def _refuse_with_phonemes(frames, props):
    """Fuse phonemes into frames with the current strength and return the new fused frames list.

    On failure returns the original frames (conservative degradation, keeps UI responsive).
    """
    from ..core.animation_cache import AnimationCache
    from ..core.phoneme_correction import PhonemeCorrector
    from ..core.blendshape import BlendshapeFrame

    phonemes = AnimationCache.get_phoneme_data()
    if not phonemes:
        # No phoneme data, cannot fuse, return as-is
        return frames

    corrector = PhonemeCorrector()
    frames_list = [
        {'time': f.time, 'weights': f.weights}
        for f in frames
    ]
    corrected = corrector.correct_frames(
        model_frames=frames_list,
        fps=AnimationCache.get_fps(),
        phonemes=phonemes,
        correction_strength=props.phoneme_correction_strength,
        frame_offset=0,
    )
    return [
        BlendshapeFrame(time=f['time'], weights=f['weights'])
        for f in corrected
    ]


def _regenerate_and_refuse_from_edited_text(props):
    """Regenerate phoneme data from user-edited ASR text and re-fuse.

    Uses the original char-level timestamps (1:1 if char count matches,
    proportional fallback otherwise). Updates AnimationCache._phoneme_data
    in place so subsequent strength adjustments use the new phonemes.

    Returns (fused_frames, fps, frame_offset, chars_data) or
    (None, 0, 0, None) on failure. chars_data is the list of
    {'char', 'start', 'end'} dicts for timeline marker creation.
    """
    from ..core.animation_cache import AnimationCache
    from ..core.phoneme_correction.speech_analyzer import SpeechAnalyzer
    from ..core.phoneme_correction.local_asr import LocalASR

    edited_text = props.asr_recognized_text
    if not edited_text:
        return None, 0, 0, None

    # Regenerate phonemes from edited text (reuses original timestamps)
    analyzer = SpeechAnalyzer()
    new_phonemes = analyzer.get_phonemes_from_edited_text(edited_text)
    if not new_phonemes:
        print("[AudioMorph] Edited text: no phonemes generated")
        return None, 0, 0, None

    print(f"[AudioMorph] Edited text: regenerated {len(new_phonemes)} phoneme segments")

    # Build chars_data for timeline marker creation.
    # When char count matches (1:1 replacement), reuse original timestamps
    # with the new characters from edited_text.
    original_chars = LocalASR._shared_chars
    edited_chars = [c for c in edited_text if analyzer._is_chinese_char(c)]
    chars_data = []
    if original_chars and len(edited_chars) == len(original_chars):
        for orig, new_char in zip(original_chars, edited_chars):
            chars_data.append({
                'char': new_char,
                'start': orig['start'],
                'end': orig['end'],
            })
    elif original_chars:
        # Char count mismatch: use original chars as-is (proportional
        # distribution was already applied internally). Markers will
        # reflect original timestamps; user can use Force Align instead.
        chars_data = [
            {'char': c['char'], 'start': c['start'], 'end': c['end']}
            for c in original_chars
        ]

    # Update cached phoneme data in place so future strength adjustments
    # and lip-repair operations use the corrected phonemes.
    AnimationCache._phoneme_data = new_phonemes

    # Rebuild baseline frames and re-fuse with new phonemes
    frames, fps, frame_offset = _rebuild_frames_from_cache()
    if frames is None:
        return None, 0, 0, None

    fused = _refuse_with_phonemes(frames, props)
    return fused, fps, frame_offset, chars_data


def _forced_align_and_refuse_from_edited_text(props, audio_path):
    """Run CTC forced alignment on user-edited text, then re-fuse animation.

    Unlike _regenerate_and_refuse_from_edited_text (which reuses original
    timestamps and only works well when char count matches), this function
    runs the SenseVoice model directly via ONNX Runtime to extract the CTC
    emission matrix, then performs Viterbi forced alignment between the
    corrected text and the audio. This produces accurate per-character
    timestamps even when the original ASR dropped characters.

    Use this when the user added/removed characters to fix ASR errors
    (e.g. fast songs where ASR missed syllables). Use the regular
    "Apply Edited Text" button only for same-count character fixes.

    Args:
        props: scene properties (must have asr_recognized_text)
        audio_path: path to the audio file for alignment

    Returns (fused_frames, fps, frame_offset, aligned_chars) or
    (None, 0, 0, None) on failure. aligned_chars is the list of
    {'char', 'start', 'end'} dicts for timeline marker creation.
    """
    from ..core.animation_cache import AnimationCache
    from ..core.phoneme_correction.forced_aligner import (
        forced_align, align_to_phoneme_segments,
    )

    edited_text = props.asr_recognized_text
    if not edited_text:
        return None, 0, 0, None

    if not audio_path or not os.path.isfile(audio_path):
        print("[AudioMorph] Forced align: audio file not found")
        return None, 0, 0, None

    print(f"[AudioMorph] Forced align: aligning edited text to {audio_path}")
    aligned_chars = forced_align(audio_path, edited_text, callback=None)
    if not aligned_chars:
        print("[AudioMorph] Forced align: no alignment result")
        return None, 0, 0, None

    print(f"[AudioMorph] Forced align: aligned {len(aligned_chars)} chars")

    # Debug: print first 10 and last 5 char timestamps for precision verification
    _debug_count = min(10, len(aligned_chars))
    for i in range(_debug_count):
        c = aligned_chars[i]
        dur_ms = (c['end'] - c['start']) * 1000
        print(f"  [{i}] '{c['char']}' start={c['start']:.3f}s end={c['end']:.3f}s dur={dur_ms:.0f}ms")
    if len(aligned_chars) > 15:
        print(f"  ... ({len(aligned_chars) - 15} more chars) ...")
        for i in range(len(aligned_chars) - 5, len(aligned_chars)):
            c = aligned_chars[i]
            dur_ms = (c['end'] - c['start']) * 1000
            print(f"  [{i}] '{c['char']}' start={c['start']:.3f}s end={c['end']:.3f}s dur={dur_ms:.0f}ms")

    # Convert aligned chars to PhonemeSegment list (reuses SpeechAnalyzer's
    # _char_to_phonemes so compound final splitting, initial duration
    # factors, and bilabial/labiodental protections all apply identically)
    new_phonemes = align_to_phoneme_segments(aligned_chars)
    if not new_phonemes:
        print("[AudioMorph] Forced align: no phonemes generated")
        return None, 0, 0, None

    print(f"[AudioMorph] Forced align: generated {len(new_phonemes)} phoneme segments")

    # Update cached phoneme data in place
    AnimationCache._phoneme_data = new_phonemes

    # Rebuild baseline frames and re-fuse with new phonemes
    frames, fps, frame_offset = _rebuild_frames_from_cache()
    if frames is None:
        return None, 0, 0, None

    fused = _refuse_with_phonemes(frames, props)
    return fused, fps, frame_offset, aligned_chars


def _refuse_from_chars_data(props, chars_data):
    """Regenerate phonemes from marker-derived chars_data and re-fuse.

    Used by the "Fix Timestamps from Markers" operator. Reads the
    user-adjusted character timestamps from timeline markers, rebuilds
    phoneme segments via align_to_phoneme_segments (same compound final
    splitting and initial duration logic), then re-fuses with the cached
    original inference frames.

    Args:
        props: scene properties (for correction_strength)
        chars_data: list of {'char', 'start', 'end'} dicts (seconds)

    Returns (fused_frames, fps, frame_offset) or (None, 0, 0) on failure.
    """
    from ..core.animation_cache import AnimationCache
    from ..core.phoneme_correction.forced_aligner import align_to_phoneme_segments

    if not chars_data:
        return None, 0, 0

    new_phonemes = align_to_phoneme_segments(chars_data)
    if not new_phonemes:
        print("[AudioMorph] Fix timestamps: no phonemes generated from markers")
        return None, 0, 0

    print(f"[AudioMorph] Fix timestamps: generated {len(new_phonemes)} phoneme segments")

    AnimationCache._phoneme_data = new_phonemes

    frames, fps, frame_offset = _rebuild_frames_from_cache()
    if frames is None:
        return None, 0, 0

    fused = _refuse_with_phonemes(frames, props)
    return fused, fps, frame_offset


class AUDIO2FACE_OT_add_char_end_marker(bpy.types.Operator):
    """Add an end marker for the selected A2F start marker at the current frame.

    Select a start marker in the timeline (the character whose end you want
    to mark), move the playhead to the desired end position, then click this
    button. A new end marker is created. Characters with an end marker will
    create a silence gap after the end (mouth relaxes to neutral), instead
    of transitioning directly to the next character.

    The end marker frame must be within the scene frame range and after the
    start marker's frame.
    """
    bl_idname = "audiomorph.add_char_end_marker"
    bl_label = t("Add End Marker")
    bl_description = t("Add an end marker for the selected start marker at the current frame. Creates a silence gap after this character.")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        from ..core.timeline_markers import get_selected_a2f_start_marker
        return get_selected_a2f_start_marker(context.scene) is not None

    def execute(self, context):
        scene = context.scene
        from ..core.timeline_markers import get_selected_a2f_start_marker, add_end_marker

        selected_name = get_selected_a2f_start_marker(scene)
        if not selected_name:
            self.report({'ERROR'}, tr("No A2F start marker selected in timeline"))
            return {'CANCELLED'}

        start_marker = scene.timeline_markers.get(selected_name)
        if start_marker is None:
            self.report({'ERROR'}, tr("Selected marker not found"))
            return {'CANCELLED'}

        current_frame = scene.frame_current
        # Validate: end frame must be after start frame
        if current_frame <= start_marker.frame:
            self.report({'ERROR'}, tr("Current frame must be after the start marker frame"))
            return {'CANCELLED'}

        # Validate: end frame must be within scene frame range
        if not (scene.frame_start <= current_frame <= scene.frame_end):
            self.report({'ERROR'}, tr("Current frame must be within the timeline frame range"))
            return {'CANCELLED'}

        ok = add_end_marker(scene, selected_name, current_frame)
        if not ok:
            self.report({'ERROR'}, tr("Failed to add end marker"))
            return {'CANCELLED'}

        self.report({'INFO'}, tr("End marker added at frame %d") % current_frame)
        print(f"[AudioMorph] End marker added for '{selected_name}' at frame {current_frame}")
        return {'FINISHED'}


classes = [
    AUDIO2FACE_OT_add_char_end_marker,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
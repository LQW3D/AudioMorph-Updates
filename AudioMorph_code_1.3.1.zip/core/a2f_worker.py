#!/usr/bin/env python
"""AudioMorph SDK Worker - runs in subprocess to avoid onnxruntime conflicts in Blender 5.0.

Reads audio samples and emotion vectors from .npy files (binary, fast),
runs ONNX inference, and writes blendshape weights to .npy file.
Metadata (frame_count, providers) is written to a small JSON file.

All progress/timing logs go to stderr (stdout is reserved for future JSON output).
The parent process (a2f_sdk.py) forwards stderr to Blender console in real time.
"""

import sys
import os
import json
import time
import argparse

def _log(msg):
    """Log to stderr with timestamp (parent process forwards to Blender console)."""
    t = time.time() - _T0
    print(f"[A2F-Worker {t:7.2f}s] {msg}", file=sys.stderr, flush=True)

_T0 = time.time()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_dir', required=True)
    parser.add_argument('--samples', required=True)   # .npy path
    parser.add_argument('--emotion', required=True)    # .npy path
    parser.add_argument('--output', required=True)     # .npy path for weights
    parser.add_argument('--meta', required=True)       # .json path for metadata
    args = parser.parse_args()

    _log(f"Worker started, pid={os.getpid()}")

    # __file__ = <addon_dir>/core/a2f_worker.py
    # Two levels up is the plugin root directory (do not assume the plugin folder name)
    addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # Read device_config.json for device configuration (keep consistent with the
    # main process). The main process passes the resolved config path (which
    # lives in Blender's user config dir) via A2F_DEVICE_CONFIG; this subprocess
    # cannot import bpy, so it falls back to the addon-root file for standalone
    # runs.
    env_cfg_path = os.environ.get("A2F_DEVICE_CONFIG")
    config_path = env_cfg_path if env_cfg_path else os.path.join(addon_dir, "device_config.json")
    device_config = None
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            device_config = json.load(f)
    except Exception:
        pass

    if device_config is None:
        # Config file missing, fall back to CPU
        py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
        if py_version == "cp313":
            pylibs_dir = os.path.join(addon_dir, "deps", "pylibs_cp313")
        elif py_version == "cp311":
            pylibs_dir = os.path.join(addon_dir, "deps", "pylibs")
        else:
            _log(f"Unsupported Python version {py_version}: AudioMorph "
                 f"requires Blender 4.x (Python 3.11) or 5.x (Python 3.13)")
            sys.exit(1)
        pylibs_cpu_dir = pylibs_dir
        _log(f"No device_config.json, using CPU fallback: {pylibs_dir}")
    else:
        # Read the pylibs directory from the config file
        pylibs_dir_name = device_config.get("pylibs_dir", "pylibs")
        pylibs_dir = os.path.join(addon_dir, "deps", pylibs_dir_name)
        # CPU pylibs (for numpy/scipy/llvmlite)
        py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
        if py_version == "cp313":
            pylibs_cpu_dir = os.path.join(addon_dir, "deps", "pylibs_cp313")
        elif py_version == "cp311":
            pylibs_cpu_dir = os.path.join(addon_dir, "deps", "pylibs")
        else:
            _log(f"Unsupported Python version {py_version}: AudioMorph "
                 f"requires Blender 4.x (Python 3.11) or 5.x (Python 3.13)")
            sys.exit(1)
        _log(f"Device config: {device_config.get('device_type', 'cpu')} | "
             f"Provider: {device_config.get('provider', 'CPUExecutionProvider')} | "
             f"pylibs: {pylibs_dir_name}")

    # Set up sys.path: main pylibs first, CPU pylibs supplements dependencies
    if pylibs_dir not in sys.path:
        sys.path.insert(0, pylibs_dir)
    if pylibs_dir != pylibs_cpu_dir and pylibs_cpu_dir not in sys.path:
        sys.path.append(pylibs_cpu_dir)

    # Register ONNX Runtime DLL path (required on Windows)
    ort_capi_dir = os.path.join(pylibs_dir, "onnxruntime", "capi")
    if os.path.isdir(ort_capi_dir) and hasattr(os, "add_dll_directory"):
        os.add_dll_directory(ort_capi_dir)
    # Register other native library paths
    for libs_subdir in ("numpy.libs", "scipy.libs", "llvmlite.libs"):
        libs_dir = os.path.join(pylibs_cpu_dir, libs_subdir)
        if os.path.isdir(libs_dir) and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(libs_dir)

    # Ensure the plugin root is importable: a2f_onnx.py does a top-level
    # `import a2f_engine` (the .pyd lives at the addon root), and the
    # subprocess sys.path so far only contains the pylibs dirs. Without the
    # addon root on sys.path, every subprocess load raises ImportError and
    # generation fails (see asr_worker/forced_align_worker for the same fix).
    if addon_dir not in sys.path:
        sys.path.insert(0, addon_dir)

    import importlib.util
    a2f_onnx_path = os.path.join(addon_dir, 'core', 'a2f_onnx.py')
    _log(f"Loading a2f_onnx from: {a2f_onnx_path}")
    spec = importlib.util.spec_from_file_location("a2f_onnx", a2f_onnx_path)
    a2f_onnx = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(a2f_onnx)

    ctx = None
    try:
        import numpy as np

        A2FOnnxContext = a2f_onnx.A2FOnnxContext

        # Load audio data from binary .npy (keep as numpy array, avoid .tolist() overhead)
        _log("Loading audio samples...")
        t0 = time.time()
        samples_arr = np.load(args.samples)
        _log(f"Loaded samples: shape={samples_arr.shape}, dtype={samples_arr.dtype}, {time.time()-t0:.2f}s")

        _log("Loading emotion vectors...")
        t0 = time.time()
        emotion_arr = np.load(args.emotion)
        emotion_vectors = emotion_arr if emotion_arr.size > 0 else None
        _log(f"Loaded emotion: shape={emotion_arr.shape}, {time.time()-t0:.2f}s")

        _log(f"Creating A2FOnnxContext(model_dir={args.model_dir})...")
        t0 = time.time()
        ctx = A2FOnnxContext(args.model_dir)
        _log(f"Context created (model loaded): {time.time()-t0:.2f}s")

        _log(f"Calling ctx.process_audio(samples_len={len(samples_arr)})...")
        t0 = time.time()
        # Pass numpy array directly (avoid .tolist() -> np.asarray round-trip)
        result = ctx.process_audio(samples_arr, emotion_vectors=emotion_vectors)
        _log(f"process_audio done: {time.time()-t0:.2f}s, result_type={type(result).__name__}")

        _log("Saving output weights...")
        t0 = time.time()
        # Save directly from numpy array (avoid .tolist() overhead)
        result_arr = np.asarray(result, dtype=np.float32)
        np.save(args.output, result_arr)
        _log(f"Saved output: shape={result_arr.shape}, {time.time()-t0:.2f}s")

        # Save metadata as small JSON
        meta = {
            'success': True,
            'frame_count': ctx.frame_count,
            'weight_count': ctx.weight_count,
            'providers': ctx.providers,
        }

        _log("Worker completed successfully")

    except Exception as e:
        import traceback
        _log(f"ERROR: {e}")
        _log(traceback.format_exc())
        meta = {
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
        }
    finally:
        if ctx is not None:
            try:
                ctx.close()
            except Exception:
                pass

    with open(args.meta, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    main()

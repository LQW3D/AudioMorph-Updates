"""Device detection module.

Auto-detects the best available execution provider (GPU/CPU) for ONNX Runtime.
Detection result is cached in device_config.json for fast subsequent startups.

Detection strategy:
    1. Check if DirectML package exists (pylibs_dml / pylibs_cp313_dml)
    2. Try import onnxruntime and check get_available_providers()
    3. Try create a minimal InferenceSession to verify GPU is really usable
    4. If all pass -> use DmlExecutionProvider
    5. If any step fails -> fall back to CPUExecutionProvider

Config file: <addon_dir>/device_config.json
    {
        "device_type": "directml" | "cpu",
        "provider": "DmlExecutionProvider" | "CPUExecutionProvider",
        "pylibs_dir": "pylibs_dml" | "pylibs" (relative to addon_dir),
        "onnxruntime_version": "1.19.2",
        "last_check": "2026-07-21T12:00:00"
    }

For distribution: delete device_config.json before packaging.
Each user's first startup will auto-detect and generate their own config.
"""

import os
import sys
import json
import platform
from datetime import datetime

# Config file name (stored in addon root directory)
CONFIG_FILE = "device_config.json"


def _get_addon_dir():
    """Get addon root directory (parent of core/)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _get_config_path():
    """Get full path to device_config.json.

    The config is per-user state, so it lives in Blender's user config
    directory (survives addon updates and works in read-only installs).
    Subprocess workers receive the resolved path via the A2F_DEVICE_CONFIG
    environment variable (they cannot import bpy). Falls back to the addon
    root when no Blender context is available.
    """
    env_path = os.environ.get("A2F_DEVICE_CONFIG")
    if env_path:
        return env_path
    try:
        import bpy
        user_cfg = bpy.utils.user_resource('CONFIG')
        if user_cfg:
            return os.path.join(user_cfg, CONFIG_FILE)
    except Exception:
        pass
    return os.path.join(_get_addon_dir(), CONFIG_FILE)


def _get_pylibs_candidates():
    """Get (pylibs_dir, pylibs_dml_dir) candidates based on Python version.

    Only Python 3.11 (Blender 4.x) and 3.13 (Blender 5.x) are supported.
    Any other version raises immediately instead of silently loading a
    binary built for a different ABI (which would crash on import).

    Returns:
        tuple: (pylibs_dir_abs, pylibs_dml_dir_abs)
    """
    addon_dir = _get_addon_dir()
    py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"

    if py_version == "cp313":
        pylibs_dir = os.path.join(addon_dir, "deps", "pylibs_cp313")
        pylibs_dml_dir = os.path.join(addon_dir, "deps", "pylibs_cp313_dml")
    elif py_version == "cp311":
        pylibs_dir = os.path.join(addon_dir, "deps", "pylibs")
        pylibs_dml_dir = os.path.join(addon_dir, "deps", "pylibs_dml")
    else:
        raise RuntimeError(
            f"AudioMorph supports Blender 4.x (Python 3.11) and "
            f"Blender 5.x (Python 3.13) only; detected Python "
            f"{py_version}. Please use a supported Blender version."
        )

    return pylibs_dir, pylibs_dml_dir


def _try_detect_directml():
    """Try to detect DirectML availability.

    Returns:
        dict or None: detection result if successful, None if failed
    """
    pylibs_dir, pylibs_dml_dir = _get_pylibs_candidates()

    # Step 1: Check if DirectML package exists
    dml_onnxruntime_dir = os.path.join(pylibs_dml_dir, "onnxruntime")
    if not os.path.isdir(dml_onnxruntime_dir):
        return None

    # Step 2: Temporarily add DML path and try import
    # Note: onnxruntime can only be imported once per process, so if CPU version
    # was already imported, we can't re-import DML version. In that case, we
    # rely on the config file from previous detection.
    if "onnxruntime" in sys.modules:
        # Already imported (probably CPU version), can't re-import
        # Check if current onnxruntime has DML provider
        try:
            import onnxruntime as ort
            providers = ort.get_available_providers()
            if "DmlExecutionProvider" in providers:
                return {
                    "device_type": "directml",
                    "provider": "DmlExecutionProvider",
                    "pylibs_dir": os.path.basename(pylibs_dml_dir),
                    "onnxruntime_version": getattr(ort, "__version__", "unknown"),
                }
        except Exception:
            pass
        return None

    # Step 3: Fresh import - try DML version
    try:
        # Insert DML path at front
        if pylibs_dml_dir not in sys.path:
            sys.path.insert(0, pylibs_dml_dir)

        # Register DLL directory (Windows)
        capi_dir = os.path.join(pylibs_dml_dir, "onnxruntime", "capi")
        if os.path.isdir(capi_dir) and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(capi_dir)

        import onnxruntime as ort

        # Step 4: Check if DML provider is available
        providers = ort.get_available_providers()
        if "DmlExecutionProvider" not in providers:
            return None

        # Step 5: Verify GPU is really usable by creating a minimal session
        # This catches cases where provider is compiled in but GPU driver is broken
        # We use a tiny dummy model (sigmoid.onnx shipped with onnxruntime)
        dummy_model = os.path.join(os.path.dirname(capi_dir), "datasets", "sigmoid.onnx")
        if not os.path.isfile(dummy_model):
            # If dummy model doesn't exist, skip verification (trust get_available_providers)
            pass
        else:
            try:
                import numpy as np
                so = ort.SessionOptions()
                so.enable_mem_pattern = False
                so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
                sess = ort.InferenceSession(
                    dummy_model, sess_options=so,
                    providers=["DmlExecutionProvider", "CPUExecutionProvider"]
                )
                # Run a tiny inference to verify
                # sigmoid.onnx expects 3D input [batch, channel, features]
                input_name = sess.get_inputs()[0].name
                input_shape = sess.get_inputs()[0].shape
                # Build test input matching expected shape
                test_shape = [1 if (d is None or not isinstance(d, int)) else d for d in input_shape]
                test_input = np.random.randn(*test_shape).astype(np.float32) * 0.1
                _ = sess.run(None, {input_name: test_input})
                del sess
            except Exception:
                # DML provider exists but can't actually run -> fall back to CPU
                return None

        return {
            "device_type": "directml",
            "provider": "DmlExecutionProvider",
            "pylibs_dir": os.path.basename(pylibs_dml_dir),
            "onnxruntime_version": getattr(ort, "__version__", "unknown"),
        }

    except Exception:
        return None


def _detect_cpu():
    """Detect CPU provider (always available as fallback).

    Returns:
        dict: detection result
    """
    pylibs_dir, _ = _get_pylibs_candidates()
    py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"

    # Determine which pylibs dir to use
    if py_version == "cp313":
        pylibs_subdir = "pylibs_cp313"
    else:
        pylibs_subdir = "pylibs"

    return {
        "device_type": "cpu",
        "provider": "CPUExecutionProvider",
        "pylibs_dir": pylibs_subdir,
        "onnxruntime_version": "unknown",  # Will be filled by caller
    }


def detect_device(force=False):
    """Detect best available device and cache result.

    Args:
        force: if True, re-run detection even if config file exists

    Returns:
        dict: device config with keys:
            - device_type: "directml" | "cpu"
            - provider: "DmlExecutionProvider" | "CPUExecutionProvider"
            - pylibs_dir: relative path to pylibs directory
            - onnxruntime_version: str
            - python_version: "cp311" | "cp313" (for cache invalidation)
            - last_check: ISO timestamp
    """
    config_path = _get_config_path()
    current_py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"

    # Try to load cached config first
    if not force and os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            # Validate config has required fields and matching Python version
            required_keys = ("device_type", "provider", "pylibs_dir", "python_version")
            if all(k in config for k in required_keys):
                if config.get("python_version") == current_py_version:
                    return config
                # Python version mismatch (e.g. user switched Blender version)
                # Need to re-detect with correct pylibs directory
        except Exception:
            pass  # Config corrupted, re-detect

    # Run detection
    # Only detect DirectML on Windows (DirectML is Windows-only)
    is_windows = platform.system() == "Windows"
    config = None

    if is_windows:
        config = _try_detect_directml()

    if config is None:
        # Fall back to CPU
        config = _detect_cpu()
        # Fill in the onnxruntime version number
        try:
            pylibs_dir, _ = _get_pylibs_candidates()
            if pylibs_dir not in sys.path:
                sys.path.insert(0, pylibs_dir)
            capi_dir = os.path.join(pylibs_dir, "onnxruntime", "capi")
            if os.path.isdir(capi_dir) and hasattr(os, "add_dll_directory"):
                os.add_dll_directory(capi_dir)
            import onnxruntime as ort
            config["onnxruntime_version"] = getattr(ort, "__version__", "unknown")
        except Exception:
            pass

    config["python_version"] = current_py_version
    config["last_check"] = datetime.now().isoformat()

    # Save config for next startup
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except Exception:
        pass  # Can't write config, but detection result is still valid

    return config

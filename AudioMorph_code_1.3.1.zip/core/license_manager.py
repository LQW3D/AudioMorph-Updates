"""License manager for AudioMorph plugin.

Wraps the C++ engine's license functions (get_device_id, check_activated,
activate, deactivate, verify_license) and provides a cached status for UI.
"""

import os
import sys
import functools

# Try to import the C++ engine. If unavailable, all license checks
# gracefully fail (treated as "not activated").
_engine = None
_engine_checked = False
_engine_error = None  # human-readable reason if the engine failed to load/run

def _get_engine():
    global _engine, _engine_checked, _engine_error
    if not _engine_checked:
        _engine_checked = True
        try:
            addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if addon_dir not in sys.path:
                sys.path.insert(0, addon_dir)
            import a2f_engine as _eng
            _engine = _eng
        except Exception as e:
            _engine = None
            _engine_error = str(e) or type(e).__name__
    return _engine


def get_engine_status():
    """Self-check the C++ engine and report whether it is usable.

    Returns:
        (ok: bool, message: str)
        - ok=True  -> the native engine loaded and answered a basic call.
        - ok=False -> the engine cannot be used; message explains why so the
          UI can show a visible, actionable error instead of silently
          degrading animation quality.
    """
    eng = _get_engine()
    if eng is None:
        return False, _engine_error or "Native engine not available"
    # Run a cheap real call to confirm the DLL actually works, not just that
    # the Python glue imported. get_device_id is a lightweight native op.
    try:
        eng.get_device_id()
        return True, ""
    except Exception as e:
        return False, str(e) or type(e).__name__


# Activation status cache (refreshed on each UI draw or explicit call).
_cached_device_id = None
_cached_activated = None

# Short time-based cache so the per-draw activation checks (called from every
# panel's draw()) don't hit the C++ engine on every redraw. C++ also caches
# the device fingerprint (generate_device_id), so after the first call each
# check is a cheap in-memory RSA verify.
import time as _time
_activated_cache = {"t": 0.0, "val": False}
_ACTIVATED_CACHE_SEC = 2.0


def _invalidate_activation_cache():
    """Force the next is_activated() call to re-check the engine."""
    global _activated_cache
    _activated_cache = {"t": 0.0, "val": False}


def get_device_id():
    """Return the hardware fingerprint device ID string."""
    eng = _get_engine()
    if eng is None:
        return ""
    try:
        return eng.get_device_id()
    except Exception:
        return ""


def is_activated():
    """Check if the software is activated on this machine.

    Returns:
        True if activated, False otherwise.
    """
    global _cached_activated, _activated_cache

    now = _time.time()
    if now - _activated_cache["t"] < _ACTIVATED_CACHE_SEC:
        return _activated_cache["val"]

    eng = _get_engine()
    if eng is None:
        return False

    try:
        dev = get_device_id()
        if not dev:
            return False
        result = eng.check_activated(dev)
        activated = (result == 1)
        _cached_activated = activated
        _activated_cache["t"] = now
        _activated_cache["val"] = activated
        return activated
    except Exception:
        return False


def activate(key_b64):
    """Attempt to activate with a base64 RSA-2048 signature key.

    Returns:
        (success: bool, message: str)
    """
    eng = _get_engine()
    if eng is None:
        return False, "C++ engine not available"

    try:
        dev = get_device_id()
        if not dev:
            return False, "Failed to generate device ID"

        result = eng.activate(key_b64.strip(), dev)
        if result == 1:
            global _cached_activated
            _cached_activated = True
            _invalidate_activation_cache()
            return True, "Activation successful"
        elif result == -1:
            return False, "Debugger detected, activation blocked"
        elif result == 2:
            return False, ("Activation key is valid but storing it failed "
                           "(check disk space / permissions)")
        else:
            return False, "Invalid activation key"
    except Exception as e:
        return False, str(e)


def deactivate():
    """Clear all activation data (for testing / uninstall)."""
    eng = _get_engine()
    if eng is None:
        return

    try:
        eng.deactivate()
        global _cached_activated
        _cached_activated = False
        _invalidate_activation_cache()
    except Exception:
        pass


def verify_license():
    """Full license verification (debugger + integrity + activation).

    Returns:
        (status: int, message: str)
        status: 1=ok, 0=not activated, -1=debugger, -2=integrity fail
    """
    eng = _get_engine()
    if eng is None:
        return 0, "C++ engine not available"

    try:
        result = eng.verify_license()
        if result == 1:
            return 1, "License OK"
        elif result == -1:
            return -1, "Debugger detected"
        elif result == -2:
            return -2, "Module integrity check failed"
        else:
            return 0, "Not activated"
    except Exception as e:
        return 0, str(e)


# ---------------------------------------------------------------------------
# Online activation / verification (cloud-issued token)
# ---------------------------------------------------------------------------
# Architecture (see cpp_src2/线上验证与门控加固_实现计划.md):
#   server decides if a code is valid -> signs a cloud token
#   DLL  verifies the token (embedded public key) and only then unlocks
#   this file only does the HTTP round-trip; it never decides access.
# The token is the "gate key": without it the DLL treats the machine as
# tampered and pollutes output. So activation MUST reach the server once.

import urllib.request
import urllib.error
import json as _json

# Endpoint of the online license server (阿里云 FC, see docs/).
# Overridable for testing/deployment via the A2F_SERVER_URL env var or by
# editing this constant. Plaintext by design: the judgment lives in the DLL.
_DEFAULT_SERVER_URL = "https://atf-license-wiaimkeglp.cn-beijing.fcapp.run"
SERVER_URL = os.environ.get("A2F_SERVER_URL", _DEFAULT_SERVER_URL)


def _post(path, payload, timeout=12):
    """POST JSON to the server and return the parsed JSON response."""
    data = _json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        SERVER_URL + path, data=data,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read().decode("utf-8")
    return _json.loads(body) if body else {}


def activate_online(activation_code):
    """Online activation: send device_id + activation code to the server.

    On success the server returns a signed cloud token; we store BOTH the
    persistent activation code (so is_activated() is true) and the cloud
    token (so the DLL gate passes). Returns (success, message).
    """
    eng = _get_engine()
    if eng is None:
        return False, "C++ engine not available"
    dev = get_device_id()
    if not dev:
        return False, "Failed to generate device ID"
    code = (activation_code or "").strip()
    if not code:
        return False, "Please enter an activation key"

    try:
        resp = _post("/activate", {"device_id": dev, "activation_code": code})
    except Exception as e:
        return False, "Network error: %s" % (e or type(e).__name__)

    if not resp.get("ok"):
        return False, resp.get("reason") or "Activation rejected by server"

    token = resp.get("token")
    expiry = resp.get("expiry")
    if not token or not expiry:
        return False, "Server returned an incomplete token"

    # 1) Store the persistent activation code (offline identifier).
    r = eng.activate(code, dev)
    if r != 1:
        return False, "Failed to store activation locally"
    # 2) Store the cloud token (this is what unlocks the DLL gate).
    if eng.verify_cloud_token(token, dev, int(expiry)) != 1:
        return False, "Cloud token rejected locally"

    _invalidate_activation_cache()
    return True, "Activation successful"


def verify_online():
    """Periodic online self-check.

    If the server revokes this device (ok=False, banned=True), we persist a
    device-bound ban flag in the DLL so the gate refuses immediately (instead
    of waiting for the token to expire). If the server re-approves the device
    (ok=True), we clear that flag and refresh the token, so unlinking a device
    automatically restores use without re-activating. Returns (ok, message).
    """
    eng = _get_engine()
    if eng is None:
        return False, "engine unavailable"
    dev = get_device_id()
    if not dev:
        return False, "no device id"
    stored = None
    try:
        stored = eng.get_cloud_token()
    except Exception:
        return False, "engine error"
    if not stored:
        return False, "no cloud token stored"

    try:
        resp = _post("/verify", {"device_id": dev, "token": stored["token"]})
    except Exception as e:
        # Offline: caller treats this as OK (grace period covers it).
        return False, "offline: %s" % (e or type(e).__name__)

    if resp.get("banned") or not resp.get("ok"):
        # Server blacklisted this device -> persist the ban flag so the DLL
        # gate locks immediately (persists across restarts). Do NOT refresh
        # the token. The "judgment" still lives in the DLL via the flag.
        try:
            eng.set_banned(dev)
        except Exception:
            pass
        return False, resp.get("reason") or "device revoked"

    # Re-approved: clear any previously stored ban flag (auto-restore after an
    # unban) and refresh the local token (new last_verified/expiry).
    try:
        eng.clear_banned(dev)
    except Exception:
        pass
    new_token = resp.get("token") or stored["token"]
    new_expiry = resp.get("expiry") or stored["expiry_ts"]
    try:
        eng.verify_cloud_token(new_token, dev, int(new_expiry))
    except Exception:
        pass
    return True, "ok"


def require_license():
    """Full license check for operation entry points.

    Runs the complete verification (debugger + module integrity +
    activation) and returns a boolean gate plus a user-facing message.
    Used by every functional operator's poll/execute so the plugin's
    features are unusable until the software is activated and intact.

    Returns:
        (ok: bool, message: str) — ok=True means licensed.
    """
    status, msg = verify_license()
    if status == 1:
        return True, ""
    return False, msg

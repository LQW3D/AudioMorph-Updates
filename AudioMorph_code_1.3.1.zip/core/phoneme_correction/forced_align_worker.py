#!/usr/bin/env python
"""Forced alignment worker - runs in subprocess to avoid onnxruntime conflicts.

This worker performs CTC forced alignment between user-corrected text and
audio, using the SenseVoice ONNX model directly via ONNX Runtime (not
through sherpa_onnx). It extracts the CTC emission matrix and runs Viterbi
alignment to produce per-character timestamps.

Mirrors asr_worker.py's setup pattern: uses CPU pylibs (onnxruntime 1.27+)
to avoid the DLL conflict with Blender 5.0's bundled onnxruntime 1.19.2.

Usage:
    python forced_align_worker.py --audio_path X --text Y --output Z
"""

import sys
import os
import json
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--audio_path', required=True)
    parser.add_argument('--text', required=True)
    parser.add_argument('--language', type=int, default=3)  # zh=3
    parser.add_argument('--text_norm', type=int, default=14)  # with_itn=14
    parser.add_argument('--output', required=True)
    args = parser.parse_args()

    addon_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # Make the addon root importable so forced_aligner can do
    # `import a2f_engine` (the native engine lives at the addon root).
    sys.path.insert(0, addon_root)

    # CPU pylibs contains onnxruntime 1.27+ (required for direct model inference)
    py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
    if py_version == "cp313":
        cpu_pylibs = os.path.join(addon_root, "deps", "pylibs_cp313")
    else:
        cpu_pylibs = os.path.join(addon_root, "deps", "pylibs")
    sys.path.insert(0, cpu_pylibs)

    # Python 3.8+ on Windows does not search PATH for DLLs.
    _ort_capi = os.path.join(cpu_pylibs, "onnxruntime", "capi")
    if os.path.isdir(_ort_capi):
        os.add_dll_directory(_ort_capi)

    # Force-clear any pre-loaded onnxruntime so the correct version is used
    for mod_name in list(sys.modules.keys()):
        if mod_name == 'onnxruntime' or mod_name.startswith('onnxruntime.'):
            del sys.modules[mod_name]

    try:
        import numpy as np
        import onnxruntime as ort
        import librosa

        print(f"[Align-Worker] onnxruntime {ort.__version__} from {ort.__file__}", flush=True)

        # --- Import alignment logic from forced_aligner ---
        # Add core/phoneme_correction to path so we can import forced_aligner
        core_pc_dir = os.path.join(addon_root, "core", "phoneme_correction")
        sys.path.insert(0, core_pc_dir)
        from forced_aligner import (
            load_tokens, text_to_token_ids, extract_fbank, apply_lfr,
            apply_cmvn, parse_cmvn_from_metadata, ctc_forced_align,
            build_char_timestamps, _compute_audio_energy,
            _get_model_path, _get_tokens_path,
            BLANK_ID,
        )

        # --- Step 1: Load tokens and convert text ---
        _, token2id = load_tokens(_get_tokens_path())
        token_ids, chars = text_to_token_ids(args.text, token2id)
        if not token_ids:
            raise ValueError("No valid Chinese characters in text")

        # --- Step 2: Load audio ---
        audio, sr = librosa.load(args.audio_path, sr=16000, mono=True)
        audio_duration = len(audio) / float(sr)

        # Compute short-time energy for boundary refinement
        audio_energy, energy_hop_sec = _compute_audio_energy(audio, sr)

        # --- Step 3: Extract features ---
        mel = extract_fbank(audio, sr=sr)
        lfr = apply_lfr(mel)

        # --- Step 4: Load model and get CMVN ---
        so = ort.SessionOptions()
        so.log_severity_level = 3
        sess = ort.InferenceSession(_get_model_path(), sess_options=so,
                                     providers=["CPUExecutionProvider"])
        meta = sess.get_modelmeta()
        neg_mean, inv_stddev = parse_cmvn_from_metadata(meta)
        features = apply_cmvn(lfr, neg_mean, inv_stddev)

        # --- Step 5: Run model ---
        x = features[np.newaxis, :, :]
        x_length = np.array([features.shape[0]], dtype=np.int32)
        language = np.array([args.language], dtype=np.int32)
        text_norm = np.array([args.text_norm], dtype=np.int32)
        outputs = sess.run(["logits"], {
            "x": x, "x_length": x_length,
            "language": language, "text_norm": text_norm,
        })
        logits = outputs[0][0]  # [T, 25055]

        # --- Step 6: log_softmax ---
        max_logits = np.max(logits, axis=-1, keepdims=True)
        exp_logits = np.exp(logits - max_logits)
        sum_exp = np.sum(exp_logits, axis=-1, keepdims=True)
        log_probs = np.log(exp_logits / sum_exp)

        # --- Step 7: CTC forced alignment ---
        token_frames, _ = ctc_forced_align(log_probs, token_ids, blank_id=BLANK_ID)

        # --- Step 8: Build char-level timestamps with peak-based refinement ---
        # Peak detection + sub-frame interpolation + energy-based boundaries
        # + LFR center offset (+30ms) for sub-60ms precision.
        # Energy data enables silence-aware boundary placement, preventing
        # pause absorption in songs with inter-phrase pauses.
        result_chars = build_char_timestamps(
            log_probs, token_frames, token_ids, chars, audio_duration,
            audio_energy=audio_energy, energy_hop_sec=energy_hop_sec,
        )

        output = {
            'success': True,
            'chars': result_chars,
            'total_chars': len(result_chars),
            'audio_duration': audio_duration,
        }

    except Exception as e:
        import traceback
        output = {
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
        }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    main()

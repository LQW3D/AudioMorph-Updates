#!/usr/bin/env python
"""ASR Worker - runs in subprocess to avoid onnxruntime conflicts in Blender 5.0.

This worker ONLY performs recognition and returns raw tokens/timestamps.
All post-processing (silence detection, char trimming, utterance splitting)
is handled by the main process via the identical _build_timestamps path used
by Blender 5.2 direct mode, ensuring consistent behavior across versions.
"""

import sys
import os
import json
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--audio_path', required=True)
    parser.add_argument('--model_dir', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()

    addon_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # sherpa-onnx needs CPU pylibs (numpy/scipy/onnxruntime 1.27+).
    # Even if device_config says pylibs_dml, sherpa-onnx only runs on CPU.
    py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
    if py_version == "cp313":
        cpu_pylibs = os.path.join(addon_root, "deps", "pylibs_cp313")
    else:
        cpu_pylibs = os.path.join(addon_root, "deps", "pylibs")
    sys.path.insert(0, cpu_pylibs)

    # Python 3.8+ on Windows does not search PATH for DLLs.
    # Must explicitly add onnxruntime/capi/ to DLL search paths so the
    # correct onnxruntime.dll (1.27.0) is found instead of any older version
    # that Blender may have pre-loaded.
    _ort_capi = os.path.join(cpu_pylibs, "onnxruntime", "capi")
    if os.path.isdir(_ort_capi):
        os.add_dll_directory(_ort_capi)

    # Blender 5.1+ may ship with an older onnxruntime (e.g. 1.17.1) that is
    # auto-loaded at subprocess startup. Force-clear any pre-loaded
    # onnxruntime from sys.modules so the correct version from cpu_pylibs
    # is used instead. sherpa-onnx will validate compatibility itself when
    # imported — do NOT add a hard version check here, because pylibs may
    # legitimately ship onnxruntime 1.26.0 (Python 3.11) which works fine
    # with sherpa-onnx 1.13.4 in practice.
    for mod_name in list(sys.modules.keys()):
        if mod_name == 'onnxruntime' or mod_name.startswith('onnxruntime.'):
            del sys.modules[mod_name]

    try:
        import onnxruntime as _ort_check
        _ort_ver = getattr(_ort_check, '__version__', 'unknown')
        _ort_path = getattr(_ort_check, '__file__', 'unknown')
        print(f"[ASR-Worker] onnxruntime {_ort_ver} from {_ort_path}", flush=True)

        import librosa
        import sherpa_onnx

        model_path = os.path.join(args.model_dir, 'model.int8.onnx')
        tokens_path = os.path.join(args.model_dir, 'tokens.txt')

        recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
            model=model_path,
            tokens=tokens_path,
            num_threads=2,
            use_itn=True,
            language="auto",
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
        )

        audio, sr = librosa.load(args.audio_path, sr=16000, mono=True)
        audio_duration = len(audio) / float(sr)

        stream = recognizer.create_stream()
        stream.accept_waveform(sr, audio)
        recognizer.decode_stream(stream)
        result = stream.result
        full_text = result.text.strip()

        tokens = list(result.tokens)
        timestamps = list(result.timestamps)

        # Detect silence regions in the subprocess.
        # In Blender 5.0, the main process's numpy can throw RecursionError
        # during np.sqrt(np.mean(...)) due to a numpy/native-library conflict.
        # Computing silence here avoids that entirely.
        silence_regions = _detect_silence_regions(audio, sr)

        output = {
            'success': True,
            'full_text': full_text,
            'tokens': tokens,
            'timestamps': [float(t) for t in timestamps],
            'duration': audio_duration,
            'silence_regions': silence_regions,
        }

    except Exception as e:
        import traceback
        output = {
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
        }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)


def _detect_silence_regions(audio, sr, frame_ms=30):
    """Detect silence regions > 150ms for VAD trimming.

    Mirrors local_asr.LocalASR._detect_silence_regions so the subprocess
    output is directly consumable by _build_timestamps in the main process.
    """
    try:
        import numpy as _np
    except ImportError:
        return []

    if _np is None or len(audio) == 0:
        return []

    frame_size = int(sr * frame_ms / 1000)
    if frame_size < 1:
        return []

    n_frames = len(audio) // frame_size
    if n_frames < 2:
        return []

    audio_trimmed = audio[:n_frames * frame_size]
    frames = audio_trimmed.reshape(n_frames, frame_size)
    energies = _np.sqrt(_np.mean(frames * frames, axis=1))

    max_energy = float(energies.max())
    if max_energy < 1e-6:
        return []

    threshold = max_energy * 0.10
    is_silence = energies < threshold

    min_silence_frames = max(2, int(150 / frame_ms))
    silence_regions = []
    gap_start = None
    frame_sec = frame_ms / 1000.0

    for i in range(n_frames):
        if is_silence[i]:
            if gap_start is None:
                gap_start = i
        else:
            if gap_start is not None:
                silence_len = i - gap_start
                if silence_len >= min_silence_frames:
                    silence_regions.append([
                        gap_start * frame_sec,
                        i * frame_sec,
                    ])
                gap_start = None

    if gap_start is not None:
        silence_len = n_frames - gap_start
        if silence_len >= min_silence_frames:
            silence_regions.append([
                gap_start * frame_sec,
                n_frames * frame_sec,
            ])

    return silence_regions


if __name__ == '__main__':
    main()

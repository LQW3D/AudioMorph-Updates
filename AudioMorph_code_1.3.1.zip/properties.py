import json
import os

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty

from .utils.i18n import t


# ----------------------------------------------------------------------------
# Preset template helpers (shared by Animation and DAZ pages)
# ----------------------------------------------------------------------------
# __file__ is properties.py inside the addon root; one dirname gets us to
# the addon directory (e.g. .../AudioMorph). Presets live under
# config/presets/ alongside user_defaults.json.
_ADDON_DIR = os.path.dirname(__file__)
_PRESETS_DIR = os.path.join(_ADDON_DIR, "config", "presets")


def _emotion_enum_items(scene, context):
    """Build EnumProperty items for the 11 emotion segment types.

    Identifiers are ASCII (safe for Blender RNA); display names are the
    i18n-translated labels so the dropdown shows the user's language.
    """
    from .core.emotion_templates import EMOTION_IDS, get_emotion_label
    items = []
    for emo_id in EMOTION_IDS:
        label = get_emotion_label(emo_id)
        items.append((emo_id, t(label), t(label)))
    return items


def _preset_enum_items(scene, context):
    """Build EnumProperty items by scanning config/presets/*.json.

    Used by both the Animation and DAZ preset dropdowns so the same set of
    template files is available on both pages. Returns at least one
    placeholder entry so the EnumProperty is always valid.

    Note: Blender EnumProperty identifiers MUST be ASCII (non-ASCII bytes
    break the RNA encoding on Windows). So we use a stable index-based
    identifier ('PRESET_0', 'PRESET_1', ...) and put the real filename in
    the display name + description. Operators translate the identifier back
    to the filename via _preset_id_to_name().
    """
    items = [('NONE', t("(No Preset)"), t("No preset template selected"))]
    try:
        if os.path.isdir(_PRESETS_DIR):
            files = sorted(
                f for f in os.listdir(_PRESETS_DIR)
                if f.lower().endswith('.json')
            )
            for idx, fname in enumerate(files):
                stem = os.path.splitext(fname)[0]
                # ASCII-safe identifier; the display name carries the real
                # (possibly non-ASCII) filename so users see Chinese names.
                identifier = f"PRESET_{idx}"
                items.append((identifier, stem, t("Load preset") + f": {stem}"))
    except Exception:
        pass
    return items


def _preset_id_to_name(identifier: str) -> str:
    """Translate an EnumProperty identifier back to the preset filename stem.

    Returns an empty string for 'NONE' or unknown identifiers. Used by the
    load/delete operators to recover the real filename.
    """
    if not identifier or identifier == 'NONE':
        return ""
    try:
        if identifier.startswith('PRESET_'):
            idx = int(identifier[len('PRESET_'):])
        else:
            return ""
        if not os.path.isdir(_PRESETS_DIR):
            return ""
        files = sorted(
            f for f in os.listdir(_PRESETS_DIR)
            if f.lower().endswith('.json')
        )
        if 0 <= idx < len(files):
            return os.path.splitext(files[idx])[0]
    except (ValueError, OSError):
        pass
    return ""


def _daz_preset_enum_items(scene, context):
    """DAZ page preset dropdown items.

    Currently mirrors the Animation page list (both scan the same
    config/presets/ directory). Kept as a separate function so DAZ can
    later have its own preset folder without touching call sites.
    """
    return _preset_enum_items(scene, context)


def _apply_phoneme_strength_realtime_daz(props, context):
    """DAZ page counterpart of _apply_phoneme_strength_realtime.

    Reads strength from the DAZ property group and feeds the same debounce
    queue. The debounce timer itself is target-type agnostic (it dispatches
    based on AnimationCache.get_target_type()), so one queue is enough.
    """
    _phoneme_update_pending.last_strength = props.phoneme_correction_strength
    _phoneme_update_pending.pending = True

    if not bpy.app.timers.is_registered(_phoneme_debounce_timer):
        bpy.app.timers.register(_phoneme_debounce_timer, first_interval=0.15)


# ----------------------------------------------------------------------------
# Frame rate
# ----------------------------------------------------------------------------
# The plugin does NOT keep its own fps property. The UI binds directly to
# scene.render.fps, and operators read context.scene.render.fps when they
# need the frame rate. This means the Animation page, the DAZ page, and
# the scene always share the exact same value - no sync logic needed.


def _apply_phoneme_strength_realtime(props, context):
    """Realtime callback for phoneme correction strength (debounced version).

    When the slider is dragged, only a "needs update" flag is set, without
    immediately executing the time-consuming fusion+write. The _phoneme_debounce_timer
    checks every 150ms and writes to animation only after dragging stops.
    This preserves responsiveness while avoiding lag from frequent triggers.
    """
    # Mark update needed (do not execute immediately)
    _phoneme_update_pending.last_strength = props.phoneme_correction_strength
    _phoneme_update_pending.pending = True

    # Start debounce timer (if not already started)
    if not bpy.app.timers.is_registered(_phoneme_debounce_timer):
        bpy.app.timers.register(_phoneme_debounce_timer, first_interval=0.15)


class _PhonemeUpdatePending:
    """Debounce flag: records latest slider value, waiting for timer execution."""
    pending = False
    last_strength = 0.4


_phoneme_update_pending = _PhonemeUpdatePending()


def _phoneme_debounce_timer():
    """Debounce timer: checks every 150ms, only executes fusion+write if pending.

    This way, even if the slider triggers 30 updates per second, the actual write
    happens at most once every 150ms, avoiding lag caused by writing keyframes
    too frequently.
    """
    if not _phoneme_update_pending.pending:
        return None  # No pending, stop timer

    _phoneme_update_pending.pending = False  # Clear flag

    try:
        from .core.animation_cache import AnimationCache
        from .core.phoneme_correction import PhonemeCorrector
        from .core.blendshape import BlendshapeFrame

        cache = AnimationCache
        if not cache.has_original_data() or not cache.has_phoneme_data():
            return 0.15  # No cached data, keep waiting (user may not have generated animation yet)

        original_frames = cache.get_original_frames()
        phoneme_data = cache.get_phoneme_data()
        frame_offset = cache.get_phoneme_frame_offset()
        fps = cache.get_fps()
        target_obj_name = cache.get_target_object()
        if not target_obj_name:
            return None
        target_obj = bpy.data.objects.get(target_obj_name)
        if not target_obj:
            return None

        # Fusion
        # CRITICAL: correct_frames must use frame_offset=0, NOT the timeline
        # frame_offset. Phoneme timestamps and frame['time'] are both relative
        # to audio 0s (see generate.py _apply_phoneme_correction:
        #   frame_offset=0, "Phoneme times are based on audio 0s")
        # The timeline frame_offset is only for writing keyframes at the correct
        # absolute frame numbers. If we pass the timeline offset to correct_frames,
        # frame_time = frame['time'] + timeline_offset * (1/fps) shifts all frames
        # beyond the phoneme data range, so viseme_result is None for every frame
        # and NO correction is applied — making strength=0 and strength=1 look
        # identical.
        corrector = PhonemeCorrector()
        strength = _phoneme_update_pending.last_strength
        corrected_dicts = corrector.correct_frames(
            original_frames, fps, phoneme_data, strength, 0
        )

        # Format conversion: dict -> BlendshapeFrame
        corrected_frames = [
            BlendshapeFrame(time=d['time'], weights=d['weights'])
            for d in corrected_dicts
        ]

        # Write (choose write path based on target_type)
        mapping = cache.get_mapping()
        target_type = cache.get_target_type()
        if target_type == 'DAZ_RIG':
            from .daz.daz_driver import apply_blendshapes_to_daz_rig
            apply_blendshapes_to_daz_rig(
                target_obj, corrected_frames, mapping, fps=fps, frame_offset=frame_offset
            )
        elif target_type == 'FACEIT_RIG':
            from .daz.faceit_driver import apply_blendshapes_to_faceit_rig
            apply_blendshapes_to_faceit_rig(
                target_obj, corrected_frames, mapping, fps=fps, frame_offset=frame_offset
            )

        # CRITICAL: sync the cache so subsequent operations (Apply Adjustments,
        # Lip Repair, next slider drag) read the SAME weights we just wrote.
        # Without this, post-processing reads stale weights from the cache and
        # writes back values that don't match the bones — causing the animation
        # to look wrong after Apply Adjustments, and causing each slider drag
        # to undo the previous drag's effect.
        cache.store_frames(
            frames=corrected_frames,
            fps=fps,
            target_object=target_obj_name,
            target_type=target_type,
            mapping=mapping,
            frame_offset=frame_offset,
        )
    except Exception as e:
        print(f"[AudioMorph] Realtime phoneme update failed: {e}")

    # If new pending exists (triggered again while sliding), keep waiting
    if _phoneme_update_pending.pending:
        return 0.15
    return None  # Stop timer


_DEFAULT_KEYS = [
    # NOTE: "fps" is not in this list because the plugin does not keep its
    # own fps property - the UI binds directly to scene.render.fps. The
    # scene's frame rate is persisted by Blender itself.
    "upper_face_strength",
    "lower_face_strength",
    "upper_face_smoothing",
    "lower_face_smoothing",
    "skin_strength",
    "jaw_open_multiplier",
    "mouth_close_multiplier",
    "jaw_left_right_multiplier",
    "mouth_roll_lower_multiplier",
    "mouth_roll_upper_multiplier",
    "mouth_shrug_lower_multiplier",
    "mouth_shrug_upper_multiplier",
    "mouth_upper_up_multiplier",
    "mouth_lower_down_multiplier",
    "blink_strength",
    "eyeballs_strength",
    "saccade_strength",
    "blink_interval",
    "lip_open_offset",
    "input_strength",
    "prediction_delay",
    "tongue_strength",
    "post_smoothing",
    "post_strength",
    "mouth_close_adjust",
    "jaw_open_adjust",
    "mouth_lower_down_adjust",
    "lip_closure_combined",
    "show_advanced_lip_params",
    # Phoneme correction settings (persisted so user tuning survives restart)
    "enable_phoneme_correction",
    "phoneme_correction_strength",
]


def get_user_defaults_path():
    """Animation page defaults file: config/user_defaults.json."""
    addon_dir = os.path.dirname(__file__)
    return os.path.join(addon_dir, "config", "user_defaults.json")


def get_daz_defaults_path():
    """DAZ page defaults file: config/user_defaults_daz.json."""
    addon_dir = os.path.dirname(__file__)
    return os.path.join(addon_dir, "config", "user_defaults_daz.json")


def load_user_defaults():
    defaults_path = get_user_defaults_path()
    if os.path.exists(defaults_path):
        try:
            with open(defaults_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[AudioMorph] load_user_defaults failed: {e}")
    return {}


def load_daz_defaults():
    """Load DAZ page defaults from config/user_defaults_daz.json."""
    path = get_daz_defaults_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[AudioMorph] load_daz_defaults failed: {e}")
    return {}


def apply_defaults_to_scene(scene):
    """Apply both Animation and DAZ defaults to the scene property groups.

    Falls back to the Animation defaults for the DAZ group when the DAZ
    defaults file does not exist yet (first run after the split), so users
    upgrading from the shared-config era keep their previous DAZ tuning.
    """
    if not hasattr(scene, "audiomorph_props"):
        return

    anim_defaults = load_user_defaults()
    if anim_defaults:
        props = scene.audiomorph_props
        for key in _DEFAULT_KEYS:
            if key in anim_defaults and hasattr(props, key):
                try:
                    setattr(props, key, anim_defaults[key])
                except Exception:
                    pass

    # DAZ defaults: prefer user_defaults_daz.json; fall back to the
    # Animation defaults so the first run after upgrade is not a regression.
    daz_defaults = load_daz_defaults()
    if not daz_defaults:
        daz_defaults = anim_defaults
    if daz_defaults and hasattr(scene, "audiomorph_daz_props"):
        daz_props = scene.audiomorph_daz_props
        for key in _DEFAULT_KEYS:
            if key in daz_defaults and hasattr(daz_props, key):
                try:
                    setattr(daz_props, key, daz_defaults[key])
                except Exception:
                    pass

    # Note: fps is not synced here because the plugin no longer keeps its
    # own fps property. The UI binds directly to scene.render.fps.


class AudioMorphEmotionSegmentItem(bpy.types.PropertyGroup):
    """One emotion segment in the manual emotion segmentation list.

    Each row is produced by ASR (one utterance = one segment) or added
    manually. The user assigns an emotion type + intensity per row; the
    start frame can be corrected by moving the timeline playhead and
    clicking the "correct" button.
    """

    text: StringProperty(
        name=t("Text"),
        description=t("Recognized text for this emotion segment"),
        default="",
    )

    emotion: EnumProperty(
        name=t("Emotion"),
        description=t("Emotion type for this segment"),
        items=_emotion_enum_items,
        default=0,
    )

    intensity: FloatProperty(
        name=t("Non-Mouth"),
        description=t("Emotion intensity for non-mouth channels (brow, eye, "
                      "cheek, nose). 0=none, 1=normal, 2=extreme"),
        default=0.5,
        min=0.0,
        max=2.0,
    )

    non_mouth_min_ratio: FloatProperty(
        name=t("Non-Mouth Min"),
        description=t("Minimum emotion ratio for non-mouth channels during "
                      "silence. 0=emotion fully drops at silence, "
                      "1=emotion stays at peak regardless of audio. "
                      "Lower values give more dynamic range, higher values "
                      "keep emotion stable during pauses"),
        default=0.7,
        min=0.0,
        max=1.0,
    )

    mouth_intensity: FloatProperty(
        name=t("Mouth"),
        description=t("Mouth emotion blend ratio (0=no mouth emotion, "
                      "1=full mouth emotion). Lower values keep lip-sync "
                      "cleaner, higher values let the emotion affect the "
                      "mouth more strongly"),
        default=0.5,
        min=0.0,
        max=1.0,
    )

    mouth_min_ratio: FloatProperty(
        name=t("Mouth Min"),
        description=t("Minimum emotion ratio for mouth channels during "
                      "silence. 0=mouth emotion fully drops at silence, "
                      "1=mouth emotion stays at peak regardless of audio. "
                      "Lower values let the mouth relax during pauses, "
                      "higher values keep mouth emotion persistent"),
        default=0.6,
        min=0.0,
        max=1.0,
    )

    frame: IntProperty(
        name=t("Frame"),
        description=t("Start frame of this emotion segment in the timeline"),
        default=1,
        min=1,
    )

    start_time: FloatProperty(
        name=t("Start Time"),
        description=t("Start time of this segment in seconds (audio-relative)"),
        default=0.0,
        min=0.0,
    )

    end_time: FloatProperty(
        name=t("End Time"),
        description=t("End time of this segment in seconds (audio-relative)"),
        default=0.0,
        min=0.0,
    )


def _active_page_update(self, context):
    """Clamp stale active_page values to 'DAZ'.

    Blend files saved with the old 3-page enum (BINDING/ANIMATION/DAZ) may
    store an identifier that no longer exists, producing RNA warnings. This
    callback forces any invalid value back to 'DAZ'.
    """
    if self.active_page != 'DAZ':
        self.active_page = 'DAZ'


class AudioMorphProperties(bpy.types.PropertyGroup):
    # Only the DAZ page remains after the closed-source refactor. active_page
    # is kept (single option) because routing code in preset, save_defaults
    # and daz_phoneme reads audiomorph_props.active_page.
    active_page: EnumProperty(
        name=t("Page"),
        description=t("AudioMorph workflow page"),
        items=[
            ("DAZ", t("DAZ"), t("Drive DAZ FACS rig from audio")),
        ],
        default="DAZ",
        update=_active_page_update,
    )

    audio_file: StringProperty(
        name=t("Audio File"),
        description=t("Audio file to process"),
        default="",
        subtype="FILE_PATH",
    )

    # fps: the plugin binds directly to scene.render.fps in the UI and reads
    # context.scene.render.fps in operators. No fps property is stored here.

    upper_face_strength: FloatProperty(
        name=t("Upper Face Strength"),
        description=t("Strength for upper-face motion"),
        default=1.5,
        min=0.0,
        max=2.0,
    )

    lower_face_strength: FloatProperty(
        name=t("Lower Face Strength"),
        description=t("Strength for mouth and lower-face motion"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    upper_face_smoothing: FloatProperty(
        name=t("Upper Face Smoothing"),
        description=t("Temporal smoothing for upper-face motion"),
        default=0.001,
        min=0.0,
        max=0.1,
        precision=4,
    )

    lower_face_smoothing: FloatProperty(
        name=t("Lower Face Smoothing"),
        description=t("Temporal smoothing for lower-face motion"),
        default=0.001,
        min=0.0,
        max=0.1,
        precision=4,
    )

    prediction_delay: FloatProperty(
        name=t("Lip Sync Delay"),
        description=t("Shift generated mouth motion in time. Positive values delay the animation."),
        default=0.0,
        min=-0.5,
        max=0.5,
        precision=3,
    )

    skin_strength: FloatProperty(
        name=t("Skin Strength"),
        description=t("Strength for skin deformation output"),
        default=1.32,
        min=0.0,
        max=2.0,
    )

    jaw_open_multiplier: FloatProperty(
        name=t("Jaw Open Multiplier"),
        description=t("Multiplier for jaw-open motion"),
        default=0.65,
        min=0.0,
        max=2.0,
    )

    mouth_close_multiplier: FloatProperty(
        name=t("Mouth Close Multiplier"),
        description=t("Multiplier for mouth-close motion"),
        default=1.1,
        min=0.0,
        max=2.0,
    )

    jaw_left_right_multiplier: FloatProperty(
        name=t("Jaw Left/Right Multiplier"),
        description=t("Multiplier for jaw and mouth left-right motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_roll_lower_multiplier: FloatProperty(
        name=t("Lower Lip Roll Multiplier"),
        description=t("Multiplier for lower-lip roll motion"),
        default=0.3,
        min=0.0,
        max=2.0,
    )

    mouth_roll_upper_multiplier: FloatProperty(
        name=t("Upper Lip Roll Multiplier"),
        description=t("Multiplier for upper-lip roll motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_shrug_lower_multiplier: FloatProperty(
        name=t("Lower Lip Shrug Multiplier"),
        description=t("Multiplier for lower-lip shrug motion"),
        default=0.3,
        min=0.0,
        max=2.0,
    )

    mouth_shrug_upper_multiplier: FloatProperty(
        name=t("Upper Lip Shrug Multiplier"),
        description=t("Multiplier for upper-lip shrug motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_upper_up_multiplier: FloatProperty(
        name=t("Upper Lip Up Multiplier"),
        description=t("Multiplier for upper-lip raise motion (MouthUpperUpLeft/Right). Negative values push the upper lip down to counteract excessive lift during speech."),
        default=0.6,
        min=-1.0,
        max=2.0,
    )

    mouth_lower_down_multiplier: FloatProperty(
        name=t("Lower Lip Down Multiplier"),
        description=t("Multiplier for lower-lip down motion"),
        default=0.8,
        min=0.0,
        max=2.0,
    )

    blink_strength: FloatProperty(
        name=t("Blink Strength"),
        description=t("Strength for blink output generated by the SDK"),
        default=2.0,
        min=0.0,
        max=2.0,
    )

    eyeballs_strength: FloatProperty(
        name=t("Eye Movement Strength"),
        description=t("Strength for generated eye movement"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    saccade_strength: FloatProperty(
        name=t("Saccade Strength"),
        description=t("Strength for small natural eye movements"),
        default=0.6,
        min=0.0,
        max=1.0,
    )

    blink_interval: FloatProperty(
        name=t("Blink Interval"),
        description=t("Target interval between automatic blinks, in seconds"),
        default=3.0,
        min=0.5,
        max=10.0,
    )

    lip_open_offset: FloatProperty(
        name=t("Lip Open Offset"),
        description=t("Global offset for mouth opening"),
        default=-0.02,
        min=-0.1,
        max=0.1,
        precision=3,
    )

    input_strength: FloatProperty(
        name=t("Input Strength"),
        description=t("Global input animation strength"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    tongue_strength: FloatProperty(
        name=t("Tongue Strength"),
        description=t("Strength for tongue motion"),
        default=1.3,
        min=0.0,
        max=2.0,
    )

    show_advanced_settings: BoolProperty(
        name=t("Show Advanced Settings"),
        description=t("Show advanced controls"),
        default=False,
    )

    status_message: StringProperty(
        name=t("Status Message"),
        default="Ready",
        description=t("Current operation status"),
    )

    is_processing: BoolProperty(
        name=t("Processing"),
        default=False,
    )

    has_animation_data: BoolProperty(
        name=t("Has Animation Data"),
        default=False,
    )

    animation_frame_count: IntProperty(
        name=t("Animation Frame Count"),
        default=0,
    )

    frame_start: IntProperty(
        name=t("Start Frame"),
        description=t("Animation start frame"),
        default=1,
        min=1,
    )

    frame_end: IntProperty(
        name=t("End Frame"),
        description=t("Animation end frame"),
        default=250,
        min=1,
    )

    post_smoothing: FloatProperty(
        name=t("Post Smoothing"),
        description=t("Post-process smoothing amount"),
        default=0.0,
        min=0.0,
        max=1.0,
    )

    post_strength: FloatProperty(
        name=t("Post Strength"),
        description=t("Post-process strength multiplier"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # Three-in-one linked adjustment for lip closure: negative=stronger closure, positive=weaker closure
    # Internally auto-adjusts MouthClose / JawOpen / MouthLowerDown in linkage
    # 0 = no adjustment (keep original generated values)
    lip_closure_combined: FloatProperty(
        name=t("Lip Closure Combined"),
        description=t("Linked lip closure adjustment. Negative=stronger closure, positive=weaker closure, 0=no change"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    # Advanced: three independent parameters (hidden by default, can be adjusted individually when expanded)
    show_advanced_lip_params: BoolProperty(
        name=t("Show Advanced Lip Parameters"),
        description=t("Show individual MouthClose / JawOpen / MouthLowerDown adjustments"),
        default=False,
    )

    # Lip closure specific adjustment (recalculated based on original generated values, 0=no adjustment)
    # Positive strengthens closure, negative weakens (used to alleviate mesh penetration)
    mouth_close_adjust: FloatProperty(
        name=t("Mouth Close Adjust"),
        description=t("Adjust mouth close intensity. 0=no change, positive=stronger closure, negative=weaker (fixes lip overlap)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    jaw_open_adjust: FloatProperty(
        name=t("Jaw Open Adjust"),
        description=t("Adjust jaw open during bilabial sounds. 0=no change, positive=more jaw drop, negative=less jaw drop (helps lip closure)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    mouth_lower_down_adjust: FloatProperty(
        name=t("Mouth Lower Down Adjust"),
        description=t("Adjust lower lip down during bilabial sounds. 0=no change, positive=lower lip drops more, negative=lower lip stays up (helps lip closure)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    # Mouth amplitude scale: uniformly scales JawOpen + MouthLowerDown +
    # MouthUpperUp in post-processing. Unlike smoothing (which blurs
    # articulation transients), this only scales the peak amplitude so
    # mouth shapes stay crisp. 1.0=original, <1.0=subdued (calm dialogue),
    # >1.0=exaggerated (excited dialogue).
    mouth_scale: FloatProperty(
        name=t("Mouth Scale"),
        description=t("Mouth amplitude scale (post-process). 1.0=original, <1.0=subdued for calm dialogue, >1.0=exaggerated for excited dialogue. Unlike smoothing, this only scales peak amplitude and preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # Pucker scale: scales MouthPucker + MouthFunnel (forward lip protrusion).
    # Reduces excessive forward pucker on rounded vowels like "o/u" (e.g. "我").
    # 1.0=original, <1.0=less pucker, >1.0=more pucker.
    # Only scales peak amplitude, preserves articulation crispness.
    pucker_scale: FloatProperty(
        name=t("Pucker Scale"),
        description=t("Pucker amplitude scale (post-process). Scales MouthPucker + MouthFunnel. 1.0=original, <1.0=reduces forward lip protrusion on rounded vowels (o/u), >1.0=more pucker. Only scales peak amplitude, preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # Mouth stretch scale: scales MouthStretch L/R (horizontal mouth width)
    # and MouthSmile L/R (corner lift, which also widens).
    # Controls how wide the mouth corners pull sideways.
    # 1.0=original, <1.0=narrower mouth, >1.0=wider mouth.
    # Only scales peak amplitude, preserves articulation crispness.
    mouth_stretch_scale: FloatProperty(
        name=t("Mouth Stretch Scale"),
        description=t("Mouth stretch scale (post-process). Scales MouthStretch Left/Right (horizontal mouth width) and MouthSmile Left/Right (corner lift). 1.0=original, <1.0=narrower mouth, >1.0=wider mouth. Only scales peak amplitude, preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # ============================================================
    # Phoneme correction related properties
    # ============================================================
    enable_phoneme_correction: BoolProperty(
        name=t("Enable Phoneme Correction"),
        description=t("Use Chinese phoneme analysis to correct mouth shapes from model inference"),
        default=True,
    )

    phoneme_correction_strength: FloatProperty(
        name=t("Correction Strength"),
        description=t("0=pure model inference, 1=pure phoneme preset"),
        default=1.0,
        min=0.0,
        max=1.0,
        # Realtime response: when sliding strength, immediately read original inference+phoneme from cache, re-fuse and write to animation
        update=lambda self, context: _apply_phoneme_strength_realtime(self, context),
    )

    phoneme_correction_active: BoolProperty(
        name=t("Phoneme Correction Active"),
        description=t("Whether phoneme correction is currently applied (toggleable without re-generating)"),
        default=False,
    )

    # ASR recognized text (editable by user for correcting misrecognitions,
    # e.g. song lyrics where "花" is misrecognized as "我"). After editing,
    # the user clicks "Apply Edited Text" to regenerate phoneme data from
    # the corrected text and re-fuse the animation. No ASR/SDK re-run needed.
    asr_recognized_text: bpy.props.StringProperty(
        name=t("ASR Recognized Text"),
        description=t("ASR recognized text. Edit to fix misrecognitions (e.g. song lyrics), then click Apply Edited Text to regenerate phonemes. No re-run of ASR/SDK needed."),
        default="",
        subtype='FILE_NAME',
    )

    # ---- Preset template selection (Animation page). Mirrors the DAZ page
    #      dropdown; both scan config/presets/. ----
    preset_selection: EnumProperty(
        name=t("Preset"),
        description=t("Select a parameter preset template to load"),
        items=_preset_enum_items,
    )

    # ============================================================
    # Manual emotion segmentation
    # ============================================================
    # ASR splits the audio into utterances; each utterance becomes one row
    # in emotion_segments. The user assigns an emotion type + intensity per
    # row, and optionally corrects the start frame. emotion_segments_enabled
    # gates whether the segmentation is used at all.
    emotion_segments_enabled: BoolProperty(
        name=t("Emotion Segmentation"),
        description=t("Enable manual emotion segmentation (assign emotion per segment)"),
        default=False,
    )

    emotion_segments: CollectionProperty(type=AudioMorphEmotionSegmentItem)

    emotion_segments_index: IntProperty(
        name=t("Emotion Segment Index"),
        default=0,
        min=0,
    )


class AudioMorphDAZProperties(bpy.types.PropertyGroup):
    """DAZ mode dedicated property group.

    Keeps DAZ-specific state (rig pointer, audio file, status) AND a full set
    of SDK/animator settings independent from AudioMorphProperties, so the
    Animation and DAZ pages can have separate parameter sets and default
    files (user_defaults.json vs user_defaults_daz.json).
    """

    # ---- DAZ-specific state (not shared with Animation page) ----
    rig_type: EnumProperty(
        name=t("Rig Controller Type"),
        description=t("Select rig controller type"),
        items=[
            ('DAZ', "DAZ", "DAZ FACS"),
            ('FACEIT', "faceit", "Faceit ControlRig"),
        ],
        default='DAZ',
    )

    daz_rig_object: StringProperty(
        name=t("Armature"),
        description=t("Select an armature with rig controllers"),
        default="",
    )

    audio_file: StringProperty(
        name=t("Audio File"),
        description=t("Audio file to process for DAZ mode"),
        default="",
        subtype="FILE_PATH",
    )

    status_message: StringProperty(
        name=t("Status Message"),
        default="Ready",
        description=t("Current DAZ operation status"),
    )

    is_processing: BoolProperty(
        name=t("Processing"),
        default=False,
    )

    has_animation_data: BoolProperty(
        name=t("Has Animation Data"),
        default=False,
    )

    animation_frame_count: IntProperty(
        name=t("Animation Frame Count"),
        default=0,
    )

    frame_start: IntProperty(
        name=t("Start Frame"),
        description=t("Animation start frame"),
        default=1,
        min=1,
    )

    frame_end: IntProperty(
        name=t("End Frame"),
        description=t("Animation end frame"),
        default=250,
        min=1,
    )

    # ---- SDK / animator settings (independent copy, same schema as
    #      AudioMorphProperties so the user can tune DAZ without affecting
    #      the Animation page). These are persisted to
    #      config/user_defaults_daz.json. ----
    # fps: same as the Animation page - binds directly to scene.render.fps.

    upper_face_strength: FloatProperty(
        name=t("Upper Face Strength"),
        description=t("Strength for upper-face motion"),
        default=1.5,
        min=0.0,
        max=2.0,
    )

    lower_face_strength: FloatProperty(
        name=t("Lower Face Strength"),
        description=t("Strength for mouth and lower-face motion"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    upper_face_smoothing: FloatProperty(
        name=t("Upper Face Smoothing"),
        description=t("Temporal smoothing for upper-face motion"),
        default=0.001,
        min=0.0,
        max=0.1,
        precision=4,
    )

    lower_face_smoothing: FloatProperty(
        name=t("Lower Face Smoothing"),
        description=t("Temporal smoothing for lower-face motion"),
        default=0.001,
        min=0.0,
        max=0.1,
        precision=4,
    )

    prediction_delay: FloatProperty(
        name=t("Lip Sync Delay"),
        description=t("Shift generated mouth motion in time. Positive values delay the animation."),
        default=0.0,
        min=-0.5,
        max=0.5,
        precision=3,
    )

    skin_strength: FloatProperty(
        name=t("Skin Strength"),
        description=t("Strength for skin deformation output"),
        default=1.32,
        min=0.0,
        max=2.0,
    )

    jaw_open_multiplier: FloatProperty(
        name=t("Jaw Open Multiplier"),
        description=t("Multiplier for jaw-open motion"),
        default=0.65,
        min=0.0,
        max=2.0,
    )

    mouth_close_multiplier: FloatProperty(
        name=t("Mouth Close Multiplier"),
        description=t("Multiplier for mouth-close motion"),
        default=1.1,
        min=0.0,
        max=2.0,
    )

    jaw_left_right_multiplier: FloatProperty(
        name=t("Jaw Left/Right Multiplier"),
        description=t("Multiplier for jaw and mouth left-right motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_roll_lower_multiplier: FloatProperty(
        name=t("Lower Lip Roll Multiplier"),
        description=t("Multiplier for lower-lip roll motion"),
        default=0.3,
        min=0.0,
        max=2.0,
    )

    mouth_roll_upper_multiplier: FloatProperty(
        name=t("Upper Lip Roll Multiplier"),
        description=t("Multiplier for upper-lip roll motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_shrug_lower_multiplier: FloatProperty(
        name=t("Lower Lip Shrug Multiplier"),
        description=t("Multiplier for lower-lip shrug motion"),
        default=0.3,
        min=0.0,
        max=2.0,
    )

    mouth_shrug_upper_multiplier: FloatProperty(
        name=t("Upper Lip Shrug Multiplier"),
        description=t("Multiplier for upper-lip shrug motion"),
        default=0.2,
        min=0.0,
        max=2.0,
    )

    mouth_upper_up_multiplier: FloatProperty(
        name=t("Upper Lip Up Multiplier"),
        description=t("Multiplier for upper-lip raise motion (MouthUpperUpLeft/Right). Negative values push the upper lip down to counteract excessive lift during speech."),
        default=0.6,
        min=-1.0,
        max=2.0,
    )

    mouth_lower_down_multiplier: FloatProperty(
        name=t("Lower Lip Down Multiplier"),
        description=t("Multiplier for lower-lip down motion"),
        default=0.8,
        min=0.0,
        max=2.0,
    )

    blink_strength: FloatProperty(
        name=t("Blink Strength"),
        description=t("Strength for blink output generated by the SDK"),
        default=2.0,
        min=0.0,
        max=2.0,
    )

    eyeballs_strength: FloatProperty(
        name=t("Eye Movement Strength"),
        description=t("Strength for generated eye movement"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    saccade_strength: FloatProperty(
        name=t("Saccade Strength"),
        description=t("Strength for small natural eye movements"),
        default=0.6,
        min=0.0,
        max=1.0,
    )

    blink_interval: FloatProperty(
        name=t("Blink Interval"),
        description=t("Target interval between automatic blinks, in seconds"),
        default=3.0,
        min=0.5,
        max=10.0,
    )

    lip_open_offset: FloatProperty(
        name=t("Lip Open Offset"),
        description=t("Global offset for mouth opening"),
        default=-0.02,
        min=-0.1,
        max=0.1,
        precision=3,
    )

    input_strength: FloatProperty(
        name=t("Input Strength"),
        description=t("Global input animation strength"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    tongue_strength: FloatProperty(
        name=t("Tongue Strength"),
        description=t("Strength for tongue motion"),
        default=1.3,
        min=0.0,
        max=2.0,
    )

    show_advanced_settings: BoolProperty(
        name=t("Show Advanced Settings"),
        description=t("Show advanced controls"),
        default=False,
    )

    post_smoothing: FloatProperty(
        name=t("Post Smoothing"),
        description=t("Post-process smoothing amount"),
        default=0.0,
        min=0.0,
        max=1.0,
    )

    post_strength: FloatProperty(
        name=t("Post Strength"),
        description=t("Post-process strength multiplier"),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    lip_closure_combined: FloatProperty(
        name=t("Lip Closure Combined"),
        description=t("Linked lip closure adjustment. Negative=stronger closure, positive=weaker closure, 0=no change"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    show_advanced_lip_params: BoolProperty(
        name=t("Show Advanced Lip Parameters"),
        description=t("Show individual MouthClose / JawOpen / MouthLowerDown adjustments"),
        default=False,
    )

    mouth_close_adjust: FloatProperty(
        name=t("Mouth Close Adjust"),
        description=t("Adjust mouth close intensity. 0=no change, positive=stronger closure, negative=weaker (fixes lip overlap)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    jaw_open_adjust: FloatProperty(
        name=t("Jaw Open Adjust"),
        description=t("Adjust jaw open during bilabial sounds. 0=no change, positive=more jaw drop, negative=less jaw drop (helps lip closure)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    mouth_lower_down_adjust: FloatProperty(
        name=t("Mouth Lower Down Adjust"),
        description=t("Adjust lower lip down during bilabial sounds. 0=no change, positive=lower lip drops more, negative=lower lip stays up (helps lip closure)"),
        default=0.0,
        min=-1.0,
        max=1.0,
    )

    # Mouth amplitude scale (same semantics as AudioMorphProperties.mouth_scale)
    mouth_scale: FloatProperty(
        name=t("Mouth Scale"),
        description=t("Mouth amplitude scale (post-process). 1.0=original, <1.0=subdued for calm dialogue, >1.0=exaggerated for excited dialogue. Unlike smoothing, this only scales peak amplitude and preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # Pucker scale (same semantics as AudioMorphProperties.pucker_scale)
    pucker_scale: FloatProperty(
        name=t("Pucker Scale"),
        description=t("Pucker amplitude scale (post-process). Scales MouthPucker + MouthFunnel. 1.0=original, <1.0=reduces forward lip protrusion on rounded vowels (o/u), >1.0=more pucker. Only scales peak amplitude, preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # Mouth stretch scale (same semantics as AudioMorphProperties.mouth_stretch_scale)
    # Scales MouthStretch L/R (horizontal width) + MouthSmile L/R (corner lift).
    mouth_stretch_scale: FloatProperty(
        name=t("Mouth Stretch Scale"),
        description=t("Mouth stretch scale (post-process). Scales MouthStretch Left/Right (horizontal mouth width) and MouthSmile Left/Right (corner lift). 1.0=original, <1.0=narrower mouth, >1.0=wider mouth. Only scales peak amplitude, preserves articulation crispness."),
        default=1.0,
        min=0.0,
        max=2.0,
    )

    # ---- Phoneme correction (DAZ-independent copy) ----
    enable_phoneme_correction: BoolProperty(
        name=t("Enable Phoneme Correction"),
        description=t("Use Chinese phoneme analysis to correct mouth shapes from model inference"),
        default=True,
    )

    phoneme_correction_strength: FloatProperty(
        name=t("Correction Strength"),
        description=t("0=pure model inference, 1=pure phoneme preset"),
        default=1.0,
        min=0.0,
        max=1.0,
        # Realtime response: when sliding strength, immediately read original inference+phoneme from cache, re-fuse and write to animation
        update=lambda self, context: _apply_phoneme_strength_realtime_daz(self, context),
    )

    phoneme_correction_active: BoolProperty(
        name=t("Phoneme Correction Active"),
        description=t("Whether phoneme correction is currently applied (toggleable without re-generating)"),
        default=False,
    )

    # ASR recognized text (editable, same semantics as Animation page).
    asr_recognized_text: bpy.props.StringProperty(
        name=t("ASR Recognized Text"),
        description=t("ASR recognized text. Edit to fix misrecognitions (e.g. song lyrics), then click Apply Edited Text to regenerate phonemes. No re-run of ASR/SDK needed."),
        default="",
        subtype='FILE_NAME',
    )

    # ---- Manual emotion segmentation (DAZ page independent copy).
    #      The DAZ page keeps its own segment list because the DAZ audio
    #      file is typically different from the Animation page audio file,
    #      so ASR-generated segments must be tracked separately. The
    #      emotion_segments operators route to whichever property group
    #      matches the active page (see operators/emotion_segments.py). ----
    emotion_segments_enabled: BoolProperty(
        name=t("Emotion Segmentation"),
        description=t("Enable manual emotion segmentation (assign emotion per segment)"),
        default=False,
    )

    emotion_segments: CollectionProperty(type=AudioMorphEmotionSegmentItem)

    emotion_segments_index: IntProperty(
        name=t("Emotion Segment Index"),
        default=0,
        min=0,
    )

    # ---- Preset template selection (shared with the Animation page via
    #      the preset dropdown in the Settings panel). The enum items are
    #      rebuilt on demand by _daz_preset_enum_items() so newly saved
    #      templates appear without a plugin reload. ----
    preset_selection: EnumProperty(
        name=t("Preset"),
        description=t("Select a parameter preset template to load"),
        items=_daz_preset_enum_items,
    )


classes = [
    AudioMorphEmotionSegmentItem,
    AudioMorphProperties,
    AudioMorphDAZProperties,
]

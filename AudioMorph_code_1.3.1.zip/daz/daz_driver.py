"""DAZ FACS driver: write ARKit weights to Object-level FACS properties as keyframes.

The DAZ FACS driver chain (set up by the import_daz addon) is:

    rig["<prop>"]                    (Object-level custom property, the slider input)
        ↓  driver on rig.data
    rig.data["<prop>(fin)"]          (Armature data property, the driven output)
        ↓  driver on mesh shape keys
    mesh shape_key["<prop>"].value   (final mesh deformation)

We write keyframes to the Object-level property (the slider input) using
rig.keyframe_insert('["<prop>"]'), which is exactly what the DAZ UI panel
does when the user moves a slider and presses the key button.

Action / slot handling (Blender 5.x layered animation):
On Blender 5.x an Action must be bound to the Object via a slot before any
fcurve is evaluated. We reuse any existing action/slot, and only create a
new action + slot when none exists. We never replace an existing action,
because that would discard the slot binding the DAZ addon relies on.
"""

import bpy
from typing import Dict, List

# Same compensation constant as core/animation.py for MouthClose.
MOUTH_CLOSE_OPEN_COMPENSATION = 0.35


# On DAZ G8.1, three lip-related ARKit channels physically deform the lips
# inward along the X-axis, producing the visible "向里兜" (lip inversion)
# artifact the user reported on bilabial sounds like "妹妹" (mèi mei):
#   - MouthRollLower / MouthRollUpper (AU28 Lip Roll) — true X-axis rotation
#   - MouthPressLeft / MouthPressRight (AU24 Lip Press) — on G8.1 the
#     blendshape direction tucks the lips inward instead of just thinning them
#   - MouthShrugLower (AU17 Chin Raiser) — on G8.1 the lower lip pushes up
#     AND inward, manifesting as inversion rather than a clean "pout"
#
# The NVIDIA model outputs non-zero values for these channels during
# bilabial closure (b/p/m) even though no Chinese phoneme requires them —
# this is a model generalization error. On G8.1 these channels ALL produce
# visible X-axis inward rotation, so all three are DISABLED (clamped to 0).
#
# Emotion templates (ANGER/SAD) intentionally do NOT use these channels
# (verified in emotion_templates.py: ANGER uses mouthFrown/browDown, SAD uses
# mouthFrown/browOuterUp — neither uses MouthPress/MouthShrug/MouthRoll),
# so disabling them here does not affect emotion expression on DAZ.
# Lip closure for b/p/m sounds is driven by MouthClose + JawOpen +
# MouthLowerDown, which are NOT capped.
def clamp_daz_prop_value(arkit_name: str, prop_name: str, value: float,
                          weights: dict = None,
                          allow_negative: bool = False) -> float:
    """Clamp a DAZ Object property value to prevent rig deformation artifacts.

    The actual cap set (which channels are disabled/capped on G8.1) lives in
    the native C++ engine. This is a thin wrapper so that both the generation
    path (apply_blendshapes_to_daz_rig) and the post-process path
    (daz_postprocess._apply_daz_postprocess) apply the SAME caps.
    """
    import a2f_engine as _native
    return _native.clamp_daz_prop(
        arkit_name or '', prop_name, float(value), bool(allow_negative))


def _ensure_action_slot(rig: bpy.types.Object):
    """Ensure rig.animation_data has an Action and a bound OBJECT slot.

    On Blender 4.x an Action is assigned directly to anim_data.action and
    fcurves evaluate immediately. On Blender 5.x the layered-animation model
    also requires an OBJECT slot bound to anim_data.action_slot; without it,
    rig.keyframe_insert() silently succeeds but the fcurve is never evaluated
    ("no error but no animation generated"). Although Blender often auto-binds
    a slot on the first keyframe_insert of a custom property, this behavior
    is not guaranteed across all 5.x minor versions, so we bind explicitly
    as a safety net (idempotent if already bound).

    We reuse any existing action rather than creating a new one, because
    replacing the action would discard the slot binding and any user-authored
    keyframes on the same action.
    """
    if not rig.animation_data:
        rig.animation_data_create()
    anim_data = rig.animation_data

    # Create an Action if none exists
    if anim_data.action is None:
        action = bpy.data.actions.new(name=f"{rig.name}_DAZ_FACS")
        anim_data.action = action
    else:
        action = anim_data.action

    # For Blender 4.4+ layered actions, ensure an OBJECT slot is explicitly
    # bound to anim_data.action_slot. Mirrors the logic in
    # core/animation.py:_get_fcurves_collection but for an Object (rig),
    # so id_type is 'OBJECT' instead of 'KEY'.
    if hasattr(action, 'is_action_layered') and action.is_action_layered:
        slot = anim_data.action_slot
        if slot is None:
            if action.slots:
                # Prefer a suitable slot if one exists
                try:
                    suitable = list(anim_data.action_suitable_slots)
                    if suitable:
                        slot = suitable[0]
                except Exception:
                    pass
                if slot is None:
                    slot = action.slots[0]
            else:
                # Create a new OBJECT slot named after the rig
                slot = action.slots.new(id_type='OBJECT', name=rig.name)
            anim_data.action_slot = slot

        # Ensure at least one layer + strip exists so the channelbag can be
        # located/created when keyframes are inserted.
        if not action.layers:
            action.layers.new("Layer")
        layer = action.layers[0]
        if not layer.strips:
            layer.strips.new(type='KEYFRAME')


def _get_action_fcurves(action) -> List:
    """Return the fcurves of an Action, handling both legacy and layered modes.

    Blender < 4.4: action.fcurves is the fcurve collection directly.
    Blender >= 4.4 (layered animation): fcurves live inside
        action.layers[0].strips[0].channelbag(slot).fcurves
    and action.fcurves exists but is empty (does not raise), so we must
    check is_action_layered explicitly rather than relying on a try/except
    on action.fcurves.
    """
    if action is None:
        return []
    # Layered mode (Blender >= 4.4) — check this FIRST because layered
    # actions also expose an (empty) action.fcurves attribute.
    if hasattr(action, 'is_action_layered') and action.is_action_layered:
        fcurves = []
        layers = getattr(action, 'layers', None)
        if layers:
            for layer in layers:
                for strip in layer.strips:
                    channelbags = getattr(strip, 'channelbags', None)
                    if not channelbags:
                        continue
                    for cb in channelbags:
                        cb_fcurves = getattr(cb, 'fcurves', None)
                        if cb_fcurves:
                            fcurves.extend(cb_fcurves)
        return fcurves
    # Legacy mode (Blender < 4.4, or a non-layered Action on 4.4+)
    try:
        return list(action.fcurves)
    except Exception:
        return []


def apply_blendshapes_to_daz_rig(
    rig: bpy.types.Object,
    frames: List,
    mapping: Dict[str, List],
    fps: int = 30,
    frame_offset: int = 0,
) -> bool:
    """Write ARKit weight frames to rig Object-level properties as keyframes.

    Uses rig.keyframe_insert() — the same mechanism the DAZ UI panel uses.
    Reuses the existing action on rig.animation_data to preserve the DAZ
    driver chain.

    Args:
        rig: DAZ armature Object.
        frames: list of BlendshapeFrame (time, weights dict).
        mapping: ARKit name -> list of (prop_name, scale) from
            daz_mapping.get_daz_mapping().
        fps: target frame rate.
        frame_offset: frame number offset (playhead-based segment start).

    Returns:
        True if any keyframes were written.
    """
    import a2f_engine as _native

    # Log mapping coverage for diagnostics.
    _mapped_arkit = sorted(mapping.keys())
    _key_arkit = ['JawOpen', 'MouthClose', 'MouthSmileLeft', 'MouthSmileRight',
                  'EyeBlinkLeft', 'EyeBlinkRight', 'BrowInnerUp']
    _missing_key = [n for n in _key_arkit if n not in _mapped_arkit]
    if _missing_key:
        print(f"[AudioMorph DAZ] WARNING: key expressions not mapped: {_missing_key}")
    print(f"[AudioMorph DAZ] Mapping coverage: {len(_mapped_arkit)} expressions, "
          f"JawOpen={'YES' if 'JawOpen' in _mapped_arkit else 'NO'}")

    # CRITICAL: Reuse any existing action and slot. On Blender 5.x we also
    # ensure the OBJECT slot is bound, otherwise written keyframes are
    # stored but never evaluated (the rig would not move).
    _ensure_action_slot(rig)
    anim_data = rig.animation_data
    action = anim_data.action

    # Precompute frame_num -> {prop: value} for all frames.
    # Apply MouthClose compensation in the weight domain.
    #
    # Bidirectional DAZ controllers (e.g. facs_ctrl_EyeLookSide-SideLeft)
    # encode two opposite ARKit directions on a single property via sign
    # (look in = +, look out = -). Several ARKit channels can therefore
    # target the SAME property, so we SUM their contributions per property
    # per frame and write ONE keyframe. Without aggregation, the separated
    # channels wrote competing keyframes on the same frame and the zero-
    # valued one overwrote the real signal (eye saccades were lost).
    #
    # Performance: the per-frame conversion (MouthClose compensation +
    # bidirectional aggregation + per-prop clamp) runs in the compiled C++
    # engine. We convert the WHOLE clip in a single engine call
    # (a2f_engine.write_values_batch) instead of one ctypes JSON round trip
    # per frame — the per-frame call serialized the full mapping table on
    # every iteration and dominated the realtime phoneme / generation write
    # paths. The batch result is one {prop: value} dict per frame, in the
    # same order as the input frames.
    frame_nums = [
        int(round(frame_data.time * fps)) + 1 + frame_offset
        for frame_data in frames
    ]
    prop_frame_values: Dict[str, List] = {}  # prop -> [(frame_num, value), ...]

    try:
        batch_results = _native.write_values_batch("daz", frames, mapping)
    except Exception as e:
        print(f"[AudioMorph DAZ] C++ batch write failed ({e}); aborting write")
        raise

    for i, frame_data in enumerate(frames):
        frame_num = frame_nums[i]
        for prop, value in batch_results[i].items():
            if prop not in prop_frame_values:
                prop_frame_values[prop] = []
            prop_frame_values[prop].append((frame_num, value))

    if not prop_frame_values:
        print("[AudioMorph DAZ] No mappable ARKit weights -> properties")
        return False

    # Write keyframes to the Object-level FACS properties.
    #
    # Performance: a full-clip rewrite via one rig.keyframe_insert() per frame
    # is O(frames x props) Blender-side calls (e.g. 3600 frames x ~40 props =
    # ~140k slow calls) — this dominated the realtime phoneme sliders. Instead
    # we bulk-load each prop's entire time series into its fcurve once via
    # foreach_set (remaining Blender calls are O(props)).
    total_keyframes = 0
    total_props = len(prop_frame_values)

    wm = bpy.context.window_manager
    wm.progress_begin(0, total_props)

    for idx, (prop, values) in enumerate(prop_frame_values.items()):
        n = _write_prop_fcurve_batch(rig, action, prop, values)
        total_keyframes += n
        wm.progress_update(idx + 1)

    wm.progress_end()

    print(f"[AudioMorph DAZ] Wrote {total_keyframes} keyframes to "
          f"{total_props} Object properties on {rig.name}")
    return True


def _set_fcurve_points(kp, values) -> int:
    """Set an fcurve's keyframe points from (frame, value) pairs.

    The caller is responsible for deleting the overwritten frame range; this
    helper only appends the new points and then overwrites the WHOLE point
    array via foreach_set. Because foreach_set requires the coordinates array
    to match the total point count, we must merge the surviving points'
    coordinates with the new ones before calling it — otherwise the length
    check fails whenever another segment's keyframes remain on the fcurve
    ("internal error setting the array").
    """
    n = len(values)
    if n == 0:
        return 0
    # Snapshot surviving points BEFORE adding new ones, since add() inserts
    # zero-coordinate points that would pollute this list.
    surviving = [(float(k.co[0]), float(k.co[1])) for k in kp]
    kp.add(count=n)
    coords = []
    for x, y in surviving:
        coords.append(x)
        coords.append(y)
    for frame_num, value in values:
        coords.append(float(frame_num))
        coords.append(float(value))
    kp.foreach_set("co", coords)
    # Neutral handles preserve the curve shape (mirrors keyframe_insert which
    # uses auto handles; FREE keeps the values untouched by handle logic).
    # NOTE: foreach_set on the enum handle type accepts only integer enum
    # values (not strings) in Blender 5.x, so assign via per-point property.
    for k in kp:
        k.handle_left_type = 'FREE'
        k.handle_right_type = 'FREE'
    return n


def _remove_keyframe_points_in_range(kp, start: int, end: int) -> int:
    """Remove keyframes of an fcurve whose frame falls in [start, end].

    Multi-segment safety: only keyframes inside the current segment's write
    range are removed so other segments sharing this fcurve are preserved.
    Old Per-frame code used keyframe_insert (which overwrites in place and
    never deletes other frames); the batch rewrite must emulate that by
    deleting ONLY the frames being overwritten instead of kp.clear() all.
    """
    if not kp:
        return 0
    removed = 0
    i = len(kp) - 1
    while i >= 0:
        fr = int(round(kp[i].co[0]))
        if start <= fr <= end:
            try:
                kp.remove(i)
            except TypeError:
                # Older Blender expects the keyframe point object itself.
                kp.remove(kp[i])
            removed += 1
        i -= 1
    return removed


def _write_prop_fcurve_batch(rig, action, prop, values) -> int:
    """Bulk-write (frame, value) pairs to one Object custom-property fcurve.

    Replaces the old per-frame rig.keyframe_insert() loop. Only the fcurve
    creation (when the prop has no fcurve yet) uses a single keyframe_insert;
    all subsequent frames are bulk-loaded via fcurve.keyframe_points and
    foreach_set, which is orders of magnitude faster for full-clip rewrites.

    Only keyframes inside the current segment's frame range are overwritten
    (deleted then re-added); keyframes of other segments on the same fcurve
    are left untouched so multiple animation segments can coexist.

    Args:
        rig: DAZ armature Object.
        action: the rig's animation Action (already slot-bound).
        prop: Object custom property name (e.g. 'facs_bs_JawOpen').
        values: list of (frame_num, float value) pairs.

    Returns:
        Number of keyframes written (0 if the fcurve could not be located).
    """
    data_path = '["%s"]' % prop
    # Ensure the Object custom property exists and holds a float value.
    rig[prop] = float(values[-1][1])

    # Locate the existing fcurve for this prop (legacy or layered action).
    fc = None
    for f in _get_action_fcurves(action):
        if f.data_path == data_path and f.array_index == 0:
            fc = f
            break

    # Create the fcurve if missing. A single keyframe_insert is used because
    # it is the most compatible way to create fcurves on both legacy and
    # Blender 5.x layered actions (it handles slot/channelbag plumbing).
    if fc is None:
        rig[prop] = float(values[0][1])
        rig.keyframe_insert(data_path, frame=int(values[0][0]))
        for f in _get_action_fcurves(action):
            if f.data_path == data_path and f.array_index == 0:
                fc = f
                break
    if fc is None:
        return 0

    # Overwrite only the frames produced by this segment, preserving any
    # previously-written segments on the same fcurve.
    seg_start = int(values[0][0])
    seg_end = int(values[-1][0])
    _remove_keyframe_points_in_range(fc.keyframe_points, seg_start, seg_end)

    # Bulk-load the new points while preserving any surviving out-of-range
    # keyframes (other segments on the same fcurve).
    n = _set_fcurve_points(fc.keyframe_points, values)
    fc.update()
    return n


def _get_rig_object_fcurves(rig: bpy.types.Object) -> List:
    """Return the Object-level fcurves that drive facs_* custom properties.

    Used by the post-process (Apply Adjustments / Lip Repair) operators to
    read the keyframed values back from the rig's animation action without
    re-running inference. Only fcurves whose data_path matches
    '["facs_<name>"]' are returned; bone pose fcurves and non-FACS custom
    properties are excluded.

    Works on both Blender 4.x (legacy action.fcurves) and 5.x (layered
    action.layers[].strips[].channelbag().fcurves) via _get_action_fcurves.
    """
    if rig is None or not rig.animation_data or not rig.animation_data.action:
        return []
    out = []
    for fcu in _get_action_fcurves(rig.animation_data.action):
        dp = fcu.data_path or ''
        # Match '["facs_..."]' custom property paths (Object-level inputs).
        if dp.startswith('["facs_') and dp.endswith('"]'):
            out.append(fcu)
    return out




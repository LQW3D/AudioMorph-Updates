"""DAZ mode phoneme correction operators.

Mirrors operators/phoneme.py but writes to the DAZ rig.data (fin) properties
via daz_driver instead of mesh shape keys. The weight-domain fusion logic
(PhonemeCorrector.correct_frames) is reused as-is.

Provides two operators:
1. AUDIO2FACE_OT_daz_toggle_phoneme_correction
   - Turn phoneme correction on/off without re-generating animation.
2. AUDIO2FACE_OT_daz_apply_phoneme_strength
   - Re-fuse with a new strength value and re-write.
"""

import bpy
from bpy.props import BoolProperty
from typing import List, Any

from ..utils.i18n import t, tr
from ..core import license_manager
from .daz_mapping import get_daz_mapping
from .daz_driver import apply_blendshapes_to_daz_rig
from .faceit_mapping import get_faceit_mapping
from .faceit_driver import apply_blendshapes_to_faceit_rig


def _get_daz_rig_from_cache():
    """Resolve the rig Object from the AnimationCache target_object.

    Returns the armature regardless of rig type (DAZ or Faceit); the name
    is historical — the cached target_object is whatever rig the user
    selected on the page.
    """
    from ..core.animation_cache import AnimationCache
    rig_name = AnimationCache.get_target_object()
    if not rig_name:
        return None
    return bpy.data.objects.get(rig_name)


def _rebuild_frames_from_cache():
    """Reconstruct BlendshapeFrame list from AnimationCache original data."""
    from ..core.animation_cache import AnimationCache
    from ..core.blendshape import BlendshapeFrame

    if not AnimationCache.has_original_data():
        return None, 0, 0

    raw = AnimationCache.get_original_frames()
    if not raw:
        return None, 0, 0

    frames = []
    for item in raw:
        if isinstance(item, dict):
            frames.append(BlendshapeFrame(time=item['time'], weights=dict(item['weights'])))
        else:
            frames.append(BlendshapeFrame(time=item.time, weights=dict(item.weights)))

    fps = AnimationCache.get_fps()
    frame_offset = AnimationCache.get_phoneme_frame_offset()
    return frames, fps, frame_offset


def _refuse_with_phonemes(frames, props):
    """Fuse frames with phonemes at the current strength. Falls back to the
    original frames if no phoneme data is available."""
    from ..core.animation_cache import AnimationCache
    from ..core.phoneme_correction import PhonemeCorrector
    from ..core.blendshape import BlendshapeFrame

    phonemes = AnimationCache.get_phoneme_data()
    if not phonemes:
        return frames

    corrector = PhonemeCorrector()
    frames_list = [{'time': f.time, 'weights': f.weights} for f in frames]
    corrected = corrector.correct_frames(
        model_frames=frames_list,
        fps=AnimationCache.get_fps(),
        phonemes=phonemes,
        correction_strength=props.phoneme_correction_strength,
        frame_offset=0,
    )
    return [BlendshapeFrame(time=f['time'], weights=f['weights']) for f in corrected]


def _apply_frames_to_rig(frames: List[Any], fps: int, frame_offset: int) -> bool:
    """Write frames to the rig using the cached target_type for dispatch.

    The inference + emotion-fusion pipeline produces a single weight-domain
    data packet; this function is the fork where it gets written to the
    actual rig. Dispatch by AnimationCache.get_target_type():
      - DAZ_RIG:    Object-level facs_* custom properties via daz_driver
      - FACEIT_RIG: pose bone location transforms via faceit_driver
    """
    from ..core.animation_cache import AnimationCache

    rig = _get_daz_rig_from_cache()
    if rig is None:
        return False

    target_type = AnimationCache.get_target_type()

    if target_type == 'FACEIT_RIG':
        mapping = get_faceit_mapping(rig)
        if not mapping:
            return False
        return apply_blendshapes_to_faceit_rig(
            rig, frames, mapping,
            fps=fps, frame_offset=frame_offset,
        )

    # Default: DAZ_RIG (also covers legacy MESH fallback if mapping is DAZ)
    mapping = get_daz_mapping(rig)
    if not mapping:
        return False
    return apply_blendshapes_to_daz_rig(
        rig, frames, mapping,
        fps=fps, frame_offset=frame_offset,
    )


class AUDIO2FACE_OT_daz_toggle_phoneme_correction(bpy.types.Operator):
    """Toggle phoneme correction for DAZ mode without re-generating."""
    bl_idname = "audiomorph.daz_toggle_phoneme_correction"
    bl_label = t("Toggle Phoneme Correction")
    bl_description = t("Turn phoneme correction on/off without re-generating animation")
    bl_options = {'REGISTER', 'UNDO'}

    turn_on: BoolProperty(
        name="Turn On",
        description="True=enable correction, False=disable correction",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        from ..core.animation_cache import AnimationCache
        return (AnimationCache.has_data()
                and AnimationCache.has_original_data())

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        props = context.scene.audiomorph_daz_props

        from ..core.animation_cache import AnimationCache

        if not AnimationCache.has_data():
            self.report({'ERROR'}, tr("Toggle is only available when animation data exists"))
            return {'CANCELLED'}
        if not AnimationCache.has_original_data():
            self.report({'ERROR'}, tr("No original inference data cached, please regenerate animation"))
            return {'CANCELLED'}

        frames, fps, frame_offset = _rebuild_frames_from_cache()
        if frames is None:
            self.report({'ERROR'}, tr("No original inference data cached, please regenerate animation"))
            return {'CANCELLED'}

        if self.turn_on:
            if not AnimationCache.has_phoneme_data():
                self.report({'ERROR'}, tr("No phoneme data cached, please regenerate animation"))
                return {'CANCELLED'}
            fused = _refuse_with_phonemes(frames, props)
            ok = _apply_frames_to_rig(fused, fps, frame_offset)
            if not ok:
                self.report({'ERROR'}, tr("Phoneme correction failed"))
                return {'CANCELLED'}
            props.phoneme_correction_active = True
            AnimationCache.store_frames(
                frames=fused,
                fps=fps,
                target_object=AnimationCache.get_target_object(),
                target_type=AnimationCache.get_target_type(),
                mapping=AnimationCache.get_mapping(),
                frame_offset=frame_offset,
            )
            self.report({'INFO'}, tr("Phoneme correction turned on"))
            print(f"[AudioMorph DAZ] Phoneme ON: strength={props.phoneme_correction_strength:.2f}")
        else:
            ok = _apply_frames_to_rig(frames, fps, frame_offset)
            if not ok:
                self.report({'ERROR'}, tr("Phoneme correction failed"))
                return {'CANCELLED'}
            props.phoneme_correction_active = False
            AnimationCache.store_frames(
                frames=frames,
                fps=fps,
                target_object=AnimationCache.get_target_object(),
                target_type=AnimationCache.get_target_type(),
                mapping=AnimationCache.get_mapping(),
                frame_offset=frame_offset,
            )
            self.report({'INFO'}, tr("Phoneme correction turned off"))
            print("[AudioMorph DAZ] Phoneme OFF: restored pure model inference")

        return {'FINISHED'}


class AUDIO2FACE_OT_daz_apply_phoneme_strength(bpy.types.Operator):
    """Re-fuse with new strength and re-write to DAZ rig."""
    bl_idname = "audiomorph.daz_apply_phoneme_strength"
    bl_label = t("Apply Correction Strength")
    bl_description = t("Re-fuse model inference with phonemes using new strength")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        from ..core.animation_cache import AnimationCache
        return (AnimationCache.has_data()
                and AnimationCache.has_original_data()
                and AnimationCache.has_phoneme_data())

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        props = context.scene.audiomorph_daz_props

        from ..core.animation_cache import AnimationCache

        if not AnimationCache.has_data() or not AnimationCache.has_original_data():
            self.report({'ERROR'}, tr("No original inference data cached, please regenerate animation"))
            return {'CANCELLED'}
        if not AnimationCache.has_phoneme_data():
            self.report({'ERROR'}, tr("No phoneme data cached, please regenerate animation"))
            return {'CANCELLED'}

        frames, fps, frame_offset = _rebuild_frames_from_cache()
        if frames is None:
            self.report({'ERROR'}, tr("No original inference data cached, please regenerate animation"))
            return {'CANCELLED'}

        fused = _refuse_with_phonemes(frames, props)
        ok = _apply_frames_to_rig(fused, fps, frame_offset)
        if not ok:
            self.report({'ERROR'}, tr("Phoneme correction failed"))
            return {'CANCELLED'}

        props.phoneme_correction_active = True
        AnimationCache.store_frames(
            frames=fused,
            fps=fps,
            target_object=AnimationCache.get_target_object(),
            target_type=AnimationCache.get_target_type(),
            mapping=AnimationCache.get_mapping(),
            frame_offset=frame_offset,
        )
        self.report({'INFO'}, tr("Strength updated and animation re-applied"))
        print(f"[AudioMorph DAZ] Strength applied: {props.phoneme_correction_strength:.2f}")
        return {'FINISHED'}


class AUDIO2FACE_OT_daz_apply_edited_text(bpy.types.Operator):
    """Regenerate phonemes from edited ASR text and re-fuse DAZ animation.

    DAZ version of AUDIO2FACE_OT_apply_edited_text. Uses the same phoneme
    regeneration logic but writes to the DAZ rig via daz_driver.
    """
    bl_idname = "audiomorph.daz_apply_edited_text"
    bl_label = t("Apply Edited Text")
    bl_description = t("Regenerate phonemes from edited ASR text and re-fuse animation. No ASR/SDK re-run needed.")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        from ..core.animation_cache import AnimationCache
        return (AnimationCache.has_data()
                and AnimationCache.has_original_data())

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        scene = context.scene
        # Only the DAZ page remains; always use audiomorph_daz_props.
        props = scene.audiomorph_daz_props

        from ..core.animation_cache import AnimationCache
        # Reuse the shared regeneration + fusion logic from phoneme.py
        from ..operators.phoneme import _regenerate_and_refuse_from_edited_text

        fused, fps, frame_offset, chars_data = _regenerate_and_refuse_from_edited_text(props)
        if fused is None:
            self.report({'ERROR'}, tr("Failed to regenerate phonemes from edited text. Make sure ASR text is not empty."))
            return {'CANCELLED'}

        ok = _apply_frames_to_rig(fused, fps, frame_offset)
        if not ok:
            self.report({'ERROR'}, tr("Failed to write animation"))
            return {'CANCELLED'}

        props.phoneme_correction_active = True
        AnimationCache.store_frames(
            frames=fused,
            fps=fps,
            target_object=AnimationCache.get_target_object(),
            target_type=AnimationCache.get_target_type(),
            mapping=AnimationCache.get_mapping(),
            frame_offset=frame_offset,
        )

        # Create timeline markers for each character (scoped to frame range)
        if chars_data:
            from ..core.timeline_markers import create_char_markers
            n = create_char_markers(scene, chars_data, fps, frame_offset)
            print(f"[AudioMorph DAZ] Created {n} char markers")

        self.report({'INFO'}, tr("Phonemes regenerated from edited text"))
        print(f"[AudioMorph DAZ] Edited text applied: {len(fused)} frames re-fused")
        return {'FINISHED'}


class AUDIO2FACE_OT_daz_open_text_editor(bpy.types.Operator):
    """DAZ version of AUDIO2FACE_OT_open_text_editor.

    Opens a multi-line auto-wrapping text editor for the DAZ page's
    asr_recognized_text. Same UI behavior as the Animation page version.
    """
    bl_idname = "audiomorph.daz_open_text_editor"
    bl_label = t("Edit ASR Text")
    bl_description = t("Open multi-line editor for ASR recognized text. Supports auto-wrap and resizing.")
    bl_options = {'REGISTER', 'UNDO'}

    text: bpy.props.StringProperty(
        name="",
        description="ASR recognized text. Edit to correct misrecognitions, then click OK.",
        default="",
        maxlen=32768,
    )

    def invoke(self, context, event):
        props = context.scene.audiomorph_daz_props
        self.text = getattr(props, "asr_recognized_text", "") or ""
        return context.window_manager.invoke_props_dialog(self, width=650)

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.scale_y = 6.0
        row.prop(self, "text", text="", expand=True)

    def execute(self, context):
        props = context.scene.audiomorph_daz_props
        props.asr_recognized_text = self.text or ""
        self.report({'INFO'}, tr("ASR text updated. Click Apply Edited Text to regenerate phonemes."))
        return {'FINISHED'}


class AUDIO2FACE_OT_daz_forced_align_text(bpy.types.Operator):
    """DAZ version of AUDIO2FACE_OT_forced_align_text.

    Force-aligns edited text to audio via CTC forced alignment, then
    re-fuses and writes to the DAZ rig. Use when ASR dropped characters
    (fast songs) and the user added/removed chars to fix the text.
    """
    bl_idname = "audiomorph.daz_forced_align_text"
    bl_label = t("Force Align Text")
    bl_description = t("Align edited text to audio via CTC forced alignment. Use when ASR dropped characters (fast songs) and you added/removed chars to fix it.")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        from ..core.animation_cache import AnimationCache
        return (AnimationCache.has_data()
                and AnimationCache.has_original_data())

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        scene = context.scene
        # Only the DAZ page remains; always use audiomorph_daz_props.
        props = scene.audiomorph_daz_props

        from ..core.animation_cache import AnimationCache
        # Reuse the shared forced-alignment + fusion logic from phoneme.py
        from ..operators.phoneme import _forced_align_and_refuse_from_edited_text

        # DAZ page stores audio path in audiomorph_daz_props.audio_file
        # (separate from animation page's audiomorph_props.audio_file)
        audio_path = props.audio_file
        if not audio_path:
            self.report({'ERROR'}, tr("No audio file selected"))
            return {'CANCELLED'}

        fused, fps, frame_offset, chars_data = _forced_align_and_refuse_from_edited_text(props, audio_path)
        if fused is None:
            self.report({'ERROR'}, tr("Forced alignment failed. Check console for details."))
            return {'CANCELLED'}

        ok = _apply_frames_to_rig(fused, fps, frame_offset)
        if not ok:
            self.report({'ERROR'}, tr("Failed to write animation"))
            return {'CANCELLED'}

        props.phoneme_correction_active = True
        AnimationCache.store_frames(
            frames=fused,
            fps=fps,
            target_object=AnimationCache.get_target_object(),
            target_type=AnimationCache.get_target_type(),
            mapping=AnimationCache.get_mapping(),
            frame_offset=frame_offset,
        )

        # Create timeline markers for each character (scoped to frame range)
        if chars_data:
            from ..core.timeline_markers import create_char_markers
            n = create_char_markers(scene, chars_data, fps, frame_offset)
            print(f"[AudioMorph DAZ] Created {n} char markers")

        self.report({'INFO'}, tr("Forced alignment applied"))
        print(f"[AudioMorph DAZ] Forced align applied: {len(fused)} frames re-fused")
        return {'FINISHED'}


class AUDIO2FACE_OT_daz_fix_timestamps_from_markers(bpy.types.Operator):
    """DAZ version of AUDIO2FACE_OT_fix_timestamps_from_markers.

    Reads adjusted A2F timeline markers, rebuilds character timestamps,
    regenerates phonemes, re-fuses, and writes to the DAZ rig. Only
    markers within the scene frame range are processed.
    """
    bl_idname = "audiomorph.daz_fix_timestamps_from_markers"
    bl_label = t("Fix Timestamps from Markers")
    bl_description = t("Read adjusted timeline markers, rebuild character timestamps, regenerate phonemes and re-fuse animation")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not license_manager.is_activated():
            return False
        from ..core.animation_cache import AnimationCache
        from ..core.timeline_markers import _is_a2f_marker
        if not (AnimationCache.has_data() and AnimationCache.has_original_data()):
            return False
        scene = context.scene
        for m in scene.timeline_markers:
            if _is_a2f_marker(m) and scene.frame_start <= m.frame <= scene.frame_end:
                return True
        return False

    def execute(self, context):
        ok, lic_msg = license_manager.require_license()
        if not ok:
            self.report({'ERROR'}, tr("License required") + f": {lic_msg}")
            return {'CANCELLED'}

        scene = context.scene
        # Only the DAZ page remains; always use audiomorph_daz_props.
        props = scene.audiomorph_daz_props

        from ..core.animation_cache import AnimationCache
        from ..core.timeline_markers import read_char_markers
        from ..operators.phoneme import _refuse_from_chars_data

        fps = AnimationCache.get_fps()
        frame_offset = AnimationCache.get_phoneme_frame_offset()

        chars_data = read_char_markers(scene, fps, frame_offset)
        if not chars_data:
            self.report({'ERROR'}, tr("No A2F markers found in timeline frame range"))
            return {'CANCELLED'}

        print(f"[AudioMorph DAZ] Fix timestamps: read {len(chars_data)} chars from markers")

        fused, fps_out, frame_offset_out = _refuse_from_chars_data(props, chars_data)
        if fused is None:
            self.report({'ERROR'}, tr("Failed to regenerate phonemes from markers"))
            return {'CANCELLED'}

        ok = _apply_frames_to_rig(fused, fps_out, frame_offset_out)
        if not ok:
            self.report({'ERROR'}, tr("Failed to write animation"))
            return {'CANCELLED'}

        props.phoneme_correction_active = True
        AnimationCache.store_frames(
            frames=fused,
            fps=fps_out,
            target_object=AnimationCache.get_target_object(),
            target_type=AnimationCache.get_target_type(),
            mapping=AnimationCache.get_mapping(),
            frame_offset=frame_offset_out,
        )
        self.report({'INFO'}, tr("Timestamps fixed from markers, animation regenerated"))
        print(f"[AudioMorph DAZ] Fix timestamps applied: {len(fused)} frames re-fused")
        return {'FINISHED'}


classes = [
    AUDIO2FACE_OT_daz_toggle_phoneme_correction,
    AUDIO2FACE_OT_daz_apply_phoneme_strength,
    AUDIO2FACE_OT_daz_apply_edited_text,
    AUDIO2FACE_OT_daz_open_text_editor,
    AUDIO2FACE_OT_daz_forced_align_text,
    AUDIO2FACE_OT_daz_fix_timestamps_from_markers,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
